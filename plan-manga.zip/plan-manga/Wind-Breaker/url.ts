export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=Wind%20Breaker";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/wind-breaker";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/659e81efd9c91173cd718137";
