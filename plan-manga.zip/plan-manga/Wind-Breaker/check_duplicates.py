import json
import re

sql_file = 'dump-MangaBlade-202607072203.sql'

def load_sql():
    with open(sql_file, 'r', encoding='utf-8') as f:
        return f.read()

def check_json(file_path, sql_content):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return

    print(f"--- Checking {file_path} ---")
    
    # Try to find common data fields
    if 'data' in data:
        d = data['data']
        # For responseByChapter.json
        if 'item' in d and isinstance(d['item'], dict):
            item = d['item']
            comic_name = item.get('comic_name', '')
            chapter_name = item.get('chapter_name', '')
            print(f"Found Chapter Data: Comic='{comic_name}', Chapter='{chapter_name}'")
            if comic_name and comic_name in sql_content:
                print(f"[DUPLICATE] Comic name '{comic_name}' found in SQL.")
            if chapter_name and f"'{chapter_name}'" in sql_content:
                print(f"[WARNING] Chapter name '{chapter_name}' found in SQL (might be generic).")
        
        # For responseBySlug.json
        if 'item' in d and isinstance(d['item'], dict) and 'title' in d['item']:
            item = d['item']
            title = item.get('title', '')
            slug = item.get('slug', '')
            author = item.get('author', [])
            print(f"Found Manga Data: Title='{title}', Slug='{slug}', Author={author}")
            if title and title in sql_content:
                print(f"[DUPLICATE] Title '{title}' found in SQL.")
            if slug and slug in sql_content:
                print(f"[DUPLICATE] Slug '{slug}' found in SQL.")
                
            # Check chapters in slug response
            if 'chapters' in item:
                chaps = item['chapters']
                if len(chaps) > 0 and 'server_data' in chaps[0]:
                    server_data = chaps[0]['server_data']
                    print(f"Found {len(server_data)} chapters in server_data.")
                    sample_chap = server_data[0].get('chapter_name', '')
                    if sample_chap and f"'{sample_chap}'" in sql_content:
                        print(f"[WARNING] Sample chapter '{sample_chap}' found in SQL.")
                        
        # For responseBySearch.json
        if 'items' in d and isinstance(d['items'], list):
            items = d['items']
            print(f"Found {len(items)} items in search results.")
            for item in items:
                title = item.get('title', '')
                if title and title in sql_content:
                    print(f"[DUPLICATE] Search Result Title '{title}' found in SQL.")

if __name__ == "__main__":
    sql_content = load_sql()
    check_json('responseByChapter.json', sql_content)
    check_json('responseBySlug.json', sql_content)
    check_json('responseBySearch.json', sql_content)
