import re

with open('dump-MangaBlade-202607072203.sql') as f:
    sql = f.read()

# Extract the block of INSERT INTO `chapter_page` VALUES ... ;
match = re.search(r'INSERT INTO `chapter_page` VALUES\n(.*?);', sql, re.DOTALL)
if not match:
    print('No inserts found')
else:
    values = match.group(1)
    # Match tuples: (id, chapter_id, page_number, 'image_url', 'created_at')
    rows = re.findall(r'\((\d+),\s*(\d+),\s*(\d+),\s*\'(.*?)\',\s*\'(.*?)\'\)', values)
    
    print(f'Total rows extracted: {len(rows)}')
    
    chapter_page_map = {}
    duplicates = []
    
    chapter_ids = set()
    
    for r in rows:
        id_val, chapter_id, page_number, image_url, created_at = r
        chapter_ids.add(chapter_id)
        
        key = (chapter_id, page_number)
        if key in chapter_page_map:
            duplicates.append(key)
        else:
            chapter_page_map[key] = r
            
    print(f'Total unique chapter_ids: {len(chapter_ids)}')
    print(f'Duplicates of (chapter_id, page_number): {len(duplicates)}')
    
    if len(duplicates) > 0:
        print('Sample duplicates:', duplicates[:5])
        
    # Check if image_urls are duplicated
    url_map = {}
    url_dups = 0
    dup_urls = set()
    for r in rows:
        url = r[3]
        if url in url_map:
            url_dups += 1
            dup_urls.add(url)
        else:
            url_map[url] = True
            
    print(f'Number of duplicated image URLs (possibly from different chapters): {url_dups}')
    if dup_urls:
        print(f'Sample duplicated URLs: {list(dup_urls)[:2]}')
