import json
import re

with open('dump-MangaBlade-202607072203.sql', 'r', encoding='utf-8') as f:
    sql = f.read()

def parse_sql_inserts(table_name):
    # Extracts all rows for a given table name from the SQL dump
    match = re.search(f"INSERT INTO `{table_name}` VALUES\n(.*?);", sql, re.DOTALL)
    if not match:
        return []
    values = match.group(1)
    
    if table_name == 'manga':
        # (id, otruyen_manga_id, owner_user_id, source_type, slug, title, origin_name, description, status, thumb_url, ...)
        rows = re.findall(r"\((\d+),\s*'([^']+)'", values)
        # It's tricky to regex parse full rows with text containing commas, so we do basic search
        return values
    elif table_name == 'chapter':
        rows = re.findall(r"\((\d+),\s*'([^']+)',\s*(\d+),\s*'([^']*)',\s*'([^']*)'", values)
        # tuples: (id, chapter_api_url, manga_id, title, chapter_number)
        return rows
    elif table_name == 'chapter_page':
        rows = re.findall(r"\((\d+),\s*(\d+),\s*(\d+),\s*'([^']+)',\s*'[^']+'\)", values)
        # tuples: (id, chapter_id, page_number, image_url)
        return rows
    return values

# 1. Check Manga (from responseBySlug.json)
try:
    with open('responseBySlug.json', 'r', encoding='utf-8') as f:
        slug_data = json.load(f)
        item = slug_data['data']['item']
        slug = item['slug']
        name = item['name']
        print(f"--- JSON Manga ---")
        print(f"Slug: {slug}")
        print(f"Name: {name}")
        
        manga_sql = parse_sql_inserts('manga')
        if slug in manga_sql and name in manga_sql:
            print(f"-> Manga MATCHES in SQL: True")
        else:
            print(f"-> Manga MATCHES in SQL: False")
            
        # Check Chapters in JSON
        server_data = item['chapters'][0]['server_data']
        print(f"\n--- JSON Chapters List ---")
        print(f"Total chapters in JSON: {len(server_data)}")
        
        chap_sql = parse_sql_inserts('chapter')
        # Check first and last chapter
        chap_api_urls = [c[1] for c in chap_sql]
        chaps_found = 0
        for chap in server_data:
            if chap['chapter_api_data'] in chap_api_urls:
                chaps_found += 1
        print(f"-> Chapters matched by API URL in SQL: {chaps_found} / {len(server_data)}")
        
except Exception as e:
    print(f"Error parsing slug: {e}")

# 2. Check Chapter Pages (from responseByChapter.json)
try:
    with open('responseByChapter.json', 'r', encoding='utf-8') as f:
        chap_data = json.load(f)
        item = chap_data['data']['item']
        domain = chap_data['data']['domain_cdn']
        chap_path = item['chapter_path']
        images = item['chapter_image']
        
        print(f"\n--- JSON Chapter Pages ---")
        print(f"Chapter name: {item['chapter_name']}")
        print(f"Total pages in JSON: {len(images)}")
        
        page_sql = parse_sql_inserts('chapter_page')
        # Check if all image URLs exist in DB
        pages_found = 0
        for img in images:
            expected_url = f"{domain}/{chap_path}/{img['image_file']}"
            if any(p[3] == expected_url for p in page_sql):
                pages_found += 1
                
        print(f"-> Pages matched by Image URL in SQL: {pages_found} / {len(images)}")

except Exception as e:
    print(f"Error parsing chapter pages: {e}")
