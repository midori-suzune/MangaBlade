/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: MangaBlade
-- ------------------------------------------------------
-- Server version	9.7.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `author`
--

DROP TABLE IF EXISTS `author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `author` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_author_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author`
--

LOCK TABLES `author` WRITE;
/*!40000 ALTER TABLE `author` DISABLE KEYS */;
INSERT INTO `author` VALUES
(1,'Nii Satoru');
/*!40000 ALTER TABLE `author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `otruyen_category_id` char(24) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_category_otruyen_id` (`otruyen_category_id`),
  UNIQUE KEY `uq_category_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES
(1,'6508654905d5791ad671a491','Action','action'),
(2,'6508654905d5791ad671a4af','Comedy','comedy'),
(3,'6508654905d5791ad671a4d6','Manga','manga'),
(4,'6508654905d5791ad671a4ec','School Life','school-life'),
(5,'6508654905d5791ad671a4f6','Shounen','shounen');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chapter`
--

DROP TABLE IF EXISTS `chapter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chapter` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `chapter_api_url` varchar(500) DEFAULT NULL,
  `manga_id` bigint NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `chapter_number` varchar(30) DEFAULT NULL,
  `chapter_sort` decimal(10,3) DEFAULT NULL,
  `approval_status` varchar(20) NOT NULL DEFAULT 'DRAFT',
  `submitted_at` datetime(3) DEFAULT NULL,
  `reviewed_at` datetime(3) DEFAULT NULL,
  `reviewed_by` bigint DEFAULT NULL,
  `rejection_reason` varchar(1000) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chapter_id_manga` (`id`,`manga_id`),
  UNIQUE KEY `uq_chapter_api_url` (`chapter_api_url`),
  KEY `fk_chapter_manga` (`manga_id`),
  KEY `fk_chapter_reviewed_by` (`reviewed_by`),
  CONSTRAINT `fk_chapter_manga` FOREIGN KEY (`manga_id`) REFERENCES `manga` (`id`),
  CONSTRAINT `fk_chapter_reviewed_by` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`),
  CONSTRAINT `chk_chapter_approval_status` CHECK ((`approval_status` in (_utf8mb4'DRAFT',_utf8mb4'PENDING',_utf8mb4'APPROVED',_utf8mb4'REJECTED')))
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapter`
--

LOCK TABLES `chapter` WRITE;
/*!40000 ALTER TABLE `chapter` DISABLE KEYS */;
INSERT INTO `chapter` VALUES
(1,'https://sv1.otruyencdn.com/v1/api/chapter/659e81efd9c91173cd718137',1,'','1',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(2,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f0d9c91173cd71813a',1,'','2',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(3,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f1d9c91173cd71813d',1,'','3',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(4,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f1d9c91173cd718140',1,'','4',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(5,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f2d9c91173cd718143',1,'','5',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(6,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f3d9c91173cd718146',1,'','6',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(7,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f3d9c91173cd718149',1,'','7',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(8,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f4d9c91173cd71814c',1,'','8',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(9,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f4d9c91173cd71814f',1,'','9',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(10,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f5d9c91173cd718152',1,'','10',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(11,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f5d9c91173cd718155',1,'','11',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(12,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f5d9c91173cd71815c',1,'','12',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(13,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f6d9c91173cd71815f',1,'','13',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(14,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f7d9c91173cd718165',1,'','14',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(15,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f6d9c91173cd718162',1,'','14.5',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(16,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f7d9c91173cd718168',1,'','15',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(17,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f8d9c91173cd71816b',1,'','16',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(18,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f8d9c91173cd718170',1,'','17',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(19,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f9d9c91173cd718175',1,'','18',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(20,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f9d9c91173cd71817a',1,'','19',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(21,'https://sv1.otruyencdn.com/v1/api/chapter/659e81f9d9c91173cd71817e',1,'','20',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(22,'https://sv1.otruyencdn.com/v1/api/chapter/659e81fad9c91173cd718181',1,'','21',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(23,'https://sv1.otruyencdn.com/v1/api/chapter/659e81fad9c91173cd718184',1,'','22',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(24,'https://sv1.otruyencdn.com/v1/api/chapter/659e81fbd9c91173cd718187',1,'','23',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(25,'https://sv1.otruyencdn.com/v1/api/chapter/659e81fbd9c91173cd71818a',1,'','24',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(26,'https://sv1.otruyencdn.com/v1/api/chapter/659e81fcd9c91173cd71818d',1,'','25',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(27,'https://sv1.otruyencdn.com/v1/api/chapter/659e81fcd9c91173cd718190',1,'','26',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(28,'https://sv1.otruyencdn.com/v1/api/chapter/659e81fcd9c91173cd718193',1,'','27',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(29,'https://sv1.otruyencdn.com/v1/api/chapter/659e81fdd9c91173cd718196',1,'','28',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(30,'https://sv1.otruyencdn.com/v1/api/chapter/659e81fdd9c91173cd718199',1,'','29',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(31,'https://sv1.otruyencdn.com/v1/api/chapter/659e81fed9c91173cd71819c',1,'','30',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(32,'https://sv1.otruyencdn.com/v1/api/chapter/659e81fed9c91173cd71819f',1,'','31',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(33,'https://sv1.otruyencdn.com/v1/api/chapter/659e81ffd9c91173cd7181a2',1,'','32',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(34,'https://sv1.otruyencdn.com/v1/api/chapter/659e81ffd9c91173cd7181a5',1,'','33',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(35,'https://sv1.otruyencdn.com/v1/api/chapter/659e8200d9c91173cd7181a8',1,'','34',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(36,'https://sv1.otruyencdn.com/v1/api/chapter/659e8201d9c91173cd7181ab',1,'','35',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(37,'https://sv1.otruyencdn.com/v1/api/chapter/659e8201d9c91173cd7181ae',1,'','36',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(38,'https://sv1.otruyencdn.com/v1/api/chapter/659e8201d9c91173cd7181b1',1,'','37',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(39,'https://sv1.otruyencdn.com/v1/api/chapter/659e8202d9c91173cd7181b4',1,'','38',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(40,'https://sv1.otruyencdn.com/v1/api/chapter/659e8202d9c91173cd7181b7',1,'','39',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(41,'https://sv1.otruyencdn.com/v1/api/chapter/659e8203d9c91173cd7181ba',1,'','40',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(42,'https://sv1.otruyencdn.com/v1/api/chapter/659e8203d9c91173cd7181bd',1,'','41',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(43,'https://sv1.otruyencdn.com/v1/api/chapter/659e8204d9c91173cd7181c0',1,'','42',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(44,'https://sv1.otruyencdn.com/v1/api/chapter/659e8204d9c91173cd7181c3',1,'','43',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(45,'https://sv1.otruyencdn.com/v1/api/chapter/659e8205d9c91173cd7181c6',1,'','44',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(46,'https://sv1.otruyencdn.com/v1/api/chapter/659e8205d9c91173cd7181cd',1,'','45',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(47,'https://sv1.otruyencdn.com/v1/api/chapter/659e8206d9c91173cd7181d0',1,'','46',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(48,'https://sv1.otruyencdn.com/v1/api/chapter/659e8206d9c91173cd7181d3',1,'','47',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(49,'https://sv1.otruyencdn.com/v1/api/chapter/659e8207d9c91173cd7181d8',1,'','48',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(50,'https://sv1.otruyencdn.com/v1/api/chapter/659e8207d9c91173cd7181dd',1,'','49',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(51,'https://sv1.otruyencdn.com/v1/api/chapter/659e8208d9c91173cd7181e1',1,'','50',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(52,'https://sv1.otruyencdn.com/v1/api/chapter/659e8208d9c91173cd7181e5',1,'','51',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(53,'https://sv1.otruyencdn.com/v1/api/chapter/659e8209d9c91173cd7181e8',1,'','52',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(54,'https://sv1.otruyencdn.com/v1/api/chapter/659e8209d9c91173cd7181eb',1,'','53',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(55,'https://sv1.otruyencdn.com/v1/api/chapter/659e820ad9c91173cd7181ee',1,'','54',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(56,'https://sv1.otruyencdn.com/v1/api/chapter/659e820ad9c91173cd7181f1',1,'','55',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(57,'https://sv1.otruyencdn.com/v1/api/chapter/659e820bd9c91173cd7181f4',1,'','56',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(58,'https://sv1.otruyencdn.com/v1/api/chapter/659e820bd9c91173cd7181f7',1,'','57',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(59,'https://sv1.otruyencdn.com/v1/api/chapter/659e820cd9c91173cd7181fa',1,'','58',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(60,'https://sv1.otruyencdn.com/v1/api/chapter/659e820cd9c91173cd7181fd',1,'','59',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(61,'https://sv1.otruyencdn.com/v1/api/chapter/659e820dd9c91173cd718200',1,'','60',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(62,'https://sv1.otruyencdn.com/v1/api/chapter/659e820dd9c91173cd718203',1,'','61',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(63,'https://sv1.otruyencdn.com/v1/api/chapter/659e820ed9c91173cd718206',1,'','62',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(64,'https://sv1.otruyencdn.com/v1/api/chapter/659e820ed9c91173cd718209',1,'','63',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(65,'https://sv1.otruyencdn.com/v1/api/chapter/659e820ed9c91173cd71820c',1,'','64',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(66,'https://sv1.otruyencdn.com/v1/api/chapter/659e820fd9c91173cd71820f',1,'','65',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(67,'https://sv1.otruyencdn.com/v1/api/chapter/659e820fd9c91173cd718212',1,'','66',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(68,'https://sv1.otruyencdn.com/v1/api/chapter/659e8210d9c91173cd718215',1,'','67',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(69,'https://sv1.otruyencdn.com/v1/api/chapter/659e8210d9c91173cd718218',1,'','68',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(70,'https://sv1.otruyencdn.com/v1/api/chapter/659e8211d9c91173cd71821b',1,'','69',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(71,'https://sv1.otruyencdn.com/v1/api/chapter/659e8211d9c91173cd71821e',1,'','70',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(72,'https://sv1.otruyencdn.com/v1/api/chapter/659e8211d9c91173cd718221',1,'','71',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(73,'https://sv1.otruyencdn.com/v1/api/chapter/659e8212d9c91173cd718224',1,'','72',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(74,'https://sv1.otruyencdn.com/v1/api/chapter/659e8212d9c91173cd718227',1,'','73',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(75,'https://sv1.otruyencdn.com/v1/api/chapter/659e8213d9c91173cd71822a',1,'','74',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(76,'https://sv1.otruyencdn.com/v1/api/chapter/659e8213d9c91173cd71822e',1,'','75',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(77,'https://sv1.otruyencdn.com/v1/api/chapter/659e8214d9c91173cd718232',1,'','76',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(78,'https://sv1.otruyencdn.com/v1/api/chapter/659e8214d9c91173cd718238',1,'','77',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(79,'https://sv1.otruyencdn.com/v1/api/chapter/659e8214d9c91173cd71823b',1,'','78',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(80,'https://sv1.otruyencdn.com/v1/api/chapter/659e8215d9c91173cd718240',1,'','79',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(81,'https://sv1.otruyencdn.com/v1/api/chapter/659e8215d9c91173cd718244',1,'','80',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(82,'https://sv1.otruyencdn.com/v1/api/chapter/659e8216d9c91173cd718247',1,'','81',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(83,'https://sv1.otruyencdn.com/v1/api/chapter/659e8216d9c91173cd71824a',1,'','82',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(84,'https://sv1.otruyencdn.com/v1/api/chapter/659e8217d9c91173cd71824d',1,'','83',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(85,'https://sv1.otruyencdn.com/v1/api/chapter/659e8217d9c91173cd718250',1,'','84',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(86,'https://sv1.otruyencdn.com/v1/api/chapter/659e8218d9c91173cd718253',1,'','85',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(87,'https://sv1.otruyencdn.com/v1/api/chapter/659e8218d9c91173cd718256',1,'','86',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(88,'https://sv1.otruyencdn.com/v1/api/chapter/659e8219d9c91173cd718259',1,'','87',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(89,'https://sv1.otruyencdn.com/v1/api/chapter/659e8219d9c91173cd71825c',1,'Cuộc họp khẩn cấp','88',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(90,'https://sv1.otruyencdn.com/v1/api/chapter/659e821ad9c91173cd71825f',1,'','89',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(91,'https://sv1.otruyencdn.com/v1/api/chapter/659e821ad9c91173cd718262',1,'','90',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(92,'https://sv1.otruyencdn.com/v1/api/chapter/659e821ad9c91173cd718265',1,'','91',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(93,'https://sv1.otruyencdn.com/v1/api/chapter/659e821bd9c91173cd718268',1,'','92',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(94,'https://sv1.otruyencdn.com/v1/api/chapter/659e821cd9c91173cd71826b',1,'','93',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(95,'https://sv1.otruyencdn.com/v1/api/chapter/659e821cd9c91173cd71826e',1,'','94',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(96,'https://sv1.otruyencdn.com/v1/api/chapter/65afad4dd9c91173cd7e6e23',1,'','95',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(97,'https://sv1.otruyencdn.com/v1/api/chapter/65afad4ed9c91173cd7e6e26',1,'','96',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(98,'https://sv1.otruyencdn.com/v1/api/chapter/65b740d90b71e8bf0af7d66d',1,'','97',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(99,'https://sv1.otruyencdn.com/v1/api/chapter/65c066fb0b71e8bf0af85f3a',1,'','98',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(100,'https://sv1.otruyencdn.com/v1/api/chapter/65cc377ed99f3dea41c7da53',1,'','99',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(101,'https://sv1.otruyencdn.com/v1/api/chapter/65d5cca18d19104b9c73158b',1,'','100',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(102,'https://sv1.otruyencdn.com/v1/api/chapter/65d5cca08d19104b9c731588',1,'','100.5',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(103,'https://sv1.otruyencdn.com/v1/api/chapter/65dee521164c256eada7ac71',1,'','101',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(104,'https://sv1.otruyencdn.com/v1/api/chapter/65e81a438d19104b9c73b5c0',1,'','102',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(105,'https://sv1.otruyencdn.com/v1/api/chapter/65f931878d19104b9c7445d5',1,'','103',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(106,'https://sv1.otruyencdn.com/v1/api/chapter/65fa8d25164c256eada8932d',1,'','104',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(107,'https://sv1.otruyencdn.com/v1/api/chapter/660a442b8d19104b9c74d210',1,'','105',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(108,'https://sv1.otruyencdn.com/v1/api/chapter/660b9428164c256eada91d33',1,'','106',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(109,'https://sv1.otruyencdn.com/v1/api/chapter/660e41cd8d19104b9c74fb45',1,'Quyết định','107',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(110,'https://sv1.otruyencdn.com/v1/api/chapter/660e41cd8d19104b9c74fb48',1,'Điều cần thực hiện','108',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(111,'https://sv1.otruyencdn.com/v1/api/chapter/660e41ce8d19104b9c74fb4b',1,'','109',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(112,'https://sv1.otruyencdn.com/v1/api/chapter/6614c81f164c256eada96cab',1,'','110',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(113,'https://sv1.otruyencdn.com/v1/api/chapter/6614c81f164c256eada96cb0',1,'','111',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(114,'https://sv1.otruyencdn.com/v1/api/chapter/661f5a3a164c256eada9b770',1,'','112',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(115,'https://sv1.otruyencdn.com/v1/api/chapter/662606ef8d19104b9c75a8e1',1,'','113',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(116,'https://sv1.otruyencdn.com/v1/api/chapter/6634a3ef8d19104b9c7602b7',1,'Ranh giới sinh tử','114',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(117,'https://sv1.otruyencdn.com/v1/api/chapter/663d8c900edcbd817f976bd7',1,'','115',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(118,'https://sv1.otruyencdn.com/v1/api/chapter/663d8c900edcbd817f976bda',1,'','116',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(119,'https://sv1.otruyencdn.com/v1/api/chapter/663d8c910edcbd817f976bdd',1,'','117',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(120,'https://sv1.otruyencdn.com/v1/api/chapter/664f32baa833720746733074',1,'','118',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(121,'https://sv1.otruyencdn.com/v1/api/chapter/6651a7c4a833720746733c0c',1,'','119',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(122,'https://sv1.otruyencdn.com/v1/api/chapter/665450c4a833720746734c01',1,'','120',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(123,'https://sv1.otruyencdn.com/v1/api/chapter/665997dca83372074674df04',1,'','121',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(124,'https://sv1.otruyencdn.com/v1/api/chapter/665d7cb6a4468f0e0dd8f444',1,'','122',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(125,'https://sv1.otruyencdn.com/v1/api/chapter/66617da9a8337207467b3a36',1,'','123',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(126,'https://sv1.otruyencdn.com/v1/api/chapter/6667fe7ba833720746804798',1,'','124',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(127,'https://sv1.otruyencdn.com/v1/api/chapter/66728c41a833720746810669',1,'','125',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(128,'https://sv1.otruyencdn.com/v1/api/chapter/66791320a833720746813396',1,'','126',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(129,'https://sv1.otruyencdn.com/v1/api/chapter/66823d81a4468f0e0de04769',1,'','127',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(130,'https://sv1.otruyencdn.com/v1/api/chapter/6686419fc926626890a12d36',1,'','128',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(131,'https://sv1.otruyencdn.com/v1/api/chapter/6694d904c705a578a7f5bf5e',1,'','129',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(132,'https://sv1.otruyencdn.com/v1/api/chapter/6694d905c705a578a7f5bf61',1,'','130',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(133,'https://sv1.otruyencdn.com/v1/api/chapter/66a252a4c926626890a1cbdb',1,'','131',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(134,'https://sv1.otruyencdn.com/v1/api/chapter/66e01187c705a578a7f6f0d7',1,'','132',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(135,'https://sv1.otruyencdn.com/v1/api/chapter/66e01188c705a578a7f6f0da',1,'','133',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(136,'https://sv1.otruyencdn.com/v1/api/chapter/66e01188c705a578a7f6f0dd',1,'','134',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(137,'https://sv1.otruyencdn.com/v1/api/chapter/66e01189c705a578a7f6f0e0',1,'','135',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(138,'https://sv1.otruyencdn.com/v1/api/chapter/66e0118ac705a578a7f6f0e3',1,'','136',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(139,'https://sv1.otruyencdn.com/v1/api/chapter/66e0118ac705a578a7f6f0e6',1,'','137',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(140,'https://sv1.otruyencdn.com/v1/api/chapter/66e0118bc705a578a7f6f0e9',1,'','138',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(141,'https://sv1.otruyencdn.com/v1/api/chapter/66e0118cc705a578a7f6f0ef',1,'','139',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(142,'https://sv1.otruyencdn.com/v1/api/chapter/66e0118cc705a578a7f6f0ec',1,'','139.5',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(143,'https://sv1.otruyencdn.com/v1/api/chapter/66e0118dc705a578a7f6f0f2',1,'','140',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(144,'https://sv1.otruyencdn.com/v1/api/chapter/66e0118ec705a578a7f6f0f5',1,'','141',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(145,'https://sv1.otruyencdn.com/v1/api/chapter/66e0118fc705a578a7f6f0f8',1,'','142',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(146,'https://sv1.otruyencdn.com/v1/api/chapter/66e0118fc705a578a7f6f0fb',1,'','143',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(147,'https://sv1.otruyencdn.com/v1/api/chapter/66e972bbc705a578a7f70885',1,'','144',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(148,'https://sv1.otruyencdn.com/v1/api/chapter/66e972bcc705a578a7f70888',1,'','145',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(149,'https://sv1.otruyencdn.com/v1/api/chapter/66f2adc4c705a578a7f72e92',1,'','146',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(150,'https://sv1.otruyencdn.com/v1/api/chapter/66f778f7c926626890a313e5',1,'','147',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(151,'https://sv1.otruyencdn.com/v1/api/chapter/66f778f8c926626890a313e8',1,'','148',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(152,'https://sv1.otruyencdn.com/v1/api/chapter/66fa2043c926626890a3268e',1,'','149',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(153,'https://sv1.otruyencdn.com/v1/api/chapter/6707820cc926626890a36ae7',1,'','151',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(154,'https://sv1.otruyencdn.com/v1/api/chapter/6707820cc926626890a36aea',1,'','152',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(155,'https://sv1.otruyencdn.com/v1/api/chapter/67108459c926626890a3a2df',1,'','153',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(156,'https://sv1.otruyencdn.com/v1/api/chapter/67108459c926626890a3a2e2',1,'','154',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(157,'https://sv1.otruyencdn.com/v1/api/chapter/6713271dc705a578a7f7e578',1,'','155',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(158,'https://sv1.otruyencdn.com/v1/api/chapter/6719bdf5c926626890a3da20',1,'','156',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(159,'https://sv1.otruyencdn.com/v1/api/chapter/671f0911c705a578a7f82a86',1,'','157',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(160,'https://sv1.otruyencdn.com/v1/api/chapter/6721dcf9c926626890a40c58',1,'','158',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(161,'https://sv1.otruyencdn.com/v1/api/chapter/672ee2dbc705a578a7f873c2',1,'','159',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(162,'https://sv1.otruyencdn.com/v1/api/chapter/67386a64c705a578a7f8ab7e',1,'','160',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(163,'https://sv1.otruyencdn.com/v1/api/chapter/67be8d3dc705a578a7fbb975',1,'','161',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(164,'https://sv1.otruyencdn.com/v1/api/chapter/67be8d3dc705a578a7fbb978',1,'','162',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(165,'https://sv1.otruyencdn.com/v1/api/chapter/67be8d3ec705a578a7fbb97b',1,'','163',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(166,'https://sv1.otruyencdn.com/v1/api/chapter/67be8d3fc705a578a7fbb97e',1,'','164',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(167,'https://sv1.otruyencdn.com/v1/api/chapter/67be8d3fc705a578a7fbb981',1,'','165',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(168,'https://sv1.otruyencdn.com/v1/api/chapter/67be8d40c705a578a7fbb984',1,'','166',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(169,'https://sv1.otruyencdn.com/v1/api/chapter/67be8d41c705a578a7fbb987',1,'','167',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(170,'https://sv1.otruyencdn.com/v1/api/chapter/67be8d41c705a578a7fbb98a',1,'','168',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(171,'https://sv1.otruyencdn.com/v1/api/chapter/67be8d42c705a578a7fbb98d',1,'','169',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(172,'https://sv1.otruyencdn.com/v1/api/chapter/67be8d42c705a578a7fbb994',1,'','170',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(173,'https://sv1.otruyencdn.com/v1/api/chapter/67c68149c705a578a7fbd7cc',1,'','171',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(174,'https://sv1.otruyencdn.com/v1/api/chapter/67d3b3bac705a578a7fc0e66',1,'','172',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(175,'https://sv1.otruyencdn.com/v1/api/chapter/6836ace6c926626890a9dea1',1,'','172.5',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(176,'https://sv1.otruyencdn.com/v1/api/chapter/6836ace7c926626890a9dea4',1,'','173',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(177,'https://sv1.otruyencdn.com/v1/api/chapter/6836ace8c926626890a9dea7',1,'','174',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(178,'https://sv1.otruyencdn.com/v1/api/chapter/6836ace9c926626890a9deaa',1,'','175',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(179,'https://sv1.otruyencdn.com/v1/api/chapter/6836ace9c926626890a9dead',1,'','176',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(180,'https://sv1.otruyencdn.com/v1/api/chapter/6836aceac926626890a9deb0',1,'','177',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(181,'https://sv1.otruyencdn.com/v1/api/chapter/6836acebc926626890a9deb7',1,'','178',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(182,'https://sv1.otruyencdn.com/v1/api/chapter/6836acebc926626890a9deba',1,'','179',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(183,'https://sv1.otruyencdn.com/v1/api/chapter/684fbfe0c705a578a7fec62f',1,'','180',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(184,'https://sv1.otruyencdn.com/v1/api/chapter/684fbfe1c705a578a7fec632',1,'','181',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(185,'https://sv1.otruyencdn.com/v1/api/chapter/685a3a8ac705a578a7ff0051',1,'','182',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(186,'https://sv1.otruyencdn.com/v1/api/chapter/68a43994c705a578a7014af9',1,'','183',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(187,'https://sv1.otruyencdn.com/v1/api/chapter/68a43995c705a578a7014b00',1,'','184',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(188,'https://sv1.otruyencdn.com/v1/api/chapter/68a43996c705a578a7014b03',1,'','185',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(189,'https://sv1.otruyencdn.com/v1/api/chapter/68a43996c705a578a7014b06',1,'','186',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(190,'https://sv1.otruyencdn.com/v1/api/chapter/68a43997c705a578a7014b09',1,'','187',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(191,'https://sv1.otruyencdn.com/v1/api/chapter/68ad5646c705a578a701d378',1,'','188',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(192,'https://sv1.otruyencdn.com/v1/api/chapter/68d1484dc926626890afd70d',1,'','189',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(193,'https://sv1.otruyencdn.com/v1/api/chapter/68d1484fc926626890afd710',1,'','190',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(194,'https://sv1.otruyencdn.com/v1/api/chapter/68d1484fc926626890afd713',1,'','191',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(195,'https://sv1.otruyencdn.com/v1/api/chapter/68d14850c926626890afd716',1,'','192',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(196,'https://sv1.otruyencdn.com/v1/api/chapter/69e61783e0d753f32e5a1129',1,'','193',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(197,'https://sv1.otruyencdn.com/v1/api/chapter/69e61784e0d753f32e5a112c',1,'','194',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(198,'https://sv1.otruyencdn.com/v1/api/chapter/69e61784e0d753f32e5a112f',1,'','195',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(199,'https://sv1.otruyencdn.com/v1/api/chapter/69e61784e0d753f32e5a1132',1,'','196',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(200,'https://sv1.otruyencdn.com/v1/api/chapter/69e61784e0d753f32e5a1135',1,'','197',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(201,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a1138',1,'','198',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(202,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a113b',1,'','199',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(203,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a113e',1,'','200',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(204,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a1141',1,'','201',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(205,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a1144',1,'','202',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(206,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a1147',1,'','203',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(207,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a114a',1,'','204',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(208,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a114d',1,'','205',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(209,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a1150',1,'','206',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(210,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a1153',1,'','207',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(211,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a1156',1,'','208',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(212,'https://sv1.otruyencdn.com/v1/api/chapter/69e61785e0d753f32e5a1159',1,'','209',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(213,'https://sv1.otruyencdn.com/v1/api/chapter/69e61786e0d753f32e5a115c',1,'','210',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(214,'https://sv1.otruyencdn.com/v1/api/chapter/69e61786e0d753f32e5a115f',1,'','211',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(215,'https://sv1.otruyencdn.com/v1/api/chapter/6a2a463a7b89b5b25710e0f7',1,'','212',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517'),
(216,'https://sv1.otruyencdn.com/v1/api/chapter/6a2a463a7b89b5b25710e0fa',1,'','213',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517');
/*!40000 ALTER TABLE `chapter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chapter_page`
--

DROP TABLE IF EXISTS `chapter_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `chapter_page` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `chapter_id` bigint NOT NULL,
  `page_number` int NOT NULL,
  `image_url` varchar(1000) NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chapter_page_number` (`chapter_id`,`page_number`),
  CONSTRAINT `fk_chapter_page_chapter` FOREIGN KEY (`chapter_id`) REFERENCES `chapter` (`id`),
  CONSTRAINT `chk_chapter_page_number` CHECK ((`page_number` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=1072 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chapter_page`
--

LOCK TABLES `chapter_page` WRITE;
/*!40000 ALTER TABLE `chapter_page` DISABLE KEYS */;
INSERT INTO `chapter_page` VALUES
(1,1,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_1.jpg','2026-07-07 08:00:05.115'),
(2,1,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_2.jpg','2026-07-07 08:00:05.115'),
(3,1,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_3.jpg','2026-07-07 08:00:05.115'),
(4,1,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_4.jpg','2026-07-07 08:00:05.115'),
(5,1,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_5.jpg','2026-07-07 08:00:05.115'),
(6,1,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_6.jpg','2026-07-07 08:00:05.115'),
(7,1,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_7.jpg','2026-07-07 08:00:05.115'),
(8,1,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_8.jpg','2026-07-07 08:00:05.115'),
(9,1,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_9.jpg','2026-07-07 08:00:05.115'),
(10,1,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_10.jpg','2026-07-07 08:00:05.115'),
(11,1,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_11.jpg','2026-07-07 08:00:05.115'),
(12,1,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_12.jpg','2026-07-07 08:00:05.115'),
(13,1,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_13.jpg','2026-07-07 08:00:05.115'),
(14,1,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_14.jpg','2026-07-07 08:00:05.115'),
(15,1,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_15.jpg','2026-07-07 08:00:05.115'),
(16,1,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_16.jpg','2026-07-07 08:00:05.115'),
(17,1,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_17.jpg','2026-07-07 08:00:05.115'),
(18,1,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_18.jpg','2026-07-07 08:00:05.115'),
(19,1,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_19.jpg','2026-07-07 08:00:05.115'),
(20,1,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_20.jpg','2026-07-07 08:00:05.115'),
(21,1,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_21.jpg','2026-07-07 08:00:05.115'),
(22,1,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_22.jpg','2026-07-07 08:00:05.115'),
(23,1,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_23.jpg','2026-07-07 08:00:05.115'),
(24,1,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_24.jpg','2026-07-07 08:00:05.115'),
(25,1,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_25.jpg','2026-07-07 08:00:05.115'),
(26,1,26,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_26.jpg','2026-07-07 08:00:05.115'),
(27,1,27,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_27.jpg','2026-07-07 08:00:05.115'),
(28,1,28,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_28.jpg','2026-07-07 08:00:05.115'),
(29,1,29,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_29.jpg','2026-07-07 08:00:05.115'),
(30,1,30,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_30.jpg','2026-07-07 08:00:05.115'),
(31,1,31,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_31.jpg','2026-07-07 08:00:05.115'),
(32,1,32,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_32.jpg','2026-07-07 08:00:05.115'),
(33,1,33,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_33.jpg','2026-07-07 08:00:05.115'),
(34,1,34,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_34.jpg','2026-07-07 08:00:05.115'),
(35,1,35,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_35.jpg','2026-07-07 08:00:05.115'),
(36,1,36,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_36.jpg','2026-07-07 08:00:05.115'),
(37,1,37,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_37.jpg','2026-07-07 08:00:05.115'),
(38,1,38,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_38.jpg','2026-07-07 08:00:05.115'),
(39,1,39,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_39.jpg','2026-07-07 08:00:05.115'),
(40,1,40,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_40.jpg','2026-07-07 08:00:05.115'),
(41,1,41,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_41.jpg','2026-07-07 08:00:05.115'),
(42,1,42,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_42.jpg','2026-07-07 08:00:05.115'),
(43,1,43,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_43.jpg','2026-07-07 08:00:05.115'),
(44,1,44,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_44.jpg','2026-07-07 08:00:05.115'),
(45,1,45,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_45.jpg','2026-07-07 08:00:05.115'),
(46,1,46,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_46.jpg','2026-07-07 08:00:05.115'),
(47,1,47,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_47.jpg','2026-07-07 08:00:05.115'),
(48,1,48,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_48.jpg','2026-07-07 08:00:05.115'),
(49,1,49,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_49.jpg','2026-07-07 08:00:05.115'),
(50,1,50,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_50.jpg','2026-07-07 08:00:05.115'),
(51,1,51,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_51.jpg','2026-07-07 08:00:05.115'),
(52,1,52,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_52.jpg','2026-07-07 08:00:05.115'),
(53,1,53,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_53.jpg','2026-07-07 08:00:05.115'),
(54,1,54,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_54.jpg','2026-07-07 08:00:05.115'),
(55,1,55,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_55.jpg','2026-07-07 08:00:05.115'),
(56,1,56,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_56.jpg','2026-07-07 08:00:05.115'),
(57,1,57,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_57.jpg','2026-07-07 08:00:05.115'),
(58,1,58,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_58.jpg','2026-07-07 08:00:05.115'),
(59,1,59,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_59.jpg','2026-07-07 08:00:05.115'),
(60,1,60,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_60.jpg','2026-07-07 08:00:05.115'),
(61,1,61,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_61.jpg','2026-07-07 08:00:05.115'),
(62,1,62,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_62.jpg','2026-07-07 08:00:05.115'),
(63,1,63,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_63.jpg','2026-07-07 08:00:05.115'),
(64,1,64,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_1/page_64.jpg','2026-07-07 08:00:05.115'),
(65,2,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_1.jpg','2026-07-07 08:00:05.509'),
(66,2,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_2.jpg','2026-07-07 08:00:05.509'),
(67,2,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_3.jpg','2026-07-07 08:00:05.509'),
(68,2,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_4.jpg','2026-07-07 08:00:05.509'),
(69,2,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_5.jpg','2026-07-07 08:00:05.509'),
(70,2,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_6.jpg','2026-07-07 08:00:05.509'),
(71,2,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_7.jpg','2026-07-07 08:00:05.509'),
(72,2,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_8.jpg','2026-07-07 08:00:05.509'),
(73,2,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_9.jpg','2026-07-07 08:00:05.509'),
(74,2,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_10.jpg','2026-07-07 08:00:05.509'),
(75,2,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_11.jpg','2026-07-07 08:00:05.509'),
(76,2,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_12.jpg','2026-07-07 08:00:05.509'),
(77,2,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_13.jpg','2026-07-07 08:00:05.509'),
(78,2,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_14.jpg','2026-07-07 08:00:05.509'),
(79,2,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_15.jpg','2026-07-07 08:00:05.509'),
(80,2,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_16.jpg','2026-07-07 08:00:05.509'),
(81,2,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_17.jpg','2026-07-07 08:00:05.509'),
(82,2,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_18.jpg','2026-07-07 08:00:05.509'),
(83,2,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_19.jpg','2026-07-07 08:00:05.509'),
(84,2,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_20.jpg','2026-07-07 08:00:05.509'),
(85,2,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_21.jpg','2026-07-07 08:00:05.509'),
(86,2,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_22.jpg','2026-07-07 08:00:05.509'),
(87,2,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_23.jpg','2026-07-07 08:00:05.509'),
(88,2,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_24.jpg','2026-07-07 08:00:05.509'),
(89,2,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_25.jpg','2026-07-07 08:00:05.509'),
(90,2,26,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_26.jpg','2026-07-07 08:00:05.509'),
(91,2,27,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_27.jpg','2026-07-07 08:00:05.509'),
(92,2,28,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_28.jpg','2026-07-07 08:00:05.509'),
(93,2,29,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_29.jpg','2026-07-07 08:00:05.509'),
(94,2,30,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_30.jpg','2026-07-07 08:00:05.509'),
(95,2,31,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_31.jpg','2026-07-07 08:00:05.509'),
(96,2,32,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_32.jpg','2026-07-07 08:00:05.509'),
(97,2,33,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_33.jpg','2026-07-07 08:00:05.509'),
(98,2,34,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_34.jpg','2026-07-07 08:00:05.509'),
(99,2,35,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_35.jpg','2026-07-07 08:00:05.509'),
(100,2,36,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_36.jpg','2026-07-07 08:00:05.509'),
(101,2,37,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_37.jpg','2026-07-07 08:00:05.509'),
(102,2,38,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_38.jpg','2026-07-07 08:00:05.509'),
(103,2,39,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_39.jpg','2026-07-07 08:00:05.509'),
(104,2,40,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_40.jpg','2026-07-07 08:00:05.509'),
(105,2,41,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_41.jpg','2026-07-07 08:00:05.509'),
(106,2,42,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_42.jpg','2026-07-07 08:00:05.509'),
(107,2,43,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_43.jpg','2026-07-07 08:00:05.509'),
(108,2,44,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_44.jpg','2026-07-07 08:00:05.509'),
(109,2,45,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_45.jpg','2026-07-07 08:00:05.509'),
(110,2,46,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_46.jpg','2026-07-07 08:00:05.509'),
(111,2,47,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_47.jpg','2026-07-07 08:00:05.509'),
(112,2,48,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_48.jpg','2026-07-07 08:00:05.509'),
(113,2,49,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_49.jpg','2026-07-07 08:00:05.509'),
(114,2,50,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_2/page_50.jpg','2026-07-07 08:00:05.509'),
(115,3,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_1.jpg','2026-07-07 08:00:05.826'),
(116,3,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_2.jpg','2026-07-07 08:00:05.826'),
(117,3,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_3.jpg','2026-07-07 08:00:05.826'),
(118,3,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_4.jpg','2026-07-07 08:00:05.826'),
(119,3,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_5.jpg','2026-07-07 08:00:05.826'),
(120,3,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_6.jpg','2026-07-07 08:00:05.826'),
(121,3,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_7.jpg','2026-07-07 08:00:05.826'),
(122,3,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_8.jpg','2026-07-07 08:00:05.826'),
(123,3,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_9.jpg','2026-07-07 08:00:05.826'),
(124,3,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_10.jpg','2026-07-07 08:00:05.826'),
(125,3,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_11.jpg','2026-07-07 08:00:05.826'),
(126,3,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_12.jpg','2026-07-07 08:00:05.826'),
(127,3,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_13.jpg','2026-07-07 08:00:05.826'),
(128,3,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_14.jpg','2026-07-07 08:00:05.826'),
(129,3,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_15.jpg','2026-07-07 08:00:05.826'),
(130,3,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_16.jpg','2026-07-07 08:00:05.826'),
(131,3,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_17.jpg','2026-07-07 08:00:05.826'),
(132,3,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_18.jpg','2026-07-07 08:00:05.826'),
(133,3,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_19.jpg','2026-07-07 08:00:05.826'),
(134,3,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_20.jpg','2026-07-07 08:00:05.826'),
(135,3,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_21.jpg','2026-07-07 08:00:05.826'),
(136,3,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_22.jpg','2026-07-07 08:00:05.826'),
(137,3,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_23.jpg','2026-07-07 08:00:05.826'),
(138,3,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_24.jpg','2026-07-07 08:00:05.826'),
(139,3,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_25.jpg','2026-07-07 08:00:05.826'),
(140,3,26,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_26.jpg','2026-07-07 08:00:05.826'),
(141,3,27,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_27.jpg','2026-07-07 08:00:05.826'),
(142,3,28,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_28.jpg','2026-07-07 08:00:05.826'),
(143,3,29,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_29.jpg','2026-07-07 08:00:05.826'),
(144,3,30,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_30.jpg','2026-07-07 08:00:05.826'),
(145,3,31,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_31.jpg','2026-07-07 08:00:05.826'),
(146,3,32,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_32.jpg','2026-07-07 08:00:05.826'),
(147,3,33,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_33.jpg','2026-07-07 08:00:05.826'),
(148,3,34,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_34.jpg','2026-07-07 08:00:05.826'),
(149,3,35,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_35.jpg','2026-07-07 08:00:05.826'),
(150,3,36,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_36.jpg','2026-07-07 08:00:05.826'),
(151,3,37,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_37.jpg','2026-07-07 08:00:05.826'),
(152,3,38,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_3/page_38.jpg','2026-07-07 08:00:05.826'),
(153,4,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_1.jpg','2026-07-07 08:00:06.108'),
(154,4,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_2.jpg','2026-07-07 08:00:06.108'),
(155,4,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_3.jpg','2026-07-07 08:00:06.108'),
(156,4,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_4.jpg','2026-07-07 08:00:06.108'),
(157,4,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_5.jpg','2026-07-07 08:00:06.108'),
(158,4,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_6.jpg','2026-07-07 08:00:06.108'),
(159,4,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_7.jpg','2026-07-07 08:00:06.108'),
(160,4,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_8.jpg','2026-07-07 08:00:06.108'),
(161,4,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_9.jpg','2026-07-07 08:00:06.108'),
(162,4,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_10.jpg','2026-07-07 08:00:06.108'),
(163,4,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_11.jpg','2026-07-07 08:00:06.108'),
(164,4,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_12.jpg','2026-07-07 08:00:06.108'),
(165,4,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_13.jpg','2026-07-07 08:00:06.108'),
(166,4,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_14.jpg','2026-07-07 08:00:06.108'),
(167,4,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_15.jpg','2026-07-07 08:00:06.108'),
(168,4,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_16.jpg','2026-07-07 08:00:06.108'),
(169,4,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_17.jpg','2026-07-07 08:00:06.108'),
(170,4,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_18.jpg','2026-07-07 08:00:06.108'),
(171,4,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_19.jpg','2026-07-07 08:00:06.108'),
(172,4,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_20.jpg','2026-07-07 08:00:06.108'),
(173,4,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_21.jpg','2026-07-07 08:00:06.108'),
(174,4,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_22.jpg','2026-07-07 08:00:06.108'),
(175,4,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_23.jpg','2026-07-07 08:00:06.108'),
(176,4,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_24.jpg','2026-07-07 08:00:06.108'),
(177,4,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_4/page_25.jpg','2026-07-07 08:00:06.108'),
(178,5,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_1.jpg','2026-07-07 08:00:06.384'),
(179,5,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_2.jpg','2026-07-07 08:00:06.384'),
(180,5,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_3.jpg','2026-07-07 08:00:06.384'),
(181,5,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_4.jpg','2026-07-07 08:00:06.384'),
(182,5,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_5.jpg','2026-07-07 08:00:06.384'),
(183,5,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_6.jpg','2026-07-07 08:00:06.384'),
(184,5,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_7.jpg','2026-07-07 08:00:06.384'),
(185,5,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_8.jpg','2026-07-07 08:00:06.384'),
(186,5,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_9.jpg','2026-07-07 08:00:06.384'),
(187,5,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_10.jpg','2026-07-07 08:00:06.384'),
(188,5,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_11.jpg','2026-07-07 08:00:06.384'),
(189,5,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_12.jpg','2026-07-07 08:00:06.384'),
(190,5,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_13.jpg','2026-07-07 08:00:06.384'),
(191,5,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_14.jpg','2026-07-07 08:00:06.384'),
(192,5,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_15.jpg','2026-07-07 08:00:06.384'),
(193,5,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_16.jpg','2026-07-07 08:00:06.384'),
(194,5,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_17.jpg','2026-07-07 08:00:06.384'),
(195,5,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_18.jpg','2026-07-07 08:00:06.384'),
(196,5,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_19.jpg','2026-07-07 08:00:06.384'),
(197,5,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_20.jpg','2026-07-07 08:00:06.384'),
(198,5,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_21.jpg','2026-07-07 08:00:06.384'),
(199,5,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_22.jpg','2026-07-07 08:00:06.384'),
(200,5,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_23.jpg','2026-07-07 08:00:06.384'),
(201,5,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_24.jpg','2026-07-07 08:00:06.384'),
(202,5,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_25.jpg','2026-07-07 08:00:06.384'),
(203,5,26,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_26.jpg','2026-07-07 08:00:06.384'),
(204,5,27,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_27.jpg','2026-07-07 08:00:06.384'),
(205,5,28,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_28.jpg','2026-07-07 08:00:06.384'),
(206,5,29,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_29.jpg','2026-07-07 08:00:06.384'),
(207,5,30,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_30.jpg','2026-07-07 08:00:06.384'),
(208,5,31,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_31.jpg','2026-07-07 08:00:06.384'),
(209,5,32,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_5/page_32.jpg','2026-07-07 08:00:06.384'),
(210,6,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_1.jpg','2026-07-07 08:08:04.210'),
(211,6,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_2.jpg','2026-07-07 08:08:04.210'),
(212,6,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_3.jpg','2026-07-07 08:08:04.210'),
(213,6,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_4.jpg','2026-07-07 08:08:04.210'),
(214,6,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_5.jpg','2026-07-07 08:08:04.210'),
(215,6,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_6.jpg','2026-07-07 08:08:04.210'),
(216,6,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_7.jpg','2026-07-07 08:08:04.210'),
(217,6,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_8.jpg','2026-07-07 08:08:04.210'),
(218,6,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_9.jpg','2026-07-07 08:08:04.210'),
(219,6,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_10.jpg','2026-07-07 08:08:04.210'),
(220,6,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_11.jpg','2026-07-07 08:08:04.210'),
(221,6,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_12.jpg','2026-07-07 08:08:04.210'),
(222,6,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_13.jpg','2026-07-07 08:08:04.210'),
(223,6,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_14.jpg','2026-07-07 08:08:04.210'),
(224,6,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_15.jpg','2026-07-07 08:08:04.210'),
(225,6,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_16.jpg','2026-07-07 08:08:04.210'),
(226,6,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_17.jpg','2026-07-07 08:08:04.210'),
(227,6,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_18.jpg','2026-07-07 08:08:04.210'),
(228,6,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_19.jpg','2026-07-07 08:08:04.210'),
(229,6,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_20.jpg','2026-07-07 08:08:04.210'),
(230,6,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_21.jpg','2026-07-07 08:08:04.210'),
(231,6,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_22.jpg','2026-07-07 08:08:04.210'),
(232,6,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_23.jpg','2026-07-07 08:08:04.210'),
(233,6,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_24.jpg','2026-07-07 08:08:04.210'),
(234,6,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_6/page_25.jpg','2026-07-07 08:08:04.210'),
(235,7,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_1.jpg','2026-07-07 08:08:04.500'),
(236,7,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_2.jpg','2026-07-07 08:08:04.500'),
(237,7,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_3.jpg','2026-07-07 08:08:04.500'),
(238,7,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_4.jpg','2026-07-07 08:08:04.500'),
(239,7,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_5.jpg','2026-07-07 08:08:04.500'),
(240,7,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_6.jpg','2026-07-07 08:08:04.500'),
(241,7,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_7.jpg','2026-07-07 08:08:04.500'),
(242,7,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_8.jpg','2026-07-07 08:08:04.500'),
(243,7,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_9.jpg','2026-07-07 08:08:04.500'),
(244,7,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_10.jpg','2026-07-07 08:08:04.500'),
(245,7,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_11.jpg','2026-07-07 08:08:04.500'),
(246,7,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_12.jpg','2026-07-07 08:08:04.500'),
(247,7,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_13.jpg','2026-07-07 08:08:04.500'),
(248,7,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_14.jpg','2026-07-07 08:08:04.500'),
(249,7,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_15.jpg','2026-07-07 08:08:04.500'),
(250,7,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_16.jpg','2026-07-07 08:08:04.500'),
(251,7,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_17.jpg','2026-07-07 08:08:04.500'),
(252,7,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_18.jpg','2026-07-07 08:08:04.500'),
(253,7,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_19.jpg','2026-07-07 08:08:04.500'),
(254,7,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_20.jpg','2026-07-07 08:08:04.500'),
(255,7,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_21.jpg','2026-07-07 08:08:04.500'),
(256,7,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_22.jpg','2026-07-07 08:08:04.500'),
(257,7,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_23.jpg','2026-07-07 08:08:04.500'),
(258,7,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_24.jpg','2026-07-07 08:08:04.500'),
(259,7,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_25.jpg','2026-07-07 08:08:04.500'),
(260,7,26,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_26.jpg','2026-07-07 08:08:04.500'),
(261,7,27,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_7/page_27.jpg','2026-07-07 08:08:04.500'),
(262,8,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_1.jpg','2026-07-07 08:08:04.741'),
(263,8,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_2.jpg','2026-07-07 08:08:04.741'),
(264,8,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_3.jpg','2026-07-07 08:08:04.741'),
(265,8,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_4.jpg','2026-07-07 08:08:04.741'),
(266,8,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_5.jpg','2026-07-07 08:08:04.741'),
(267,8,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_6.jpg','2026-07-07 08:08:04.741'),
(268,8,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_7.jpg','2026-07-07 08:08:04.741'),
(269,8,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_8.jpg','2026-07-07 08:08:04.741'),
(270,8,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_9.jpg','2026-07-07 08:08:04.741'),
(271,8,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_10.jpg','2026-07-07 08:08:04.741'),
(272,8,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_11.jpg','2026-07-07 08:08:04.741'),
(273,8,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_12.jpg','2026-07-07 08:08:04.741'),
(274,8,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_13.jpg','2026-07-07 08:08:04.741'),
(275,8,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_14.jpg','2026-07-07 08:08:04.741'),
(276,8,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_15.jpg','2026-07-07 08:08:04.741'),
(277,8,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_16.jpg','2026-07-07 08:08:04.741'),
(278,8,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_17.jpg','2026-07-07 08:08:04.741'),
(279,8,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_18.jpg','2026-07-07 08:08:04.741'),
(280,8,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_19.jpg','2026-07-07 08:08:04.741'),
(281,8,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_20.jpg','2026-07-07 08:08:04.741'),
(282,8,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_21.jpg','2026-07-07 08:08:04.741'),
(283,8,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_22.jpg','2026-07-07 08:08:04.741'),
(284,8,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_23.jpg','2026-07-07 08:08:04.741'),
(285,8,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_24.jpg','2026-07-07 08:08:04.741'),
(286,8,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_25.jpg','2026-07-07 08:08:04.741'),
(287,8,26,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_26.jpg','2026-07-07 08:08:04.741'),
(288,8,27,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_8/page_27.jpg','2026-07-07 08:08:04.741'),
(289,9,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_1.jpg','2026-07-07 08:08:04.982'),
(290,9,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_2.jpg','2026-07-07 08:08:04.982'),
(291,9,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_3.jpg','2026-07-07 08:08:04.982'),
(292,9,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_4.jpg','2026-07-07 08:08:04.982'),
(293,9,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_5.jpg','2026-07-07 08:08:04.982'),
(294,9,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_6.jpg','2026-07-07 08:08:04.982'),
(295,9,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_7.jpg','2026-07-07 08:08:04.982'),
(296,9,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_8.jpg','2026-07-07 08:08:04.982'),
(297,9,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_9.jpg','2026-07-07 08:08:04.982'),
(298,9,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_10.jpg','2026-07-07 08:08:04.982'),
(299,9,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_11.jpg','2026-07-07 08:08:04.982'),
(300,9,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_12.jpg','2026-07-07 08:08:04.982'),
(301,9,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_13.jpg','2026-07-07 08:08:04.982'),
(302,9,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_14.jpg','2026-07-07 08:08:04.982'),
(303,9,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_15.jpg','2026-07-07 08:08:04.982'),
(304,9,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_16.jpg','2026-07-07 08:08:04.982'),
(305,9,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_17.jpg','2026-07-07 08:08:04.982'),
(306,9,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_18.jpg','2026-07-07 08:08:04.982'),
(307,9,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_19.jpg','2026-07-07 08:08:04.982'),
(308,9,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_20.jpg','2026-07-07 08:08:04.982'),
(309,9,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_21.jpg','2026-07-07 08:08:04.982'),
(310,9,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_22.jpg','2026-07-07 08:08:04.982'),
(311,9,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_23.jpg','2026-07-07 08:08:04.982'),
(312,9,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_24.jpg','2026-07-07 08:08:04.982'),
(313,9,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_25.jpg','2026-07-07 08:08:04.982'),
(314,9,26,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_9/page_26.jpg','2026-07-07 08:08:04.982'),
(315,10,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_1.jpg','2026-07-07 08:08:05.243'),
(316,10,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_2.jpg','2026-07-07 08:08:05.243'),
(317,10,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_3.jpg','2026-07-07 08:08:05.243'),
(318,10,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_4.jpg','2026-07-07 08:08:05.243'),
(319,10,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_5.jpg','2026-07-07 08:08:05.243'),
(320,10,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_6.jpg','2026-07-07 08:08:05.243'),
(321,10,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_7.jpg','2026-07-07 08:08:05.243'),
(322,10,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_8.jpg','2026-07-07 08:08:05.243'),
(323,10,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_9.jpg','2026-07-07 08:08:05.243'),
(324,10,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_10.jpg','2026-07-07 08:08:05.243'),
(325,10,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_11.jpg','2026-07-07 08:08:05.243'),
(326,10,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_12.jpg','2026-07-07 08:08:05.243'),
(327,10,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_13.jpg','2026-07-07 08:08:05.243'),
(328,10,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_14.jpg','2026-07-07 08:08:05.243'),
(329,10,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_15.jpg','2026-07-07 08:08:05.243'),
(330,10,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_16.jpg','2026-07-07 08:08:05.243'),
(331,10,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_17.jpg','2026-07-07 08:08:05.243'),
(332,10,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_18.jpg','2026-07-07 08:08:05.243'),
(333,10,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_19.jpg','2026-07-07 08:08:05.243'),
(334,10,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_20.jpg','2026-07-07 08:08:05.243'),
(335,10,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_21.jpg','2026-07-07 08:08:05.243'),
(336,10,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_22.jpg','2026-07-07 08:08:05.243'),
(337,10,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_23.jpg','2026-07-07 08:08:05.243'),
(338,10,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_24.jpg','2026-07-07 08:08:05.243'),
(339,10,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_25.jpg','2026-07-07 08:08:05.243'),
(340,10,26,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_26.jpg','2026-07-07 08:08:05.243'),
(341,10,27,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_10/page_27.jpg','2026-07-07 08:08:05.243'),
(342,11,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_1.jpg','2026-07-07 08:16:10.417'),
(343,11,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_2.jpg','2026-07-07 08:16:10.417'),
(344,11,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_3.jpg','2026-07-07 08:16:10.417'),
(345,11,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_4.jpg','2026-07-07 08:16:10.417'),
(346,11,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_5.jpg','2026-07-07 08:16:10.417'),
(347,11,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_6.jpg','2026-07-07 08:16:10.417'),
(348,11,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_7.jpg','2026-07-07 08:16:10.417'),
(349,11,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_8.jpg','2026-07-07 08:16:10.417'),
(350,11,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_9.jpg','2026-07-07 08:16:10.417'),
(351,11,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_10.jpg','2026-07-07 08:16:10.417'),
(352,11,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_11.jpg','2026-07-07 08:16:10.417'),
(353,11,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_12.jpg','2026-07-07 08:16:10.417'),
(354,11,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_13.jpg','2026-07-07 08:16:10.417'),
(355,11,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_14.jpg','2026-07-07 08:16:10.417'),
(356,11,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_15.jpg','2026-07-07 08:16:10.417'),
(357,11,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_16.jpg','2026-07-07 08:16:10.417'),
(358,11,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_17.jpg','2026-07-07 08:16:10.417'),
(359,11,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_18.jpg','2026-07-07 08:16:10.417'),
(360,11,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_19.jpg','2026-07-07 08:16:10.417'),
(361,11,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_20.jpg','2026-07-07 08:16:10.417'),
(362,11,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_21.jpg','2026-07-07 08:16:10.417'),
(363,11,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_22.jpg','2026-07-07 08:16:10.417'),
(364,11,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_23.jpg','2026-07-07 08:16:10.417'),
(365,11,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_24.jpg','2026-07-07 08:16:10.417'),
(366,11,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_11/page_25.jpg','2026-07-07 08:16:10.417'),
(367,12,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_1.jpg','2026-07-07 08:16:10.658'),
(368,12,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_2.jpg','2026-07-07 08:16:10.658'),
(369,12,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_3.jpg','2026-07-07 08:16:10.658'),
(370,12,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_4.jpg','2026-07-07 08:16:10.658'),
(371,12,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_5.jpg','2026-07-07 08:16:10.658'),
(372,12,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_6.jpg','2026-07-07 08:16:10.658'),
(373,12,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_7.jpg','2026-07-07 08:16:10.658'),
(374,12,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_8.jpg','2026-07-07 08:16:10.658'),
(375,12,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_9.jpg','2026-07-07 08:16:10.658'),
(376,12,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_10.jpg','2026-07-07 08:16:10.658'),
(377,12,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_11.jpg','2026-07-07 08:16:10.658'),
(378,12,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_12.jpg','2026-07-07 08:16:10.658'),
(379,12,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_13.jpg','2026-07-07 08:16:10.658'),
(380,12,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_14.jpg','2026-07-07 08:16:10.658'),
(381,12,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_15.jpg','2026-07-07 08:16:10.658'),
(382,12,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_16.jpg','2026-07-07 08:16:10.658'),
(383,12,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_17.jpg','2026-07-07 08:16:10.658'),
(384,12,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_18.jpg','2026-07-07 08:16:10.658'),
(385,12,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_19.jpg','2026-07-07 08:16:10.658'),
(386,12,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_20.jpg','2026-07-07 08:16:10.658'),
(387,12,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_21.jpg','2026-07-07 08:16:10.658'),
(388,12,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_22.jpg','2026-07-07 08:16:10.658'),
(389,12,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_23.jpg','2026-07-07 08:16:10.658'),
(390,12,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_12/page_24.jpg','2026-07-07 08:16:10.658'),
(391,13,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_1.jpg','2026-07-07 08:16:10.933'),
(392,13,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_2.jpg','2026-07-07 08:16:10.933'),
(393,13,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_3.jpg','2026-07-07 08:16:10.933'),
(394,13,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_4.jpg','2026-07-07 08:16:10.933'),
(395,13,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_5.jpg','2026-07-07 08:16:10.933'),
(396,13,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_6.jpg','2026-07-07 08:16:10.933'),
(397,13,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_7.jpg','2026-07-07 08:16:10.933'),
(398,13,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_8.jpg','2026-07-07 08:16:10.933'),
(399,13,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_9.jpg','2026-07-07 08:16:10.933'),
(400,13,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_10.jpg','2026-07-07 08:16:10.933'),
(401,13,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_11.jpg','2026-07-07 08:16:10.933'),
(402,13,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_12.jpg','2026-07-07 08:16:10.933'),
(403,13,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_13.jpg','2026-07-07 08:16:10.933'),
(404,13,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_14.jpg','2026-07-07 08:16:10.933'),
(405,13,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_15.jpg','2026-07-07 08:16:10.933'),
(406,13,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_16.jpg','2026-07-07 08:16:10.933'),
(407,13,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_17.jpg','2026-07-07 08:16:10.933'),
(408,13,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_18.jpg','2026-07-07 08:16:10.933'),
(409,13,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_19.jpg','2026-07-07 08:16:10.933'),
(410,13,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_20.jpg','2026-07-07 08:16:10.933'),
(411,13,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_21.jpg','2026-07-07 08:16:10.933'),
(412,13,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_22.jpg','2026-07-07 08:16:10.933'),
(413,13,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_23.jpg','2026-07-07 08:16:10.933'),
(414,13,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_13/page_24.jpg','2026-07-07 08:16:10.933'),
(415,14,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_1.jpg','2026-07-07 08:16:11.191'),
(416,14,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_2.jpg','2026-07-07 08:16:11.191'),
(417,14,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_3.jpg','2026-07-07 08:16:11.191'),
(418,14,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_4.jpg','2026-07-07 08:16:11.191'),
(419,14,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_5.jpg','2026-07-07 08:16:11.191'),
(420,14,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_6.jpg','2026-07-07 08:16:11.191'),
(421,14,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_7.jpg','2026-07-07 08:16:11.191'),
(422,14,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_8.jpg','2026-07-07 08:16:11.191'),
(423,14,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_9.jpg','2026-07-07 08:16:11.191'),
(424,14,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_10.jpg','2026-07-07 08:16:11.191'),
(425,14,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_11.jpg','2026-07-07 08:16:11.191'),
(426,14,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_12.jpg','2026-07-07 08:16:11.191'),
(427,14,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_13.jpg','2026-07-07 08:16:11.191'),
(428,14,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_14.jpg','2026-07-07 08:16:11.191'),
(429,14,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_15.jpg','2026-07-07 08:16:11.191'),
(430,14,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_16.jpg','2026-07-07 08:16:11.191'),
(431,14,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_17.jpg','2026-07-07 08:16:11.191'),
(432,14,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_18.jpg','2026-07-07 08:16:11.191'),
(433,14,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_19.jpg','2026-07-07 08:16:11.191'),
(434,14,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_20.jpg','2026-07-07 08:16:11.191'),
(435,14,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14/page_21.jpg','2026-07-07 08:16:11.191'),
(436,15,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14.5/page_1.jpg','2026-07-07 08:16:11.448'),
(437,15,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14.5/page_2.jpg','2026-07-07 08:16:11.448'),
(438,15,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14.5/page_3.jpg','2026-07-07 08:16:11.448'),
(439,15,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14.5/page_4.jpg','2026-07-07 08:16:11.448'),
(440,15,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14.5/page_5.jpg','2026-07-07 08:16:11.448'),
(441,15,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14.5/page_6.jpg','2026-07-07 08:16:11.448'),
(442,15,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14.5/page_7.jpg','2026-07-07 08:16:11.448'),
(443,15,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14.5/page_8.jpg','2026-07-07 08:16:11.448'),
(444,15,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_14.5/page_9.jpg','2026-07-07 08:16:11.448'),
(445,16,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_1.jpg','2026-07-07 08:24:03.636'),
(446,16,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_2.jpg','2026-07-07 08:24:03.636'),
(447,16,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_3.jpg','2026-07-07 08:24:03.636'),
(448,16,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_4.jpg','2026-07-07 08:24:03.636'),
(449,16,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_5.jpg','2026-07-07 08:24:03.636'),
(450,16,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_6.jpg','2026-07-07 08:24:03.636'),
(451,16,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_7.jpg','2026-07-07 08:24:03.636'),
(452,16,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_8.jpg','2026-07-07 08:24:03.636'),
(453,16,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_9.jpg','2026-07-07 08:24:03.636'),
(454,16,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_10.jpg','2026-07-07 08:24:03.636'),
(455,16,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_11.jpg','2026-07-07 08:24:03.636'),
(456,16,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_12.jpg','2026-07-07 08:24:03.636'),
(457,16,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_13.jpg','2026-07-07 08:24:03.636'),
(458,16,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_14.jpg','2026-07-07 08:24:03.636'),
(459,16,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_15.jpg','2026-07-07 08:24:03.636'),
(460,16,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_16.jpg','2026-07-07 08:24:03.636'),
(461,16,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_17.jpg','2026-07-07 08:24:03.636'),
(462,16,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_18.jpg','2026-07-07 08:24:03.636'),
(463,16,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_19.jpg','2026-07-07 08:24:03.636'),
(464,16,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_20.jpg','2026-07-07 08:24:03.636'),
(465,16,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_21.jpg','2026-07-07 08:24:03.636'),
(466,16,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_22.jpg','2026-07-07 08:24:03.636'),
(467,16,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_23.jpg','2026-07-07 08:24:03.636'),
(468,16,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_24.jpg','2026-07-07 08:24:03.636'),
(469,16,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_25.jpg','2026-07-07 08:24:03.636'),
(470,16,26,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_26.jpg','2026-07-07 08:24:03.636'),
(471,16,27,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_15/page_27.jpg','2026-07-07 08:24:03.636'),
(472,17,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_1.jpg','2026-07-07 08:24:03.895'),
(473,17,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_2.jpg','2026-07-07 08:24:03.895'),
(474,17,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_3.jpg','2026-07-07 08:24:03.895'),
(475,17,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_4.jpg','2026-07-07 08:24:03.895'),
(476,17,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_5.jpg','2026-07-07 08:24:03.895'),
(477,17,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_6.jpg','2026-07-07 08:24:03.895'),
(478,17,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_7.jpg','2026-07-07 08:24:03.895'),
(479,17,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_8.jpg','2026-07-07 08:24:03.895'),
(480,17,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_9.jpg','2026-07-07 08:24:03.895'),
(481,17,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_10.jpg','2026-07-07 08:24:03.895'),
(482,17,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_11.jpg','2026-07-07 08:24:03.895'),
(483,17,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_12.jpg','2026-07-07 08:24:03.895'),
(484,17,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_13.jpg','2026-07-07 08:24:03.895'),
(485,17,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_14.jpg','2026-07-07 08:24:03.895'),
(486,17,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_15.jpg','2026-07-07 08:24:03.895'),
(487,17,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_16.jpg','2026-07-07 08:24:03.895'),
(488,17,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_17.jpg','2026-07-07 08:24:03.895'),
(489,17,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_18.jpg','2026-07-07 08:24:03.895'),
(490,17,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_19.jpg','2026-07-07 08:24:03.895'),
(491,17,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_20.jpg','2026-07-07 08:24:03.895'),
(492,17,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_21.jpg','2026-07-07 08:24:03.895'),
(493,17,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_22.jpg','2026-07-07 08:24:03.895'),
(494,17,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_23.jpg','2026-07-07 08:24:03.895'),
(495,17,24,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_24.jpg','2026-07-07 08:24:03.895'),
(496,17,25,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_16/page_25.jpg','2026-07-07 08:24:03.895'),
(497,18,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_1.jpg','2026-07-07 08:24:04.151'),
(498,18,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_2.jpg','2026-07-07 08:24:04.151'),
(499,18,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_3.jpg','2026-07-07 08:24:04.151'),
(500,18,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_4.jpg','2026-07-07 08:24:04.151'),
(501,18,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_5.jpg','2026-07-07 08:24:04.151'),
(502,18,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_6.jpg','2026-07-07 08:24:04.151'),
(503,18,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_7.jpg','2026-07-07 08:24:04.151'),
(504,18,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_8.jpg','2026-07-07 08:24:04.151'),
(505,18,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_9.jpg','2026-07-07 08:24:04.151'),
(506,18,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_10.jpg','2026-07-07 08:24:04.151'),
(507,18,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_11.jpg','2026-07-07 08:24:04.151'),
(508,18,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_12.jpg','2026-07-07 08:24:04.151'),
(509,18,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_13.jpg','2026-07-07 08:24:04.151'),
(510,18,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_14.jpg','2026-07-07 08:24:04.151'),
(511,18,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_15.jpg','2026-07-07 08:24:04.151'),
(512,18,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_16.jpg','2026-07-07 08:24:04.151'),
(513,18,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_17.jpg','2026-07-07 08:24:04.151'),
(514,18,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_18.jpg','2026-07-07 08:24:04.151'),
(515,18,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_19.jpg','2026-07-07 08:24:04.151'),
(516,18,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_20.jpg','2026-07-07 08:24:04.151'),
(517,18,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_21.jpg','2026-07-07 08:24:04.151'),
(518,18,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_22.jpg','2026-07-07 08:24:04.151'),
(519,18,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_17/page_23.jpg','2026-07-07 08:24:04.151'),
(520,19,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_1.jpg','2026-07-07 08:24:04.405'),
(521,19,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_2.jpg','2026-07-07 08:24:04.405'),
(522,19,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_3.jpg','2026-07-07 08:24:04.405'),
(523,19,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_4.jpg','2026-07-07 08:24:04.405'),
(524,19,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_5.jpg','2026-07-07 08:24:04.405'),
(525,19,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_6.jpg','2026-07-07 08:24:04.405'),
(526,19,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_7.jpg','2026-07-07 08:24:04.405'),
(527,19,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_8.jpg','2026-07-07 08:24:04.405'),
(528,19,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_9.jpg','2026-07-07 08:24:04.405'),
(529,19,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_10.jpg','2026-07-07 08:24:04.405'),
(530,19,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_11.jpg','2026-07-07 08:24:04.405'),
(531,19,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_12.jpg','2026-07-07 08:24:04.405'),
(532,19,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_13.jpg','2026-07-07 08:24:04.405'),
(533,19,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_14.jpg','2026-07-07 08:24:04.405'),
(534,19,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_15.jpg','2026-07-07 08:24:04.405'),
(535,19,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_16.jpg','2026-07-07 08:24:04.405'),
(536,19,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_17.jpg','2026-07-07 08:24:04.405'),
(537,19,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_18.jpg','2026-07-07 08:24:04.405'),
(538,19,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_18/page_19.jpg','2026-07-07 08:24:04.405'),
(539,20,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_1.jpg','2026-07-07 08:24:04.654'),
(540,20,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_2.jpg','2026-07-07 08:24:04.654'),
(541,20,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_3.jpg','2026-07-07 08:24:04.654'),
(542,20,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_4.jpg','2026-07-07 08:24:04.654'),
(543,20,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_5.jpg','2026-07-07 08:24:04.654'),
(544,20,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_6.jpg','2026-07-07 08:24:04.654'),
(545,20,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_7.jpg','2026-07-07 08:24:04.654'),
(546,20,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_8.jpg','2026-07-07 08:24:04.654'),
(547,20,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_9.jpg','2026-07-07 08:24:04.654'),
(548,20,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_10.jpg','2026-07-07 08:24:04.654'),
(549,20,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_11.jpg','2026-07-07 08:24:04.654'),
(550,20,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_12.jpg','2026-07-07 08:24:04.654'),
(551,20,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_13.jpg','2026-07-07 08:24:04.654'),
(552,20,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_14.jpg','2026-07-07 08:24:04.654'),
(553,20,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_15.jpg','2026-07-07 08:24:04.654'),
(554,20,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_16.jpg','2026-07-07 08:24:04.654'),
(555,20,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_17.jpg','2026-07-07 08:24:04.654'),
(556,20,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_18.jpg','2026-07-07 08:24:04.654'),
(557,20,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_19.jpg','2026-07-07 08:24:04.654'),
(558,20,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_20.jpg','2026-07-07 08:24:04.654'),
(559,20,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_19/page_21.jpg','2026-07-07 08:24:04.654'),
(560,21,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_1.jpg','2026-07-07 09:24:04.238'),
(561,21,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_2.jpg','2026-07-07 09:24:04.238'),
(562,21,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_3.jpg','2026-07-07 09:24:04.238'),
(563,21,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_4.jpg','2026-07-07 09:24:04.238'),
(564,21,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_5.jpg','2026-07-07 09:24:04.238'),
(565,21,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_6.jpg','2026-07-07 09:24:04.238'),
(566,21,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_7.jpg','2026-07-07 09:24:04.238'),
(567,21,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_8.jpg','2026-07-07 09:24:04.238'),
(568,21,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_9.jpg','2026-07-07 09:24:04.238'),
(569,21,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_10.jpg','2026-07-07 09:24:04.238'),
(570,21,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_11.jpg','2026-07-07 09:24:04.238'),
(571,21,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_12.jpg','2026-07-07 09:24:04.238'),
(572,21,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_13.jpg','2026-07-07 09:24:04.238'),
(573,21,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_14.jpg','2026-07-07 09:24:04.238'),
(574,21,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_15.jpg','2026-07-07 09:24:04.238'),
(575,21,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_16.jpg','2026-07-07 09:24:04.238'),
(576,21,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_17.jpg','2026-07-07 09:24:04.238'),
(577,21,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_18.jpg','2026-07-07 09:24:04.238'),
(578,21,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_20/page_19.jpg','2026-07-07 09:24:04.238'),
(579,22,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_1.jpg','2026-07-07 09:24:05.536'),
(580,22,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_2.jpg','2026-07-07 09:24:05.536'),
(581,22,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_3.jpg','2026-07-07 09:24:05.536'),
(582,22,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_4.jpg','2026-07-07 09:24:05.536'),
(583,22,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_5.jpg','2026-07-07 09:24:05.536'),
(584,22,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_6.jpg','2026-07-07 09:24:05.536'),
(585,22,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_7.jpg','2026-07-07 09:24:05.536'),
(586,22,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_8.jpg','2026-07-07 09:24:05.536'),
(587,22,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_9.jpg','2026-07-07 09:24:05.536'),
(588,22,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_10.jpg','2026-07-07 09:24:05.536'),
(589,22,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_11.jpg','2026-07-07 09:24:05.536'),
(590,22,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_12.jpg','2026-07-07 09:24:05.536'),
(591,22,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_13.jpg','2026-07-07 09:24:05.536'),
(592,22,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_14.jpg','2026-07-07 09:24:05.536'),
(593,22,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_15.jpg','2026-07-07 09:24:05.536'),
(594,22,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_16.jpg','2026-07-07 09:24:05.536'),
(595,22,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_17.jpg','2026-07-07 09:24:05.536'),
(596,22,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_21/page_18.jpg','2026-07-07 09:24:05.536'),
(597,23,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_1.jpg','2026-07-07 09:24:05.788'),
(598,23,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_2.jpg','2026-07-07 09:24:05.788'),
(599,23,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_3.jpg','2026-07-07 09:24:05.788'),
(600,23,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_4.jpg','2026-07-07 09:24:05.788'),
(601,23,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_5.jpg','2026-07-07 09:24:05.788'),
(602,23,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_6.jpg','2026-07-07 09:24:05.788'),
(603,23,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_7.jpg','2026-07-07 09:24:05.788'),
(604,23,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_8.jpg','2026-07-07 09:24:05.788'),
(605,23,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_9.jpg','2026-07-07 09:24:05.788'),
(606,23,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_10.jpg','2026-07-07 09:24:05.788'),
(607,23,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_11.jpg','2026-07-07 09:24:05.788'),
(608,23,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_12.jpg','2026-07-07 09:24:05.788'),
(609,23,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_13.jpg','2026-07-07 09:24:05.788'),
(610,23,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_14.jpg','2026-07-07 09:24:05.788'),
(611,23,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_15.jpg','2026-07-07 09:24:05.788'),
(612,23,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_16.jpg','2026-07-07 09:24:05.788'),
(613,23,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_17.jpg','2026-07-07 09:24:05.788'),
(614,23,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_18.jpg','2026-07-07 09:24:05.788'),
(615,23,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_19.jpg','2026-07-07 09:24:05.788'),
(616,23,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_22/page_20.jpg','2026-07-07 09:24:05.788'),
(617,24,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_1.jpg','2026-07-07 09:24:06.830'),
(618,24,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_2.jpg','2026-07-07 09:24:06.830'),
(619,24,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_3.jpg','2026-07-07 09:24:06.830'),
(620,24,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_4.jpg','2026-07-07 09:24:06.830'),
(621,24,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_5.jpg','2026-07-07 09:24:06.830'),
(622,24,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_6.jpg','2026-07-07 09:24:06.830'),
(623,24,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_7.jpg','2026-07-07 09:24:06.830'),
(624,24,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_8.jpg','2026-07-07 09:24:06.830'),
(625,24,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_9.jpg','2026-07-07 09:24:06.830'),
(626,24,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_10.jpg','2026-07-07 09:24:06.830'),
(627,24,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_11.jpg','2026-07-07 09:24:06.830'),
(628,24,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_12.jpg','2026-07-07 09:24:06.830'),
(629,24,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_13.jpg','2026-07-07 09:24:06.830'),
(630,24,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_14.jpg','2026-07-07 09:24:06.830'),
(631,24,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_15.jpg','2026-07-07 09:24:06.830'),
(632,24,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_16.jpg','2026-07-07 09:24:06.830'),
(633,24,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_17.jpg','2026-07-07 09:24:06.830'),
(634,24,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_23/page_18.jpg','2026-07-07 09:24:06.830'),
(635,25,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_1.jpg','2026-07-07 09:24:18.384'),
(636,25,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_2.jpg','2026-07-07 09:24:18.384'),
(637,25,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_3.jpg','2026-07-07 09:24:18.384'),
(638,25,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_4.jpg','2026-07-07 09:24:18.384'),
(639,25,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_5.jpg','2026-07-07 09:24:18.384'),
(640,25,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_6.jpg','2026-07-07 09:24:18.384'),
(641,25,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_7.jpg','2026-07-07 09:24:18.384'),
(642,25,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_8.jpg','2026-07-07 09:24:18.384'),
(643,25,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_9.jpg','2026-07-07 09:24:18.384'),
(644,25,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_10.jpg','2026-07-07 09:24:18.384'),
(645,25,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_11.jpg','2026-07-07 09:24:18.384'),
(646,25,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_12.jpg','2026-07-07 09:24:18.384'),
(647,25,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_13.jpg','2026-07-07 09:24:18.384'),
(648,25,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_14.jpg','2026-07-07 09:24:18.384'),
(649,25,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_15.jpg','2026-07-07 09:24:18.384'),
(650,25,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_16.jpg','2026-07-07 09:24:18.384'),
(651,25,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_17.jpg','2026-07-07 09:24:18.384'),
(652,25,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_18.jpg','2026-07-07 09:24:18.384'),
(653,25,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_19.jpg','2026-07-07 09:24:18.384'),
(654,25,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_24/page_20.jpg','2026-07-07 09:24:18.384'),
(655,26,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_1.jpg','2026-07-07 09:32:05.303'),
(656,26,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_2.jpg','2026-07-07 09:32:05.303'),
(657,26,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_3.jpg','2026-07-07 09:32:05.303'),
(658,26,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_4.jpg','2026-07-07 09:32:05.303'),
(659,26,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_5.jpg','2026-07-07 09:32:05.303'),
(660,26,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_6.jpg','2026-07-07 09:32:05.303'),
(661,26,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_7.jpg','2026-07-07 09:32:05.303'),
(662,26,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_8.jpg','2026-07-07 09:32:05.303'),
(663,26,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_9.jpg','2026-07-07 09:32:05.303'),
(664,26,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_10.jpg','2026-07-07 09:32:05.303'),
(665,26,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_11.jpg','2026-07-07 09:32:05.303'),
(666,26,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_12.jpg','2026-07-07 09:32:05.303'),
(667,26,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_13.jpg','2026-07-07 09:32:05.303'),
(668,26,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_14.jpg','2026-07-07 09:32:05.303'),
(669,26,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_15.jpg','2026-07-07 09:32:05.303'),
(670,26,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_16.jpg','2026-07-07 09:32:05.303'),
(671,26,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_17.jpg','2026-07-07 09:32:05.303'),
(672,26,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_18.jpg','2026-07-07 09:32:05.303'),
(673,26,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_19.jpg','2026-07-07 09:32:05.303'),
(674,26,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_20.jpg','2026-07-07 09:32:05.303'),
(675,26,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_25/page_21.jpg','2026-07-07 09:32:05.303'),
(676,27,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_1.jpg','2026-07-07 09:32:05.583'),
(677,27,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_2.jpg','2026-07-07 09:32:05.583'),
(678,27,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_3.jpg','2026-07-07 09:32:05.583'),
(679,27,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_4.jpg','2026-07-07 09:32:05.583'),
(680,27,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_5.jpg','2026-07-07 09:32:05.583'),
(681,27,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_6.jpg','2026-07-07 09:32:05.583'),
(682,27,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_7.jpg','2026-07-07 09:32:05.583'),
(683,27,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_8.jpg','2026-07-07 09:32:05.583'),
(684,27,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_9.jpg','2026-07-07 09:32:05.583'),
(685,27,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_10.jpg','2026-07-07 09:32:05.583'),
(686,27,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_11.jpg','2026-07-07 09:32:05.583'),
(687,27,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_12.jpg','2026-07-07 09:32:05.583'),
(688,27,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_13.jpg','2026-07-07 09:32:05.583'),
(689,27,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_14.jpg','2026-07-07 09:32:05.583'),
(690,27,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_15.jpg','2026-07-07 09:32:05.583'),
(691,27,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_16.jpg','2026-07-07 09:32:05.583'),
(692,27,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_17.jpg','2026-07-07 09:32:05.583'),
(693,27,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_18.jpg','2026-07-07 09:32:05.583'),
(694,27,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_19.jpg','2026-07-07 09:32:05.583'),
(695,27,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_20.jpg','2026-07-07 09:32:05.583'),
(696,27,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_21.jpg','2026-07-07 09:32:05.583'),
(697,27,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_26/page_22.jpg','2026-07-07 09:32:05.583'),
(698,28,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_1.jpg','2026-07-07 09:32:05.881'),
(699,28,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_2.jpg','2026-07-07 09:32:05.881'),
(700,28,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_3.jpg','2026-07-07 09:32:05.881'),
(701,28,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_4.jpg','2026-07-07 09:32:05.881'),
(702,28,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_5.jpg','2026-07-07 09:32:05.881'),
(703,28,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_6.jpg','2026-07-07 09:32:05.881'),
(704,28,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_7.jpg','2026-07-07 09:32:05.881'),
(705,28,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_8.jpg','2026-07-07 09:32:05.881'),
(706,28,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_9.jpg','2026-07-07 09:32:05.881'),
(707,28,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_10.jpg','2026-07-07 09:32:05.881'),
(708,28,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_11.jpg','2026-07-07 09:32:05.881'),
(709,28,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_12.jpg','2026-07-07 09:32:05.881'),
(710,28,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_13.jpg','2026-07-07 09:32:05.881'),
(711,28,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_14.jpg','2026-07-07 09:32:05.881'),
(712,28,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_15.jpg','2026-07-07 09:32:05.881'),
(713,28,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_16.jpg','2026-07-07 09:32:05.881'),
(714,28,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_17.jpg','2026-07-07 09:32:05.881'),
(715,28,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_18.jpg','2026-07-07 09:32:05.881'),
(716,28,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_19.jpg','2026-07-07 09:32:05.881'),
(717,28,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_20.jpg','2026-07-07 09:32:05.881'),
(718,28,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_27/page_21.jpg','2026-07-07 09:32:05.881'),
(719,29,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_1.jpg','2026-07-07 09:32:06.178'),
(720,29,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_2.jpg','2026-07-07 09:32:06.178'),
(721,29,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_3.jpg','2026-07-07 09:32:06.178'),
(722,29,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_4.jpg','2026-07-07 09:32:06.178'),
(723,29,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_5.jpg','2026-07-07 09:32:06.178'),
(724,29,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_6.jpg','2026-07-07 09:32:06.178'),
(725,29,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_7.jpg','2026-07-07 09:32:06.178'),
(726,29,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_8.jpg','2026-07-07 09:32:06.178'),
(727,29,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_9.jpg','2026-07-07 09:32:06.178'),
(728,29,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_10.jpg','2026-07-07 09:32:06.178'),
(729,29,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_11.jpg','2026-07-07 09:32:06.178'),
(730,29,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_12.jpg','2026-07-07 09:32:06.178'),
(731,29,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_13.jpg','2026-07-07 09:32:06.178'),
(732,29,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_14.jpg','2026-07-07 09:32:06.178'),
(733,29,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_15.jpg','2026-07-07 09:32:06.178'),
(734,29,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_16.jpg','2026-07-07 09:32:06.178'),
(735,29,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_17.jpg','2026-07-07 09:32:06.178'),
(736,29,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_28/page_18.jpg','2026-07-07 09:32:06.178'),
(737,30,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_1.jpg','2026-07-07 09:32:06.449'),
(738,30,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_2.jpg','2026-07-07 09:32:06.449'),
(739,30,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_3.jpg','2026-07-07 09:32:06.449'),
(740,30,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_4.jpg','2026-07-07 09:32:06.449'),
(741,30,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_5.jpg','2026-07-07 09:32:06.449'),
(742,30,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_6.jpg','2026-07-07 09:32:06.449'),
(743,30,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_7.jpg','2026-07-07 09:32:06.449'),
(744,30,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_8.jpg','2026-07-07 09:32:06.449'),
(745,30,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_9.jpg','2026-07-07 09:32:06.449'),
(746,30,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_10.jpg','2026-07-07 09:32:06.449'),
(747,30,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_11.jpg','2026-07-07 09:32:06.449'),
(748,30,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_12.jpg','2026-07-07 09:32:06.449'),
(749,30,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_13.jpg','2026-07-07 09:32:06.449'),
(750,30,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_14.jpg','2026-07-07 09:32:06.449'),
(751,30,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_15.jpg','2026-07-07 09:32:06.449'),
(752,30,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_16.jpg','2026-07-07 09:32:06.449'),
(753,30,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_17.jpg','2026-07-07 09:32:06.449'),
(754,30,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_18.jpg','2026-07-07 09:32:06.449'),
(755,30,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_19.jpg','2026-07-07 09:32:06.449'),
(756,30,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_29/page_20.jpg','2026-07-07 09:32:06.449'),
(757,31,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_1.jpg','2026-07-07 09:40:06.252'),
(758,31,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_2.jpg','2026-07-07 09:40:06.252'),
(759,31,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_3.jpg','2026-07-07 09:40:06.252'),
(760,31,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_4.jpg','2026-07-07 09:40:06.252'),
(761,31,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_5.jpg','2026-07-07 09:40:06.252'),
(762,31,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_6.jpg','2026-07-07 09:40:06.252'),
(763,31,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_7.jpg','2026-07-07 09:40:06.252'),
(764,31,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_8.jpg','2026-07-07 09:40:06.252'),
(765,31,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_9.jpg','2026-07-07 09:40:06.252'),
(766,31,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_10.jpg','2026-07-07 09:40:06.252'),
(767,31,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_11.jpg','2026-07-07 09:40:06.252'),
(768,31,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_12.jpg','2026-07-07 09:40:06.252'),
(769,31,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_13.jpg','2026-07-07 09:40:06.252'),
(770,31,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_14.jpg','2026-07-07 09:40:06.252'),
(771,31,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_15.jpg','2026-07-07 09:40:06.252'),
(772,31,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_16.jpg','2026-07-07 09:40:06.252'),
(773,31,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_17.jpg','2026-07-07 09:40:06.252'),
(774,31,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_18.jpg','2026-07-07 09:40:06.252'),
(775,31,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_19.jpg','2026-07-07 09:40:06.252'),
(776,31,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_30/page_20.jpg','2026-07-07 09:40:06.252'),
(777,32,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_1.jpg','2026-07-07 09:40:06.517'),
(778,32,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_2.jpg','2026-07-07 09:40:06.517'),
(779,32,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_3.jpg','2026-07-07 09:40:06.517'),
(780,32,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_4.jpg','2026-07-07 09:40:06.517'),
(781,32,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_5.jpg','2026-07-07 09:40:06.517'),
(782,32,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_6.jpg','2026-07-07 09:40:06.517'),
(783,32,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_7.jpg','2026-07-07 09:40:06.517'),
(784,32,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_8.jpg','2026-07-07 09:40:06.517'),
(785,32,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_9.jpg','2026-07-07 09:40:06.517'),
(786,32,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_10.jpg','2026-07-07 09:40:06.517'),
(787,32,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_11.jpg','2026-07-07 09:40:06.517'),
(788,32,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_12.jpg','2026-07-07 09:40:06.517'),
(789,32,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_13.jpg','2026-07-07 09:40:06.517'),
(790,32,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_14.jpg','2026-07-07 09:40:06.517'),
(791,32,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_15.jpg','2026-07-07 09:40:06.517'),
(792,32,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_16.jpg','2026-07-07 09:40:06.517'),
(793,32,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_17.jpg','2026-07-07 09:40:06.517'),
(794,32,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_18.jpg','2026-07-07 09:40:06.517'),
(795,32,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_19.jpg','2026-07-07 09:40:06.517'),
(796,32,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_20.jpg','2026-07-07 09:40:06.517'),
(797,32,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_21.jpg','2026-07-07 09:40:06.517'),
(798,32,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_22.jpg','2026-07-07 09:40:06.517'),
(799,32,23,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_31/page_23.jpg','2026-07-07 09:40:06.517'),
(800,33,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_1.jpg','2026-07-07 09:40:06.822'),
(801,33,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_2.jpg','2026-07-07 09:40:06.822'),
(802,33,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_3.jpg','2026-07-07 09:40:06.822'),
(803,33,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_4.jpg','2026-07-07 09:40:06.822'),
(804,33,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_5.jpg','2026-07-07 09:40:06.822'),
(805,33,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_6.jpg','2026-07-07 09:40:06.822'),
(806,33,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_7.jpg','2026-07-07 09:40:06.822'),
(807,33,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_8.jpg','2026-07-07 09:40:06.822'),
(808,33,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_9.jpg','2026-07-07 09:40:06.822'),
(809,33,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_10.jpg','2026-07-07 09:40:06.822'),
(810,33,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_11.jpg','2026-07-07 09:40:06.822'),
(811,33,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_12.jpg','2026-07-07 09:40:06.822'),
(812,33,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_13.jpg','2026-07-07 09:40:06.822'),
(813,33,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_14.jpg','2026-07-07 09:40:06.822'),
(814,33,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_15.jpg','2026-07-07 09:40:06.822'),
(815,33,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_16.jpg','2026-07-07 09:40:06.822'),
(816,33,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_17.jpg','2026-07-07 09:40:06.822'),
(817,33,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_18.jpg','2026-07-07 09:40:06.822'),
(818,33,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_19.jpg','2026-07-07 09:40:06.822'),
(819,33,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_20.jpg','2026-07-07 09:40:06.822'),
(820,33,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_32/page_21.jpg','2026-07-07 09:40:06.822'),
(821,34,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_1.jpg','2026-07-07 09:40:07.101'),
(822,34,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_2.jpg','2026-07-07 09:40:07.101'),
(823,34,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_3.jpg','2026-07-07 09:40:07.101'),
(824,34,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_4.jpg','2026-07-07 09:40:07.101'),
(825,34,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_5.jpg','2026-07-07 09:40:07.101'),
(826,34,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_6.jpg','2026-07-07 09:40:07.101'),
(827,34,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_7.jpg','2026-07-07 09:40:07.101'),
(828,34,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_8.jpg','2026-07-07 09:40:07.101'),
(829,34,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_9.jpg','2026-07-07 09:40:07.101'),
(830,34,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_10.jpg','2026-07-07 09:40:07.101'),
(831,34,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_11.jpg','2026-07-07 09:40:07.101'),
(832,34,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_12.jpg','2026-07-07 09:40:07.101'),
(833,34,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_13.jpg','2026-07-07 09:40:07.101'),
(834,34,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_14.jpg','2026-07-07 09:40:07.101'),
(835,34,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_15.jpg','2026-07-07 09:40:07.101'),
(836,34,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_16.jpg','2026-07-07 09:40:07.101'),
(837,34,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_17.jpg','2026-07-07 09:40:07.101'),
(838,34,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_18.jpg','2026-07-07 09:40:07.101'),
(839,34,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_19.jpg','2026-07-07 09:40:07.101'),
(840,34,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_20.jpg','2026-07-07 09:40:07.101'),
(841,34,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_33/page_21.jpg','2026-07-07 09:40:07.101'),
(842,35,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_1.jpg','2026-07-07 09:40:07.382'),
(843,35,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_2.jpg','2026-07-07 09:40:07.382'),
(844,35,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_3.jpg','2026-07-07 09:40:07.382'),
(845,35,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_4.jpg','2026-07-07 09:40:07.382'),
(846,35,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_5.jpg','2026-07-07 09:40:07.382'),
(847,35,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_6.jpg','2026-07-07 09:40:07.382'),
(848,35,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_7.jpg','2026-07-07 09:40:07.382'),
(849,35,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_8.jpg','2026-07-07 09:40:07.382'),
(850,35,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_9.jpg','2026-07-07 09:40:07.382'),
(851,35,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_10.jpg','2026-07-07 09:40:07.382'),
(852,35,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_11.jpg','2026-07-07 09:40:07.382'),
(853,35,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_12.jpg','2026-07-07 09:40:07.382'),
(854,35,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_13.jpg','2026-07-07 09:40:07.382'),
(855,35,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_14.jpg','2026-07-07 09:40:07.382'),
(856,35,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_15.jpg','2026-07-07 09:40:07.382'),
(857,35,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_16.jpg','2026-07-07 09:40:07.382'),
(858,35,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_17.jpg','2026-07-07 09:40:07.382'),
(859,35,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_18.jpg','2026-07-07 09:40:07.382'),
(860,35,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_19.jpg','2026-07-07 09:40:07.382'),
(861,35,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_20.jpg','2026-07-07 09:40:07.382'),
(862,35,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_21.jpg','2026-07-07 09:40:07.382'),
(863,35,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_34/page_22.jpg','2026-07-07 09:40:07.382'),
(864,36,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_1.jpg','2026-07-07 14:24:01.393'),
(865,36,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_2.jpg','2026-07-07 14:24:01.393'),
(866,36,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_3.jpg','2026-07-07 14:24:01.393'),
(867,36,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_4.jpg','2026-07-07 14:24:01.393'),
(868,36,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_5.jpg','2026-07-07 14:24:01.393'),
(869,36,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_6.jpg','2026-07-07 14:24:01.393'),
(870,36,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_7.jpg','2026-07-07 14:24:01.393'),
(871,36,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_8.jpg','2026-07-07 14:24:01.393'),
(872,36,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_9.jpg','2026-07-07 14:24:01.393'),
(873,36,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_10.jpg','2026-07-07 14:24:01.393'),
(874,36,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_11.jpg','2026-07-07 14:24:01.393'),
(875,36,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_12.jpg','2026-07-07 14:24:01.393'),
(876,36,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_13.jpg','2026-07-07 14:24:01.393'),
(877,36,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_14.jpg','2026-07-07 14:24:01.393'),
(878,36,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_15.jpg','2026-07-07 14:24:01.393'),
(879,36,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_16.jpg','2026-07-07 14:24:01.393'),
(880,36,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_17.jpg','2026-07-07 14:24:01.393'),
(881,36,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_18.jpg','2026-07-07 14:24:01.393'),
(882,36,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_19.jpg','2026-07-07 14:24:01.393'),
(883,36,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_35/page_20.jpg','2026-07-07 14:24:01.393'),
(884,37,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_1.jpg','2026-07-07 14:24:01.667'),
(885,37,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_2.jpg','2026-07-07 14:24:01.667'),
(886,37,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_3.jpg','2026-07-07 14:24:01.667'),
(887,37,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_4.jpg','2026-07-07 14:24:01.667'),
(888,37,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_5.jpg','2026-07-07 14:24:01.667'),
(889,37,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_6.jpg','2026-07-07 14:24:01.667'),
(890,37,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_7.jpg','2026-07-07 14:24:01.667'),
(891,37,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_8.jpg','2026-07-07 14:24:01.667'),
(892,37,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_9.jpg','2026-07-07 14:24:01.667'),
(893,37,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_10.jpg','2026-07-07 14:24:01.667'),
(894,37,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_11.jpg','2026-07-07 14:24:01.667'),
(895,37,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_12.jpg','2026-07-07 14:24:01.667'),
(896,37,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_13.jpg','2026-07-07 14:24:01.667'),
(897,37,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_14.jpg','2026-07-07 14:24:01.667'),
(898,37,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_15.jpg','2026-07-07 14:24:01.667'),
(899,37,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_16.jpg','2026-07-07 14:24:01.667'),
(900,37,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_17.jpg','2026-07-07 14:24:01.667'),
(901,37,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_18.jpg','2026-07-07 14:24:01.667'),
(902,37,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_19.jpg','2026-07-07 14:24:01.667'),
(903,37,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_20.jpg','2026-07-07 14:24:01.667'),
(904,37,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_21.jpg','2026-07-07 14:24:01.667'),
(905,37,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_36/page_22.jpg','2026-07-07 14:24:01.667'),
(906,38,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_1.jpg','2026-07-07 14:24:01.974'),
(907,38,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_2.jpg','2026-07-07 14:24:01.974'),
(908,38,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_3.jpg','2026-07-07 14:24:01.974'),
(909,38,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_4.jpg','2026-07-07 14:24:01.974'),
(910,38,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_5.jpg','2026-07-07 14:24:01.974'),
(911,38,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_6.jpg','2026-07-07 14:24:01.974'),
(912,38,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_7.jpg','2026-07-07 14:24:01.974'),
(913,38,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_8.jpg','2026-07-07 14:24:01.974'),
(914,38,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_9.jpg','2026-07-07 14:24:01.974'),
(915,38,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_10.jpg','2026-07-07 14:24:01.974'),
(916,38,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_11.jpg','2026-07-07 14:24:01.974'),
(917,38,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_12.jpg','2026-07-07 14:24:01.974'),
(918,38,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_13.jpg','2026-07-07 14:24:01.974'),
(919,38,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_14.jpg','2026-07-07 14:24:01.974'),
(920,38,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_15.jpg','2026-07-07 14:24:01.974'),
(921,38,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_16.jpg','2026-07-07 14:24:01.974'),
(922,38,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_17.jpg','2026-07-07 14:24:01.974'),
(923,38,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_18.jpg','2026-07-07 14:24:01.974'),
(924,38,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_19.jpg','2026-07-07 14:24:01.974'),
(925,38,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_20.jpg','2026-07-07 14:24:01.974'),
(926,38,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_21.jpg','2026-07-07 14:24:01.974'),
(927,38,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_37/page_22.jpg','2026-07-07 14:24:01.974'),
(928,39,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_1.jpg','2026-07-07 14:24:02.280'),
(929,39,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_2.jpg','2026-07-07 14:24:02.280'),
(930,39,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_3.jpg','2026-07-07 14:24:02.280'),
(931,39,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_4.jpg','2026-07-07 14:24:02.280'),
(932,39,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_5.jpg','2026-07-07 14:24:02.280'),
(933,39,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_6.jpg','2026-07-07 14:24:02.280'),
(934,39,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_7.jpg','2026-07-07 14:24:02.280'),
(935,39,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_8.jpg','2026-07-07 14:24:02.280'),
(936,39,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_9.jpg','2026-07-07 14:24:02.280'),
(937,39,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_10.jpg','2026-07-07 14:24:02.280'),
(938,39,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_11.jpg','2026-07-07 14:24:02.280'),
(939,39,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_12.jpg','2026-07-07 14:24:02.280'),
(940,39,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_13.jpg','2026-07-07 14:24:02.280'),
(941,39,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_14.jpg','2026-07-07 14:24:02.280'),
(942,39,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_15.jpg','2026-07-07 14:24:02.280'),
(943,39,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_16.jpg','2026-07-07 14:24:02.280'),
(944,39,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_17.jpg','2026-07-07 14:24:02.280'),
(945,39,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_18.jpg','2026-07-07 14:24:02.280'),
(946,39,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_19.jpg','2026-07-07 14:24:02.280'),
(947,39,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_20.jpg','2026-07-07 14:24:02.280'),
(948,39,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_38/page_21.jpg','2026-07-07 14:24:02.280'),
(949,40,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_1.jpg','2026-07-07 14:24:02.583'),
(950,40,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_2.jpg','2026-07-07 14:24:02.583'),
(951,40,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_3.jpg','2026-07-07 14:24:02.583'),
(952,40,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_4.jpg','2026-07-07 14:24:02.583'),
(953,40,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_5.jpg','2026-07-07 14:24:02.583'),
(954,40,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_6.jpg','2026-07-07 14:24:02.583'),
(955,40,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_7.jpg','2026-07-07 14:24:02.583'),
(956,40,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_8.jpg','2026-07-07 14:24:02.583'),
(957,40,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_9.jpg','2026-07-07 14:24:02.583'),
(958,40,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_10.jpg','2026-07-07 14:24:02.583'),
(959,40,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_11.jpg','2026-07-07 14:24:02.583'),
(960,40,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_12.jpg','2026-07-07 14:24:02.583'),
(961,40,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_13.jpg','2026-07-07 14:24:02.583'),
(962,40,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_14.jpg','2026-07-07 14:24:02.583'),
(963,40,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_15.jpg','2026-07-07 14:24:02.583'),
(964,40,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_16.jpg','2026-07-07 14:24:02.583'),
(965,40,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_17.jpg','2026-07-07 14:24:02.583'),
(966,40,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_18.jpg','2026-07-07 14:24:02.583'),
(967,40,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_19.jpg','2026-07-07 14:24:02.583'),
(968,40,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_39/page_20.jpg','2026-07-07 14:24:02.583'),
(969,41,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_1.jpg','2026-07-07 14:32:01.403'),
(970,41,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_2.jpg','2026-07-07 14:32:01.403'),
(971,41,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_3.jpg','2026-07-07 14:32:01.403'),
(972,41,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_4.jpg','2026-07-07 14:32:01.403'),
(973,41,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_5.jpg','2026-07-07 14:32:01.403'),
(974,41,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_6.jpg','2026-07-07 14:32:01.403'),
(975,41,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_7.jpg','2026-07-07 14:32:01.403'),
(976,41,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_8.jpg','2026-07-07 14:32:01.403'),
(977,41,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_9.jpg','2026-07-07 14:32:01.403'),
(978,41,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_10.jpg','2026-07-07 14:32:01.403'),
(979,41,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_11.jpg','2026-07-07 14:32:01.403'),
(980,41,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_12.jpg','2026-07-07 14:32:01.403'),
(981,41,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_13.jpg','2026-07-07 14:32:01.403'),
(982,41,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_14.jpg','2026-07-07 14:32:01.403'),
(983,41,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_15.jpg','2026-07-07 14:32:01.403'),
(984,41,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_16.jpg','2026-07-07 14:32:01.403'),
(985,41,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_17.jpg','2026-07-07 14:32:01.403'),
(986,41,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_18.jpg','2026-07-07 14:32:01.403'),
(987,41,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_19.jpg','2026-07-07 14:32:01.403'),
(988,41,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_40/page_20.jpg','2026-07-07 14:32:01.403'),
(989,42,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_1.jpg','2026-07-07 14:32:01.625'),
(990,42,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_2.jpg','2026-07-07 14:32:01.625'),
(991,42,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_3.jpg','2026-07-07 14:32:01.625'),
(992,42,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_4.jpg','2026-07-07 14:32:01.625'),
(993,42,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_5.jpg','2026-07-07 14:32:01.625'),
(994,42,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_6.jpg','2026-07-07 14:32:01.625'),
(995,42,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_7.jpg','2026-07-07 14:32:01.625'),
(996,42,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_8.jpg','2026-07-07 14:32:01.625'),
(997,42,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_9.jpg','2026-07-07 14:32:01.625'),
(998,42,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_10.jpg','2026-07-07 14:32:01.625'),
(999,42,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_11.jpg','2026-07-07 14:32:01.625'),
(1000,42,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_12.jpg','2026-07-07 14:32:01.625'),
(1001,42,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_13.jpg','2026-07-07 14:32:01.625'),
(1002,42,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_14.jpg','2026-07-07 14:32:01.625'),
(1003,42,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_15.jpg','2026-07-07 14:32:01.625'),
(1004,42,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_16.jpg','2026-07-07 14:32:01.625'),
(1005,42,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_17.jpg','2026-07-07 14:32:01.625'),
(1006,42,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_18.jpg','2026-07-07 14:32:01.625'),
(1007,42,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_19.jpg','2026-07-07 14:32:01.625'),
(1008,42,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_20.jpg','2026-07-07 14:32:01.625'),
(1009,42,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_21.jpg','2026-07-07 14:32:01.625'),
(1010,42,22,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_41/page_22.jpg','2026-07-07 14:32:01.625'),
(1011,43,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_1.jpg','2026-07-07 14:32:01.934'),
(1012,43,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_2.jpg','2026-07-07 14:32:01.934'),
(1013,43,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_3.jpg','2026-07-07 14:32:01.934'),
(1014,43,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_4.jpg','2026-07-07 14:32:01.934'),
(1015,43,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_5.jpg','2026-07-07 14:32:01.934'),
(1016,43,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_6.jpg','2026-07-07 14:32:01.934'),
(1017,43,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_7.jpg','2026-07-07 14:32:01.934'),
(1018,43,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_8.jpg','2026-07-07 14:32:01.934'),
(1019,43,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_9.jpg','2026-07-07 14:32:01.934'),
(1020,43,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_10.jpg','2026-07-07 14:32:01.934'),
(1021,43,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_11.jpg','2026-07-07 14:32:01.934'),
(1022,43,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_12.jpg','2026-07-07 14:32:01.934'),
(1023,43,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_13.jpg','2026-07-07 14:32:01.934'),
(1024,43,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_14.jpg','2026-07-07 14:32:01.934'),
(1025,43,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_15.jpg','2026-07-07 14:32:01.934'),
(1026,43,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_16.jpg','2026-07-07 14:32:01.934'),
(1027,43,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_17.jpg','2026-07-07 14:32:01.934'),
(1028,43,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_18.jpg','2026-07-07 14:32:01.934'),
(1029,43,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_19.jpg','2026-07-07 14:32:01.934'),
(1030,43,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_20.jpg','2026-07-07 14:32:01.934'),
(1031,43,21,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_42/page_21.jpg','2026-07-07 14:32:01.934'),
(1032,44,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_1.jpg','2026-07-07 14:32:02.159'),
(1033,44,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_2.jpg','2026-07-07 14:32:02.159'),
(1034,44,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_3.jpg','2026-07-07 14:32:02.159'),
(1035,44,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_4.jpg','2026-07-07 14:32:02.159'),
(1036,44,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_5.jpg','2026-07-07 14:32:02.159'),
(1037,44,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_6.jpg','2026-07-07 14:32:02.159'),
(1038,44,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_7.jpg','2026-07-07 14:32:02.159'),
(1039,44,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_8.jpg','2026-07-07 14:32:02.159'),
(1040,44,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_9.jpg','2026-07-07 14:32:02.159'),
(1041,44,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_10.jpg','2026-07-07 14:32:02.159'),
(1042,44,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_11.jpg','2026-07-07 14:32:02.159'),
(1043,44,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_12.jpg','2026-07-07 14:32:02.159'),
(1044,44,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_13.jpg','2026-07-07 14:32:02.159'),
(1045,44,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_14.jpg','2026-07-07 14:32:02.159'),
(1046,44,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_15.jpg','2026-07-07 14:32:02.159'),
(1047,44,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_16.jpg','2026-07-07 14:32:02.159'),
(1048,44,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_17.jpg','2026-07-07 14:32:02.159'),
(1049,44,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_18.jpg','2026-07-07 14:32:02.159'),
(1050,44,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_19.jpg','2026-07-07 14:32:02.159'),
(1051,44,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_43/page_20.jpg','2026-07-07 14:32:02.159'),
(1052,45,1,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_1.jpg','2026-07-07 14:32:02.441'),
(1053,45,2,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_2.jpg','2026-07-07 14:32:02.441'),
(1054,45,3,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_3.jpg','2026-07-07 14:32:02.441'),
(1055,45,4,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_4.jpg','2026-07-07 14:32:02.441'),
(1056,45,5,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_5.jpg','2026-07-07 14:32:02.441'),
(1057,45,6,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_6.jpg','2026-07-07 14:32:02.441'),
(1058,45,7,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_7.jpg','2026-07-07 14:32:02.441'),
(1059,45,8,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_8.jpg','2026-07-07 14:32:02.441'),
(1060,45,9,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_9.jpg','2026-07-07 14:32:02.441'),
(1061,45,10,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_10.jpg','2026-07-07 14:32:02.441'),
(1062,45,11,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_11.jpg','2026-07-07 14:32:02.441'),
(1063,45,12,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_12.jpg','2026-07-07 14:32:02.441'),
(1064,45,13,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_13.jpg','2026-07-07 14:32:02.441'),
(1065,45,14,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_14.jpg','2026-07-07 14:32:02.441'),
(1066,45,15,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_15.jpg','2026-07-07 14:32:02.441'),
(1067,45,16,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_16.jpg','2026-07-07 14:32:02.441'),
(1068,45,17,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_17.jpg','2026-07-07 14:32:02.441'),
(1069,45,18,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_18.jpg','2026-07-07 14:32:02.441'),
(1070,45,19,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_19.jpg','2026-07-07 14:32:02.441'),
(1071,45,20,'https://sv1.otruyencdn.com/uploads/20240110/e7652bae6c0a9765581bfe82b9965f99/chapter_44/page_20.jpg','2026-07-07 14:32:02.441');
/*!40000 ALTER TABLE `chapter_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `manga_id` bigint NOT NULL,
  `chapter_id` bigint DEFAULT NULL,
  `parent_id` bigint DEFAULT NULL,
  `content` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'VISIBLE',
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comment_user` (`user_id`),
  KEY `fk_comment_manga` (`manga_id`),
  KEY `fk_comment_chapter_manga` (`chapter_id`,`manga_id`),
  KEY `fk_comment_parent` (`parent_id`),
  CONSTRAINT `fk_comment_chapter_manga` FOREIGN KEY (`chapter_id`, `manga_id`) REFERENCES `chapter` (`id`, `manga_id`),
  CONSTRAINT `fk_comment_manga` FOREIGN KEY (`manga_id`) REFERENCES `manga` (`id`),
  CONSTRAINT `fk_comment_parent` FOREIGN KEY (`parent_id`) REFERENCES `comment` (`id`),
  CONSTRAINT `fk_comment_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `chk_comment_status` CHECK ((`status` in (_utf8mb4'VISIBLE',_utf8mb4'HIDDEN',_utf8mb4'DELETED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_like`
--

DROP TABLE IF EXISTS `comment_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_like` (
  `user_id` bigint NOT NULL,
  `comment_id` bigint NOT NULL,
  PRIMARY KEY (`user_id`,`comment_id`),
  KEY `fk_comment_like_comment` (`comment_id`),
  CONSTRAINT `fk_comment_like_comment` FOREIGN KEY (`comment_id`) REFERENCES `comment` (`id`),
  CONSTRAINT `fk_comment_like_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_like`
--

LOCK TABLES `comment_like` WRITE;
/*!40000 ALTER TABLE `comment_like` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_like` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_verification_token`
--

DROP TABLE IF EXISTS `email_verification_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_verification_token` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `used_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_email_verification_token_hash` (`token_hash`),
  KEY `fk_email_verification_token_user` (`user_id`),
  CONSTRAINT `fk_email_verification_token_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_verification_token`
--

LOCK TABLES `email_verification_token` WRITE;
/*!40000 ALTER TABLE `email_verification_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_verification_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite`
--

DROP TABLE IF EXISTS `favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorite` (
  `user_id` bigint NOT NULL,
  `manga_id` bigint NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`user_id`,`manga_id`),
  KEY `fk_favorite_manga` (`manga_id`),
  CONSTRAINT `fk_favorite_manga` FOREIGN KEY (`manga_id`) REFERENCES `manga` (`id`),
  CONSTRAINT `fk_favorite_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite`
--

LOCK TABLES `favorite` WRITE;
/*!40000 ALTER TABLE `favorite` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manga`
--

DROP TABLE IF EXISTS `manga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `manga` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `otruyen_manga_id` char(24) DEFAULT NULL,
  `owner_user_id` bigint DEFAULT NULL,
  `source_type` varchar(20) NOT NULL,
  `slug` varchar(550) NOT NULL,
  `title` varchar(500) NOT NULL,
  `origin_name` varchar(500) DEFAULT NULL,
  `description` text,
  `status` varchar(30) NOT NULL,
  `thumb_url` varchar(500) DEFAULT NULL,
  `local_cover_url` varchar(1000) DEFAULT NULL,
  `approval_status` varchar(20) NOT NULL DEFAULT 'DRAFT',
  `submitted_at` datetime(3) DEFAULT NULL,
  `reviewed_at` datetime(3) DEFAULT NULL,
  `reviewed_by` bigint DEFAULT NULL,
  `rejection_reason` varchar(1000) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  `deleted_at` datetime(3) DEFAULT NULL,
  `deleted_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_manga_slug` (`slug`),
  UNIQUE KEY `uq_manga_otruyen_id` (`otruyen_manga_id`),
  KEY `fk_manga_owner` (`owner_user_id`),
  KEY `fk_manga_reviewed_by` (`reviewed_by`),
  KEY `fk_manga_deleted_by` (`deleted_by`),
  CONSTRAINT `fk_manga_deleted_by` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_manga_owner` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_manga_reviewed_by` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`),
  CONSTRAINT `chk_manga_approval_status` CHECK ((`approval_status` in (_utf8mb4'DRAFT',_utf8mb4'PENDING',_utf8mb4'APPROVED',_utf8mb4'REJECTED'))),
  CONSTRAINT `chk_manga_source_type` CHECK ((`source_type` in (_utf8mb4'OTRUYEN',_utf8mb4'LOCAL')))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manga`
--

LOCK TABLES `manga` WRITE;
/*!40000 ALTER TABLE `manga` DISABLE KEYS */;
INSERT INTO `manga` VALUES
(1,'6598f2f968e54cf5b50a29d4',NULL,'OTRUYEN','wind-breaker','Wind Breaker',NULL,'<p>Hãy bảo vệ khu phố bằng nắm đấm đó! Huyền thoại về vị anh hùng chiến đấu Sakura - học sinh cấp 3 giang hồ. Điểm chuẩn thì lẹt đẹt, nhưng đánh nhau thì luôn là mạnh nhất. Nơi nổi danh là ngôi trường của những tên giang hồ khủng khiếp nhất: THPT Fuurin. Với mục đích trở thành kẻ đứng đầu của một Fuurin như vậy, vào mùa xuân năm ấy, học sinh lớp 10 Sakura Haruka đến khu phố Tonpuu và biết được về băng nhóm bảo vệ khu phố với tên gọi \"Boufuurin\" của trường. Sakura quyết định sẽ bắt đầu chiến đấu để bảo vệ nơi ấy như một thành viên của Fuurin! (Đây là bộ truyện trùng tên nhưng khác tác giả)</p>','ongoing','wind-breaker-thumb.jpg',NULL,'DRAFT',NULL,NULL,NULL,NULL,'2026-07-06 08:40:01.517','2026-06-11 16:12:15.587',NULL,NULL);
/*!40000 ALTER TABLE `manga` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manga_author`
--

DROP TABLE IF EXISTS `manga_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `manga_author` (
  `manga_id` bigint NOT NULL,
  `author_id` bigint NOT NULL,
  PRIMARY KEY (`manga_id`,`author_id`),
  KEY `fk_manga_author_author` (`author_id`),
  CONSTRAINT `fk_manga_author_author` FOREIGN KEY (`author_id`) REFERENCES `author` (`id`),
  CONSTRAINT `fk_manga_author_manga` FOREIGN KEY (`manga_id`) REFERENCES `manga` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manga_author`
--

LOCK TABLES `manga_author` WRITE;
/*!40000 ALTER TABLE `manga_author` DISABLE KEYS */;
INSERT INTO `manga_author` VALUES
(1,1);
/*!40000 ALTER TABLE `manga_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manga_category`
--

DROP TABLE IF EXISTS `manga_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `manga_category` (
  `manga_id` bigint NOT NULL,
  `category_id` bigint NOT NULL,
  PRIMARY KEY (`manga_id`,`category_id`),
  KEY `fk_manga_category_category` (`category_id`),
  CONSTRAINT `fk_manga_category_category` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `fk_manga_category_manga` FOREIGN KEY (`manga_id`) REFERENCES `manga` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manga_category`
--

LOCK TABLES `manga_category` WRITE;
/*!40000 ALTER TABLE `manga_category` DISABLE KEYS */;
INSERT INTO `manga_category` VALUES
(1,1),
(1,2),
(1,3),
(1,4),
(1,5);
/*!40000 ALTER TABLE `manga_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manga_like`
--

DROP TABLE IF EXISTS `manga_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `manga_like` (
  `user_id` bigint NOT NULL,
  `manga_id` bigint NOT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`user_id`,`manga_id`),
  KEY `fk_manga_like_manga` (`manga_id`),
  CONSTRAINT `fk_manga_like_manga` FOREIGN KEY (`manga_id`) REFERENCES `manga` (`id`),
  CONSTRAINT `fk_manga_like_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manga_like`
--

LOCK TABLES `manga_like` WRITE;
/*!40000 ALTER TABLE `manga_like` DISABLE KEYS */;
/*!40000 ALTER TABLE `manga_like` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_token`
--

DROP TABLE IF EXISTS `password_reset_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_token` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `used_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_password_reset_token_hash` (`token_hash`),
  KEY `fk_password_reset_token_user` (`user_id`),
  CONSTRAINT `fk_password_reset_token_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_token`
--

LOCK TABLES `password_reset_token` WRITE;
/*!40000 ALTER TABLE `password_reset_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reading_history`
--

DROP TABLE IF EXISTS `reading_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reading_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `manga_id` bigint NOT NULL,
  `chapter_id` bigint NOT NULL,
  `page_index` int NOT NULL DEFAULT '0',
  `last_read_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reading_history_user_chapter` (`user_id`,`chapter_id`),
  KEY `fk_reading_history_manga` (`manga_id`),
  KEY `fk_reading_history_chapter_manga` (`chapter_id`,`manga_id`),
  CONSTRAINT `fk_reading_history_chapter_manga` FOREIGN KEY (`chapter_id`, `manga_id`) REFERENCES `chapter` (`id`, `manga_id`),
  CONSTRAINT `fk_reading_history_manga` FOREIGN KEY (`manga_id`) REFERENCES `manga` (`id`),
  CONSTRAINT `fk_reading_history_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reading_history`
--

LOCK TABLES `reading_history` WRITE;
/*!40000 ALTER TABLE `reading_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `reading_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `avatar_url` varchar(1000) DEFAULT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'USER',
  `email_verified_at` datetime(3) DEFAULT NULL,
  `password_changed_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL,
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_username` (`username`),
  CONSTRAINT `chk_users_role` CHECK ((`role` in (_utf8mb4'USER',_utf8mb4'AUTHOR',_utf8mb4'ADMIN')))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'hieuminh9873@gmail.com','suzune','$2a$10$Lpjua.HYwc9MV5kF/3JzdO2nD9GXuz2I5sWhdjHwsR5G1AKAw4cmO',NULL,'USER',NULL,NULL,'2026-07-07 08:16:50.643','2026-07-07 08:16:50.643'),
(2,'hieuminh98723@gmail.com','suzune2','$2a$10$X9dDplgCSk6pWDJAKGQ7u.7tlK171bLD.3BKW26KxrMDUzAMfmPeC',NULL,'USER',NULL,NULL,'2026-07-07 09:11:11.364','2026-07-07 09:11:11.364');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'MangaBlade'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-07 22:03:44
