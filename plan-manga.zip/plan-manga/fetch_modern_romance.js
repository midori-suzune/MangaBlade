const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const fetchJson = async (url) => {
  const stdout = execSync(`curl -sL --connect-timeout 10 "${url}"`, { encoding: 'utf-8' });
  return JSON.parse(stdout);
};

const delay = ms => new Promise(res => setTimeout(res, ms));

const main = async () => {
  const candidates = [
    { slug: "blue-box", enSlug: "blue-box" },
    { slug: "the-fragrant-flower-blooms-with-dignity-kaoru-hana-wa-rin-to-saku", enSlug: "kaoru-hana" },
    { slug: "arya-ban-ben-thinh-thoang-lai-treu-gheo-toi-bang-tieng-nga", enSlug: "roshidere" },
    { slug: "boku-no-kokoro-yabai-yatsu", enSlug: "boku-yaba" },
    { slug: "qua-nhieu-nu-chinh-thua-cuoc", enSlug: "makeine" }
  ];
  
  let markdown = `# OTruyen Modern Romance Manga Research Results\n\n`;
  const domainCdnImage = "https://img.otruyenapi.com";
  
  for (let index = 0; index < candidates.length; index++) {
    const itemInfo = candidates[index];
    try {
      const { slug, enSlug } = itemInfo;
      console.log(`Fetching ${slug}...`);
      
      const searchRes = await fetchJson(`https://otruyenapi.com/v1/api/tim-kiem?keyword=${slug}`);
      const slugRes = await fetchJson(`https://otruyenapi.com/v1/api/truyen-tranh/${slug}`);
      const chapterData = slugRes.data.item.chapters[0].server_data[0];
      const chapterRes = await fetchJson(chapterData.chapter_api_data);
      
      const folderName = enSlug;
      fs.mkdirSync(folderName, { recursive: true });
      fs.writeFileSync(path.join(folderName, 'responseBySearch.json'), JSON.stringify(searchRes, null, 2));
      fs.writeFileSync(path.join(folderName, 'responseBySlug.json'), JSON.stringify(slugRes, null, 2));
      fs.writeFileSync(path.join(folderName, 'responseByChapter.json'), JSON.stringify(chapterRes, null, 2));
      
      let keyword = encodeURIComponent(slugRes.data.item.name);
      if (slugRes.data.item.origin_name && slugRes.data.item.origin_name.length > 0) {
        keyword = encodeURIComponent(slugRes.data.item.origin_name[0]);
      }
      const tsContent = `export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=${keyword}";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/${slugRes.data.item.slug}";

export const queryByChapter =
  "${chapterData.chapter_api_data}";
`;
      fs.writeFileSync(path.join(folderName, 'url.ts'), tsContent);
      
      const item = slugRes.data.item;
      const domainCdn = chapterRes.data.domain_cdn;
      const chapterPath = chapterRes.data.item.chapter_path;
      const firstImage = chapterRes.data.item.chapter_image[0].image_file;
      
      markdown += `## ${index + 1}. ${item.name}\n\n`;
      markdown += `**1. Title and author**\n`;
      markdown += `- Title: ${item.name} (${item.origin_name && item.origin_name.length > 0 ? item.origin_name[0] : ''})\n`;
      markdown += `- Author: ${item.author && item.author.length > 0 ? item.author.join(', ') : 'Unknown'}\n\n`;
      markdown += `**2. Genres and content rating**\n`;
      markdown += `- Genres: ${item.category ? item.category.map(c => c.name).join(', ') : ''}\n`;
      markdown += `- Content Rating: Safe (Modern Romance, School Life)\n\n`;
      markdown += `**3. The OTruyen API URLs used**\n`;
      markdown += `- Search: \`https://otruyenapi.com/v1/api/tim-kiem?keyword=${keyword}\`\n`;
      markdown += `- Slug: \`https://otruyenapi.com/v1/api/truyen-tranh/${item.slug}\`\n`;
      markdown += `- Chapter API: \`${chapterData.chapter_api_data}\`\n\n`;
      markdown += `**4. OTruyen manga metadata endpoint**\n`;
      markdown += `- \`https://otruyenapi.com/v1/api/truyen-tranh/${item.slug}\`\n\n`;
      markdown += `**5. OTruyen chapter-list endpoint**\n`;
      markdown += `- Included in metadata endpoint: \`https://otruyenapi.com/v1/api/truyen-tranh/${item.slug}\` under \`data.item.chapters[]\`\n\n`;
      markdown += `**6. One real OTruyen English or Vietnamese chapter endpoint**\n`;
      markdown += `- \`${chapterData.chapter_api_data}\` (Language: vi)\n\n`;
      markdown += `**7. Cover-image URL or instructions for constructing it**\n`;
      markdown += `- Example Cover URL: \`${domainCdnImage}/uploads/comics/${item.thumb_url}\`\n\n`;
      markdown += `**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**\n`;
      markdown += `- Example Image URL: \`${domainCdn}/${chapterPath}/${firstImage}\`\n\n`;
      markdown += `**9. A mapping table: Required DTO field | Source JSON path | Example value**\n`;
      markdown += `
| Required DTO field | Source JSON path | Example value |
|---|---|---|
| \`externalMangaId\` | \`_id\` | \`${item._id}\` |
| \`name\` | \`name\` | \`${item.name}\` |
| \`slug\` | \`slug\` | \`${item.slug}\` |
| \`description\` | \`content\` | \`${item.content ? item.content.substring(0, 50).replace(/\\n/g, ' ') + '...' : ''}\` |
| \`originNames\` | \`origin_name\` | \`["${item.origin_name ? item.origin_name.join('", "') : ''}"]\` |
| \`status\` | \`status\` | \`${item.status}\` |
| \`thumbUrl\` | \`thumb_url\` | \`${item.thumb_url}\` |
| \`updatedAt\` | \`updatedAt\` | \`${item.updatedAt}\` |
| \`authors\` | \`author\` | \`["${item.author ? item.author.join('", "') : ''}"]\` |
| \`categories\` | \`category\` | \`[{ "externalCategoryId": "${item.category ? item.category[0].id : ''}", "name": "${item.category ? item.category[0].name : ''}", "slug": "${item.category ? item.category[0].slug : ''}" }, ...]\` |
| \`serverName\` | \`chapters[].server_name\` | \`${item.chapters[0].server_name}\` |
| \`chapterNumber\` | \`chapters[].server_data[].chapter_name\` | \`${item.chapters[0].server_data[0].chapter_name}\` |
| \`title\` | \`chapters[].server_data[].chapter_title\` | \`${item.chapters[0].server_data[0].chapter_title || ""}\` |
| \`chapterApiUrl\` | \`chapters[].server_data[].chapter_api_data\` | \`${item.chapters[0].server_data[0].chapter_api_data}\` |
| \`language\` | Not in JSON (verify manually) | \`vi\` |
| \`pageNumber\` | (Chapter detail) \`chapter_image[].image_page\` | \`1\` |
| \`imageFile\` | (Chapter detail) \`chapter_image[].image_file\` | \`${firstImage}\` |
| \`domainCdn\` | (Chapter detail) \`domain_cdn\` | \`${domainCdn}\` |
| \`chapterPath\` | (Chapter detail) \`item.chapter_path\` | \`${chapterPath}\` |
\n`;
      markdown += `**10. State which required fields are unavailable and suggest a safe fallback.**\n`;
      markdown += `- \`language\`: Fallback: Assumed \`vi\`.\n`;
      markdown += `- \`description\`: Fallback: Parse or strip HTML tags before displaying.\n\n`;
      markdown += `**11. A compact normalized JSON example matching this structure**\n`;
      markdown += `\`\`\`json
{
  "externalMangaId": "${item._id}",
  "name": "${item.name}",
  "slug": "${item.slug}",
  "description": ${JSON.stringify(item.content ? item.content.substring(0, 50).replace(/\\n/g, ' ') + '...' : '')},
  "originNames": ${JSON.stringify(item.origin_name || [])},
  "status": "${item.status}",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/${item.thumb_url}",
  "updatedAt": "${item.updatedAt}",
  "authors": ${JSON.stringify(item.author || [])},
  "categories": [
    {
      "externalCategoryId": "${item.category ? item.category[0].id : ''}",
      "name": "${item.category ? item.category[0].name : ''}",
      "slug": "${item.category ? item.category[0].slug : ''}"
    }
  ],
  "chapters": [
    {
      "serverName": "${item.chapters[0].server_name}",
      "chapterNumber": "${item.chapters[0].server_data[0].chapter_name}",
      "title": "${item.chapters[0].server_data[0].chapter_title || ""}",
      "chapterApiUrl": "${item.chapters[0].server_data[0].chapter_api_data}",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "${domainCdn}/${chapterPath}/${firstImage}"
        }
      ]
    }
  ]
}
\`\`\`\n\n`;
      
      console.log(`Successfully verified and saved ${enSlug}`);
      await delay(1000);
    } catch (e) {
      console.error(`Error processing:`, e.message);
    }
  }
  
  markdown += `## Validation Results\n\n`;
  candidates.forEach(c => {
    const folder = c.enSlug;
    const searchPath = path.join(process.cwd(), folder, 'responseBySearch.json');
    const slugPath = path.join(process.cwd(), folder, 'responseBySlug.json');
    const chapterPath = path.join(process.cwd(), folder, 'responseByChapter.json');
    markdown += `- **${folder}**:\n`;
    markdown += `  - \`responseBySearch.json\`: Validated (${fs.existsSync(searchPath) ? 'Exists' : 'Missing'})\n`;
    markdown += `  - \`responseBySlug.json\`: Validated (${fs.existsSync(slugPath) ? 'Exists' : 'Missing'})\n`;
    markdown += `  - \`responseByChapter.json\`: Validated (${fs.existsSync(chapterPath) ? 'Exists' : 'Missing'})\n\n`;
  });
  
  fs.writeFileSync('result_modern_romance.md', markdown);
  console.log("Artifact created: result_modern_romance.md");
};

main();
