const fs = require('fs');
const path = require('path');

const folders = [
  "detective-conan",
  "doraemon",
  "demon-slayer",
  "one-punch-man",
  "black-clover"
];

folders.forEach(folder => {
  if (!fs.existsSync(folder)) return;
  const slugJson = JSON.parse(fs.readFileSync(path.join(folder, 'responseBySlug.json')));
  
  const item = slugJson.data.item;
  
  // Use the name that actually matches the API search used to get the result
  let keyword = encodeURIComponent(item.slug);
  // Wait, if the user meant to use the English name as the keyword in url.ts:
  // e.g. "Wind Breaker" -> "Wind%20Breaker"
  // Let's use the origin_name if available, otherwise name.
  if (item.origin_name && item.origin_name.length > 0) {
    keyword = encodeURIComponent(item.origin_name[0]);
  } else {
    keyword = encodeURIComponent(item.name);
  }
  
  const queryByTitle = `https://otruyenapi.com/v1/api/tim-kiem?keyword=${keyword}`;
  const queryBySlug = `https://otruyenapi.com/v1/api/truyen-tranh/${item.slug}`;
  const queryByChapter = item.chapters[0].server_data[0].chapter_api_data;
  
  const tsContent = `export const queryByTitle =
  "${queryByTitle}";

export const queryBySlug =
  "${queryBySlug}";

export const queryByChapter =
  "${queryByChapter}";
`;

  fs.writeFileSync(path.join(folder, 'url.ts'), tsContent);
  console.log(`Created url.ts for ${folder}`);
});
