export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=Th%C3%A1m%20T%E1%BB%AD%20L%E1%BB%ABng%20Danh%20Conan";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/tham-tu-lung-danh-conan";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/69ba380e7b89b5b2570e4082";
