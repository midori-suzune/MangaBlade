# OTruyen Manga Research Results

## 1. Đảo Hải Tặc

**1. Title and author**
- Title: Đảo Hải Tặc (One Piece)
- Author: Oda Eiichiro

**2. Genres and content rating**
- Genres: Action, Adventure, Comedy, Drama, Fantasy, Manga, Shounen
- Content Rating: Safe (No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=dao-hai-tac`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/dao-hai-tac`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/65901d64ac52820f564b373e`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/dao-hai-tac`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/dao-hai-tac` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/65901d64ac52820f564b373e` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/dao-hai-tac-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231230/0a07c964d4ae96aee37c821abd014bcf/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `658f7e0668e54cf5b509097b` |
| `name` | `name` | `Đảo Hải Tặc` |
| `slug` | `slug` | `dao-hai-tac` |
| `description` | `content` | `<p>One Piece xoay quanh 1 nhóm cướp biển được gọi ...` |
| `originNames` | `origin_name` | `["One Piece"]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `dao-hai-tac-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2026-06-05T14:28:50.712Z` |
| `authors` | `author` | `["Oda Eiichiro"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a491", "name": "Action", "slug": "action" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/65901d64ac52820f564b373e` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231230/0a07c964d4ae96aee37c821abd014bcf/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "658f7e0668e54cf5b509097b",
  "name": "Đảo Hải Tặc",
  "slug": "dao-hai-tac",
  "description": "<p>One Piece xoay quanh 1 nhóm cướp biển được gọi ...",
  "originNames": ["One Piece"],
  "status": "ongoing",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/dao-hai-tac-thumb.jpg",
  "updatedAt": "2026-06-05T14:28:50.712Z",
  "authors": ["Oda Eiichiro"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a491",
      "name": "Action",
      "slug": "action"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/65901d64ac52820f564b373e",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231230/0a07c964d4ae96aee37c821abd014bcf/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## 2. Thần Đồng Đất Việt

**1. Title and author**
- Title: Thần Đồng Đất Việt ()
- Author: Lê Linh

**2. Genres and content rating**
- Genres: Comedy, Historical, Việt Nam
- Content Rating: Safe (No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=than-dong-dat-viet`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/than-dong-dat-viet`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/65570b8c5f7c20cfed7c0aa4`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/than-dong-dat-viet`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/than-dong-dat-viet` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/65570b8c5f7c20cfed7c0aa4` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/than-dong-dat-viet-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231117/af20c1144afcc595906fee9ea2b617fc/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `6556a81768e54cf5b5079d3f` |
| `name` | `name` | `Thần Đồng Đất Việt` |
| `slug` | `slug` | `than-dong-dat-viet` |
| `description` | `content` | `<p>Thần đồng Đất Việt là một bộ truyện tranh thiếu...` |
| `originNames` | `origin_name` | `[""]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `than-dong-dat-viet-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2024-05-12T08:30:37.233Z` |
| `authors` | `author` | `["Lê Linh"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4af", "name": "Comedy", "slug": "comedy" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/65570b8c5f7c20cfed7c0aa4` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231117/af20c1144afcc595906fee9ea2b617fc/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "6556a81768e54cf5b5079d3f",
  "name": "Thần Đồng Đất Việt",
  "slug": "than-dong-dat-viet",
  "description": "<p>Thần đồng Đất Việt là một bộ truyện tranh thiếu...",
  "originNames": [""],
  "status": "ongoing",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/than-dong-dat-viet-thumb.jpg",
  "updatedAt": "2024-05-12T08:30:37.233Z",
  "authors": ["Lê Linh"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a4af",
      "name": "Comedy",
      "slug": "comedy"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/65570b8c5f7c20cfed7c0aa4",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231117/af20c1144afcc595906fee9ea2b617fc/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## 3. Tôi thăng cấp một mình

**1. Title and author**
- Title: Tôi thăng cấp một mình ()
- Author: Jang Sung Lak

**2. Genres and content rating**
- Genres: Action, Adventure, Shounen, Truyện Màu, Webtoon
- Content Rating: Safe (No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=toi-thang-cap-mot-minh`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/toi-thang-cap-mot-minh`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/6568621ae120ddf21985fed6`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/toi-thang-cap-mot-minh`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/toi-thang-cap-mot-minh` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/6568621ae120ddf21985fed6` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/toi-thang-cap-mot-minh-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231130/8faf7680119d22a87245220650929452/chapter_0/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `659874fe68e54cf5b509bdb6` |
| `name` | `name` | `Tôi thăng cấp một mình` |
| `slug` | `slug` | `toi-thang-cap-mot-minh` |
| `description` | `content` | `<p>Theo chân Sung JinWoo trên hành trình từ "thợ s...` |
| `originNames` | `origin_name` | `[""]` |
| `status` | `status` | `completed` |
| `thumbUrl` | `thumb_url` | `toi-thang-cap-mot-minh-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2024-05-15T05:29:09.269Z` |
| `authors` | `author` | `["Jang Sung Lak"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a491", "name": "Action", "slug": "action" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `0` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/6568621ae120ddf21985fed6` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231130/8faf7680119d22a87245220650929452/chapter_0` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "659874fe68e54cf5b509bdb6",
  "name": "Tôi thăng cấp một mình",
  "slug": "toi-thang-cap-mot-minh",
  "description": "<p>Theo chân Sung JinWoo trên hành trình từ \"thợ s...",
  "originNames": [""],
  "status": "completed",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/toi-thang-cap-mot-minh-thumb.jpg",
  "updatedAt": "2024-05-15T05:29:09.269Z",
  "authors": ["Jang Sung Lak"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a491",
      "name": "Action",
      "slug": "action"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "0",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/6568621ae120ddf21985fed6",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231130/8faf7680119d22a87245220650929452/chapter_0/page_1.jpg"
        }
      ]
    }
  ]
}
```

## 4. Bách Luyện Thành Thần

**1. Title and author**
- Title: Bách Luyện Thành Thần (Hành Trình Tu Tiên)
- Author: Đang cập nhật

**2. Genres and content rating**
- Genres: Action, Drama, Mystery, Truyện Màu
- Content Rating: Safe (No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=bach-luyen-thanh-than`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/bach-luyen-thanh-than`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/659121ecac52820f564b6af7`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/bach-luyen-thanh-than`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/bach-luyen-thanh-than` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/659121ecac52820f564b6af7` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/bach-luyen-thanh-than-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231231/093907a8562bb6a92209515fc0a197a1/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `6591208310dc9c0a7e2e5572` |
| `name` | `name` | `Bách Luyện Thành Thần` |
| `slug` | `slug` | `bach-luyen-thanh-than` |
| `description` | `content` | `<p>Cảnh giới: Luyện nhục cảnh, Luyện cốt cảnh, Luy...` |
| `originNames` | `origin_name` | `["Hành Trình Tu Tiên"]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `bach-luyen-thanh-than-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2024-10-14T03:11:43.766Z` |
| `authors` | `author` | `["Đang cập nhật"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a491", "name": "Action", "slug": "action" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/659121ecac52820f564b6af7` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231231/093907a8562bb6a92209515fc0a197a1/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "6591208310dc9c0a7e2e5572",
  "name": "Bách Luyện Thành Thần",
  "slug": "bach-luyen-thanh-than",
  "description": "<p>Cảnh giới: Luyện nhục cảnh, Luyện cốt cảnh, Luy...",
  "originNames": ["Hành Trình Tu Tiên"],
  "status": "ongoing",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/bach-luyen-thanh-than-thumb.jpg",
  "updatedAt": "2024-10-14T03:11:43.766Z",
  "authors": ["Đang cập nhật"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a491",
      "name": "Action",
      "slug": "action"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/659121ecac52820f564b6af7",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231231/093907a8562bb6a92209515fc0a197a1/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## 5. Ta Là Tà Đế

**1. Title and author**
- Title: Ta Là Tà Đế (Ngã Vi Tà Đế)
- Author: Đang cập nhật

**2. Genres and content rating**
- Genres: Manhua, Supernatural, Truyện Màu, Xuyên Không
- Content Rating: Safe (No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=ta-la-ta-de`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/ta-la-ta-de`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/65915304e120ddf21992a126`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/ta-la-ta-de`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/ta-la-ta-de` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/65915304e120ddf21992a126` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/ta-la-ta-de-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231231/4246834a3aabdf08e7750339085d4027/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `659120b668e54cf5b5091241` |
| `name` | `name` | `Ta Là Tà Đế` |
| `slug` | `slug` | `ta-la-ta-de` |
| `description` | `content` | `<p>Truyện tranh Ta Là Tà Đế được cập nhật nhanh và...` |
| `originNames` | `origin_name` | `["Ngã Vi Tà Đế"]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `ta-la-ta-de-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2025-05-12T08:59:12.569Z` |
| `authors` | `author` | `["Đang cập nhật"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4d8", "name": "Manhua", "slug": "manhua" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/65915304e120ddf21992a126` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231231/4246834a3aabdf08e7750339085d4027/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "659120b668e54cf5b5091241",
  "name": "Ta Là Tà Đế",
  "slug": "ta-la-ta-de",
  "description": "<p>Truyện tranh Ta Là Tà Đế được cập nhật nhanh và...",
  "originNames": ["Ngã Vi Tà Đế"],
  "status": "ongoing",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/ta-la-ta-de-thumb.jpg",
  "updatedAt": "2025-05-12T08:59:12.569Z",
  "authors": ["Đang cập nhật"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a4d8",
      "name": "Manhua",
      "slug": "manhua"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/65915304e120ddf21992a126",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231231/4246834a3aabdf08e7750339085d4027/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## Validation Results

- **one-piece**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **vietnamese-child-prodigy**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **solo-leveling**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **apotheosis**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **im-an-evil-god**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

