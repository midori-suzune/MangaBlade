const fs = require('fs');
const path = require('path');
const https = require('https');

const fetchJson = (url) => {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
  });
};

const delay = ms => new Promise(res => setTimeout(res, ms));

const main = async () => {
  const candidates = [
    { slug: "horimiya", enSlug: "horimiya" },
    { slug: "nisekoi", enSlug: "nisekoi" },
    { slug: "toradora", enSlug: "toradora" },
    { slug: "khi-sep-la-hau-ban", enSlug: "maid-sama" },
    { slug: "relife", enSlug: "relife" }
  ];
  
  for (const item of candidates) {
    try {
      const { slug, enSlug } = item;
      console.log(`Fetching ${slug}...`);
      
      const searchRes = await fetchJson(`https://otruyenapi.com/v1/api/tim-kiem?keyword=${slug}`);
      const slugRes = await fetchJson(`https://otruyenapi.com/v1/api/truyen-tranh/${slug}`);
      const chapterData = slugRes.data.item.chapters[0].server_data[0];
      const chapterRes = await fetchJson(chapterData.chapter_api_data);
      
      const folderName = enSlug;
      fs.mkdirSync(folderName, { recursive: true });
      fs.writeFileSync(path.join(folderName, 'responseBySearch.json'), JSON.stringify(searchRes, null, 2));
      fs.writeFileSync(path.join(folderName, 'responseBySlug.json'), JSON.stringify(slugRes, null, 2));
      fs.writeFileSync(path.join(folderName, 'responseByChapter.json'), JSON.stringify(chapterRes, null, 2));
      
      // Write url.ts
      let keyword = encodeURIComponent(slugRes.data.item.name);
      if (slugRes.data.item.origin_name && slugRes.data.item.origin_name.length > 0) {
        keyword = encodeURIComponent(slugRes.data.item.origin_name[0]);
      }
      const tsContent = `export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=${keyword}";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/${slugRes.data.item.slug}";

export const queryByChapter =
  "${chapterData.chapter_api_data}";
`;
      fs.writeFileSync(path.join(folderName, 'url.ts'), tsContent);
      
      console.log(`Successfully verified and saved ${enSlug}`);
      await delay(1000);
    } catch (e) {
      console.error(`Error processing:`, e.message);
    }
  }
};

main();
