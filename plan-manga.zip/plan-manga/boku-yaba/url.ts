export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=The%20Bad%20Part%20of%20My%20Heart";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/boku-no-kokoro-yabai-yatsu";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/659124ebe120ddf219925585";
