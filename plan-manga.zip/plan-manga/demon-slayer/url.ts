export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=Kimetsu%20no%20Yaiba";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/thanh-guom-diet-quy";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/65a7f7d2d9c91173cd7d2463";
