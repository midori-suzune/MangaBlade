# Prompt tìm 5 truyện trên OTruyen có dữ liệu tương thích DTO

```text
Analyze the attached Wind-Breaker sample JSON files and Java response classes.

Find 5 other manga, manhwa, or webcomics that meet all of these requirements:

1. They must have readable English-language or Vietnamese-language chapters.
2. Exclude horror, adult, hentai, ecchi, smut, mature sexual content, and 18+ titles.
3. Prefer action, adventure, comedy, fantasy, sports, school life, or slice-of-life.
4. All manga data must come exclusively from OTruyen. Only use `https://otruyenapi.com` for search and manga metadata, plus chapter API URLs returned by OTruyen under `otruyencdn.com`. Do not use MangaDex or any other provider.
5. Do not invent titles, IDs, API endpoints, chapter URLs, or image URLs.
6. Verify that every provided endpoint works and returns real data.
7. Each title must have at least one readable English or Vietnamese chapter.
8. Use the original OTruyen JSON structure and ensure it provides enough data to populate the following DTO fields.

Required manga fields:
- externalMangaId: string
- name: string
- slug: string
- description: string
- originNames: string[]
- status: string
- thumbUrl: string
- updatedAt: ISO-8601 datetime
- authors: string[]
- categories: array of:
  - externalCategoryId: string
  - name: string
  - slug: string

Required chapter fields:
- serverName: string
- chapterNumber: string
- title: string
- chapterApiUrl: string
- language: "en" for English or "vi" for Vietnamese

Required chapter image fields:
- pageNumber: integer
- imageFile or imageUrl: string
- domainCdn: string, if the URL must be constructed
- chapterPath: string, if the URL must be constructed

For each of the 5 titles, return:

1. Title and author.
2. Genres and content rating.
3. The OTruyen API URLs used.
4. OTruyen manga metadata endpoint.
5. OTruyen chapter-list endpoint.
6. One real OTruyen English or Vietnamese chapter endpoint.
7. Cover-image URL or instructions for constructing it.
8. Chapter-page/image endpoint or exact instructions for constructing image URLs.
9. A mapping table:
   Required DTO field | Source JSON path | Example value
10. State which required fields are unavailable and suggest a safe fallback.
11. A compact normalized JSON example matching this structure:

{
  "externalMangaId": "",
  "name": "",
  "slug": "",
  "description": "",
  "originNames": [],
  "status": "",
  "thumbUrl": "",
  "updatedAt": "",
  "authors": [],
  "categories": [
    {
      "externalCategoryId": "",
      "name": "",
      "slug": ""
    }
  ],
  "chapters": [
    {
      "serverName": "",
      "chapterNumber": "",
      "title": "",
      "chapterApiUrl": "",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": ""
        }
      ]
    }
  ]
}

After verifying each manga, immediately create a separate folder for it. Do not wait until all five manga have been researched.

Use this folder structure:

<project-root>/
  <manga-slug>/
    responseBySearch.json
    responseBySlug.json
    responseByChapter.json

Folder and file requirements:

- Use a filesystem-safe English slug for the folder name, for example `blue-lock`.
- Create exactly one folder for each verified manga, for a total of five new folders.
- `responseBySearch.json` must contain the real raw API response used to find the manga.
- `responseBySlug.json` must contain the real raw API response containing the manga metadata and chapter list.
- `responseByChapter.json` must contain the real raw API response for one readable English or Vietnamese chapter, including its page/image data or the data required to construct its page URLs.
- Keep each original OTruyen response unchanged. Do not manually invent missing API fields.
- Every JSON file must be valid JSON and must be pretty-printed using two-space indentation.
- Do not place Markdown, comments, explanations, or placeholder values inside JSON files.
- Validate all three JSON files before considering a manga complete.
- Save exactly one successful raw OTruyen response in each required JSON file; do not combine data from another provider.
- If any manga cannot produce all three required JSON files, reject it and find another manga.

Required execution order for each manga:

1. Find a candidate with English or Vietnamese chapters and acceptable content.
2. Verify its metadata, cover, chapter list, and at least one English or Vietnamese chapter.
3. Verify that its response fields can populate the required DTO fields.
4. Create the manga folder.
5. Save and validate `responseBySearch.json`.
6. Save and validate `responseBySlug.json`.
7. Save and validate `responseByChapter.json`.
8. Only then continue to the next manga.

At the end, print the five created folder paths and a short validation result for each JSON file.

Important:
- At least one readable English-language or Vietnamese-language chapter is mandatory, not merely metadata in one of those languages.
- Do not return Wind Breaker.
- Do not include horror or 18+ content.
- OTruyen is the only permitted provider for all five titles. Reject results from MangaDex, AniList, MyAnimeList, ComicK, Webtoon, or any other source.
- Use these OTruyen endpoint patterns:
  - Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=<URL_ENCODED_TITLE>`
  - Manga metadata and chapters: `https://otruyenapi.com/v1/api/truyen-tranh/<slug>`
  - Chapter detail: use the exact `chapter_api_data` URL returned in `data.item.chapters[].server_data[]`.
- Confirm that `responseBySearch.json`, `responseBySlug.json`, and `responseByChapter.json` are raw OTruyen responses with `status: "success"`.
- OTruyen does not expose a reliable chapter-language field. Do not infer the language from the manga title. Verify that the actual chapter pages contain English or Vietnamese text and set the normalized `language` field to `en` or `vi` accordingly. If this cannot be verified, reject the manga.
- Clearly separate verified facts from assumptions.
- If live web/API access is unavailable, do not fabricate results; instead provide exact API requests that I can run to verify them.
```

## Tệp tham chiếu nên đính kèm

- `Wind-Breaker/responseBySearch.json`
- `Wind-Breaker/responseBySlug.json`
- `Wind-Breaker/responseByChapter.json`
- `Wind-Breaker/otruyen/response/OTruyenMangaResponse.java`
- `Wind-Breaker/otruyen/response/OTruyenChapterResponse.java`
- `Wind-Breaker/otruyen/response/OTruyenChapterDetailResponse.java`
- `Wind-Breaker/otruyen/response/OtruyenCategoryResponse.java`
