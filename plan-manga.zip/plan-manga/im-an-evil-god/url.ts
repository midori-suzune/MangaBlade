export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=Ng%C3%A3%20Vi%20T%C3%A0%20%C4%90%E1%BA%BF";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/ta-la-ta-de";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/65915304e120ddf21992a126";
