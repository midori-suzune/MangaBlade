export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=Kaguyahime%20no%20Kakushigoto";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/bi-mat-tham-kin-cua-cong-chua-kaguya";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/65754e26a7b870682dc448fa";
