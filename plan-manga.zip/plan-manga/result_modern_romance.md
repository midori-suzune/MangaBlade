# OTruyen Modern Romance Manga Research Results

## 1. Blue Box

**1. Title and author**
- Title: Blue Box (Ao no Hako)
- Author: Kouji Miura

**2. Genres and content rating**
- Genres: Manga, Romance, School Life, Shounen, Sports
- Content Rating: Safe (Modern Romance, School Life)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=Ao%20no%20Hako`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/blue-box`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/6591248fe120ddf2199253f6`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/blue-box`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/blue-box` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/6591248fe120ddf2199253f6` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/blue-box-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231231/7d6d8f814e485ec86a2fc84e0da0362e/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `6591200610dc9c0a7e2e54cc` |
| `name` | `name` | `Blue Box` |
| `slug` | `slug` | `blue-box` |
| `description` | `content` | `<p>Taiki Inomata, năm ba sơ trung, là thành viên c...` |
| `originNames` | `origin_name` | `["Ao no Hako"]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `blue-box-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2026-05-07T03:52:27.793Z` |
| `authors` | `author` | `["Kouji Miura"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4d6", "name": "Manga", "slug": "manga" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `Chinatsu senpai` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/6591248fe120ddf2199253f6` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231231/7d6d8f814e485ec86a2fc84e0da0362e/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Fallback: Assumed `vi`.
- `description`: Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "6591200610dc9c0a7e2e54cc",
  "name": "Blue Box",
  "slug": "blue-box",
  "description": "<p>Taiki Inomata, năm ba sơ trung, là thành viên c...",
  "originNames": ["Ao no Hako"],
  "status": "ongoing",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/blue-box-thumb.jpg",
  "updatedAt": "2026-05-07T03:52:27.793Z",
  "authors": ["Kouji Miura"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a4d6",
      "name": "Manga",
      "slug": "manga"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "Chinatsu senpai",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/6591248fe120ddf2199253f6",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231231/7d6d8f814e485ec86a2fc84e0da0362e/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## 2. The Fragrant Flower Blooms With Dignity - Kaoru Hana Wa Rin To Saku

**1. Title and author**
- Title: The Fragrant Flower Blooms With Dignity - Kaoru Hana Wa Rin To Saku (Những đóa hoa thơm nở diễm kiều)
- Author: Đang cập nhật

**2. Genres and content rating**
- Genres: Comedy, Drama, Manga, Romance, School Life
- Content Rating: Safe (Modern Romance, School Life)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=Nh%E1%BB%AFng%20%C4%91%C3%B3a%20hoa%20th%C6%A1m%20n%E1%BB%9F%20di%E1%BB%85m%20ki%E1%BB%81u`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/the-fragrant-flower-blooms-with-dignity-kaoru-hana-wa-rin-to-saku`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/662c8b548d19104b9c75d2ef`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/the-fragrant-flower-blooms-with-dignity-kaoru-hana-wa-rin-to-saku`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/the-fragrant-flower-blooms-with-dignity-kaoru-hana-wa-rin-to-saku` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/662c8b548d19104b9c75d2ef` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/the-fragrant-flower-blooms-with-dignity-kaoru-hana-wa-rin-to-saku-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20240427/cdcbe4b2888910d32679b80f48f43963/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `658e781710dc9c0a7e2e4520` |
| `name` | `name` | `The Fragrant Flower Blooms With Dignity - Kaoru Hana Wa Rin To Saku` |
| `slug` | `slug` | `the-fragrant-flower-blooms-with-dignity-kaoru-hana-wa-rin-to-saku` |
| `description` | `content` | `<p>Đang cập nhật</p>...` |
| `originNames` | `origin_name` | `["Những đóa hoa thơm nở diễm kiều", "Kaoru Hana Wa Rin To Saku"]` |
| `status` | `status` | `coming_soon` |
| `thumbUrl` | `thumb_url` | `the-fragrant-flower-blooms-with-dignity-kaoru-hana-wa-rin-to-saku-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2026-03-22T05:10:52.788Z` |
| `authors` | `author` | `["Đang cập nhật"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4af", "name": "Comedy", "slug": "comedy" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `Rintaro và Kaoruko` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/662c8b548d19104b9c75d2ef` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20240427/cdcbe4b2888910d32679b80f48f43963/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Fallback: Assumed `vi`.
- `description`: Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "658e781710dc9c0a7e2e4520",
  "name": "The Fragrant Flower Blooms With Dignity - Kaoru Hana Wa Rin To Saku",
  "slug": "the-fragrant-flower-blooms-with-dignity-kaoru-hana-wa-rin-to-saku",
  "description": "<p>Đang cập nhật</p>...",
  "originNames": ["Những đóa hoa thơm nở diễm kiều","Kaoru Hana Wa Rin To Saku"],
  "status": "coming_soon",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/the-fragrant-flower-blooms-with-dignity-kaoru-hana-wa-rin-to-saku-thumb.jpg",
  "updatedAt": "2026-03-22T05:10:52.788Z",
  "authors": ["Đang cập nhật"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a4af",
      "name": "Comedy",
      "slug": "comedy"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "Rintaro và Kaoruko",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/662c8b548d19104b9c75d2ef",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20240427/cdcbe4b2888910d32679b80f48f43963/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## Validation Results

- **blue-box**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **kaoru-hana**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **roshidere**:
  - `responseBySearch.json`: Validated (Missing)
  - `responseBySlug.json`: Validated (Missing)
  - `responseByChapter.json`: Validated (Missing)

- **boku-yaba**:
  - `responseBySearch.json`: Validated (Missing)
  - `responseBySlug.json`: Validated (Missing)
  - `responseByChapter.json`: Validated (Missing)

- **makeine**:
  - `responseBySearch.json`: Validated (Missing)
  - `responseBySlug.json`: Validated (Missing)
  - `responseByChapter.json`: Validated (Missing)

# OTruyen Modern Romance Manga Research Results

## 3. Arya bàn bên thỉnh thoảng lại trêu ghẹo tôi bằng tiếng Nga

**1. Title and author**
- Title: Arya bàn bên thỉnh thoảng lại trêu ghẹo tôi bằng tiếng Nga (My Deskmate Alya Sometimes Hides Her Feelings in Russian)
- Author: Sansan Sun, Tenamachi Saho

**2. Genres and content rating**
- Genres: Comedy, Manga, Romance, School Life, Slice of Life
- Content Rating: Safe (Modern Romance, School Life)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=My%20Deskmate%20Alya%20Sometimes%20Hides%20Her%20Feelings%20in%20Russian`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/arya-ban-ben-thinh-thoang-lai-treu-gheo-toi-bang-tieng-nga`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/65901601ac52820f564b31de`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/arya-ban-ben-thinh-thoang-lai-treu-gheo-toi-bang-tieng-nga`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/arya-ban-ben-thinh-thoang-lai-treu-gheo-toi-bang-tieng-nga` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/65901601ac52820f564b31de` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/arya-ban-ben-thinh-thoang-lai-treu-gheo-toi-bang-tieng-nga-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231230/1421c8613e0a2683376924c353942a86/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `658f7d3268e54cf5b509081f` |
| `name` | `name` | `Arya bàn bên thỉnh thoảng lại trêu ghẹo tôi bằng tiếng Nga` |
| `slug` | `slug` | `arya-ban-ben-thinh-thoang-lai-treu-gheo-toi-bang-tieng-nga` |
| `description` | `content` | `<p>Tôi- một cậu học sinh lười nhát nhất trường, lạ...` |
| `originNames` | `origin_name` | `["My Deskmate Alya Sometimes Hides Her Feelings in Russian", "Tokidoki Bosotto Roshia", "go de Dereru Tonari no Ārya", "san"]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `arya-ban-ben-thinh-thoang-lai-treu-gheo-toi-bang-tieng-nga-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2026-06-04T07:19:41.594Z` |
| `authors` | `author` | `["Sansan Sun", "Tenamachi Saho"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4af", "name": "Comedy", "slug": "comedy" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `Nàng công chúa lạnh lùng và tên bàn bên lười nhát` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/65901601ac52820f564b31de` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231230/1421c8613e0a2683376924c353942a86/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Fallback: Assumed `vi`.
- `description`: Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "658f7d3268e54cf5b509081f",
  "name": "Arya bàn bên thỉnh thoảng lại trêu ghẹo tôi bằng tiếng Nga",
  "slug": "arya-ban-ben-thinh-thoang-lai-treu-gheo-toi-bang-tieng-nga",
  "description": "<p>Tôi- một cậu học sinh lười nhát nhất trường, lạ...",
  "originNames": ["My Deskmate Alya Sometimes Hides Her Feelings in Russian","Tokidoki Bosotto Roshia","go de Dereru Tonari no Ārya","san"],
  "status": "ongoing",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/arya-ban-ben-thinh-thoang-lai-treu-gheo-toi-bang-tieng-nga-thumb.jpg",
  "updatedAt": "2026-06-04T07:19:41.594Z",
  "authors": ["Sansan Sun","Tenamachi Saho"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a4af",
      "name": "Comedy",
      "slug": "comedy"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "Nàng công chúa lạnh lùng và tên bàn bên lười nhát",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/65901601ac52820f564b31de",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231230/1421c8613e0a2683376924c353942a86/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## 4. Boku No Kokoro Yabai Yatsu

**1. Title and author**
- Title: Boku No Kokoro Yabai Yatsu (The Bad Part of My Heart)
- Author: Sakurai Norio, Goru

**2. Genres and content rating**
- Genres: Comedy, Manga, Romance, School Life, Shounen, Slice of Life
- Content Rating: Safe (Modern Romance, School Life)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=The%20Bad%20Part%20of%20My%20Heart`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/boku-no-kokoro-yabai-yatsu`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/659124ebe120ddf219925585`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/boku-no-kokoro-yabai-yatsu`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/boku-no-kokoro-yabai-yatsu` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/659124ebe120ddf219925585` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/boku-no-kokoro-yabai-yatsu-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231231/b6af533834d82552f8b791242b4ff8e0/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `65911fdc10dc9c0a7e2e5482` |
| `name` | `name` | `Boku No Kokoro Yabai Yatsu` |
| `slug` | `slug` | `boku-no-kokoro-yabai-yatsu` |
| `description` | `content` | `<p>Một "manga kinh dị" tập trung khai thác "mặt tố...` |
| `originNames` | `origin_name` | `["The Bad Part of My Heart", "Boku No Kokoro No Yabai Yatsu"]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `boku-no-kokoro-yabai-yatsu-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2026-02-07T03:14:57.486Z` |
| `authors` | `author` | `["Sakurai Norio", "Goru"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4af", "name": "Comedy", "slug": "comedy" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/659124ebe120ddf219925585` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231231/b6af533834d82552f8b791242b4ff8e0/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Fallback: Assumed `vi`.
- `description`: Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "65911fdc10dc9c0a7e2e5482",
  "name": "Boku No Kokoro Yabai Yatsu",
  "slug": "boku-no-kokoro-yabai-yatsu",
  "description": "<p>Một \"manga kinh dị\" tập trung khai thác \"mặt tố...",
  "originNames": ["The Bad Part of My Heart","Boku No Kokoro No Yabai Yatsu"],
  "status": "ongoing",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/boku-no-kokoro-yabai-yatsu-thumb.jpg",
  "updatedAt": "2026-02-07T03:14:57.486Z",
  "authors": ["Sakurai Norio","Goru"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a4af",
      "name": "Comedy",
      "slug": "comedy"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/659124ebe120ddf219925585",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231231/b6af533834d82552f8b791242b4ff8e0/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## Validation Results

- **roshidere**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **boku-yaba**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **makeine**:
  - `responseBySearch.json`: Validated (Missing)
  - `responseBySlug.json`: Validated (Missing)
  - `responseByChapter.json`: Validated (Missing)

## 5. Bí mật thầm kín của công chúa Kaguya

**1. Title and author**
- Title: Bí mật thầm kín của công chúa Kaguya (Kaguyahime no Kakushigoto)
- Author: Đang cập nhật

**2. Genres and content rating**
- Genres: Comedy, Drama, Fantasy, Historical, Shoujo
- Content Rating: Safe (Modern Romance, School Life)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=Kaguyahime%20no%20Kakushigoto`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/bi-mat-tham-kin-cua-cong-chua-kaguya`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/65754e26a7b870682dc448fa`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/bi-mat-tham-kin-cua-cong-chua-kaguya`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/bi-mat-tham-kin-cua-cong-chua-kaguya` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/65754e26a7b870682dc448fa` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/bi-mat-tham-kin-cua-cong-chua-kaguya-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231210/8f6ef3031d82cae185c19c5d18ec84ef/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `6575630110dc9c0a7e2d9bc7` |
| `name` | `name` | `Bí mật thầm kín của công chúa Kaguya` |
| `slug` | `slug` | `bi-mat-tham-kin-cua-cong-chua-kaguya` |
| `description` | `content` | `<p>Vào thời Heian, có một công chúa xinh đẹp mà ho...` |
| `originNames` | `origin_name` | `["Kaguyahime no Kakushigoto"]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `bi-mat-tham-kin-cua-cong-chua-kaguya-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2023-12-10T11:37:08.837Z` |
| `authors` | `author` | `["Đang cập nhật"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4af", "name": "Comedy", "slug": "comedy" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/65754e26a7b870682dc448fa` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231210/8f6ef3031d82cae185c19c5d18ec84ef/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Fallback: Assumed `vi`.
- `description`: Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{ "externalMangaId": "6575630110dc9c0a7e2d9bc7", "name": "Bí mật thầm kín của công chúa Kaguya", "slug": "bi-mat-tham-kin-cua-cong-chua-kaguya", "description": "<p>Vào thời Heian, có một công chúa xinh đẹp mà ho...", "originNames": ["Kaguyahime no Kakushigoto"], "status": "ongoing", "thumbUrl": "https://img.otruyenapi.com/uploads/comics/bi-mat-tham-kin-cua-cong-chua-kaguya-thumb.jpg", "updatedAt": "2023-12-10T11:37:08.837Z", "authors": ["Đang cập nhật"], "categories": [ { "externalCategoryId": "6508654905d5791ad671a4af", "name": "Comedy", "slug": "comedy" } ], "chapters": [ { "serverName": "Server #1", "chapterNumber": "1", "title": "", "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/65754e26a7b870682dc448fa", "language": "vi", "images": [ { "pageNumber": 1, "imageUrl": "https://sv1.otruyencdn.com/uploads/20231210/8f6ef3031d82cae185c19c5d18ec84ef/chapter_1/page_1.jpg" } ] } ] }
```

## Validation Results

- **blue-box**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **kaoru-hana**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **roshidere**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **boku-yaba**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **kaguya-sama**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

