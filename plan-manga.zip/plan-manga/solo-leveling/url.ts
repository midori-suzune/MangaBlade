export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/toi-thang-cap-mot-minh";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/6568621ae120ddf21985fed6";
