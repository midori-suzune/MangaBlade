export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/than-dong-dat-viet";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/65570b8c5f7c20cfed7c0aa4";
