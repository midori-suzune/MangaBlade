export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=My%20Deskmate%20Alya%20Sometimes%20Hides%20Her%20Feelings%20in%20Russian";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/arya-ban-ben-thinh-thoang-lai-treu-gheo-toi-bang-tieng-nga";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/65901601ac52820f564b31de";
