const fs = require('fs');
const path = require('path');
const https = require('https');

const fetchJson = (url) => {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
  });
};

const delay = ms => new Promise(res => setTimeout(res, ms));

const BAD_GENRES = ["Horror", "Adult", "Hentai", "Ecchi", "Smut", "Mature", "18+"];

const main = async () => {
  // Try finding some popular mangas
  const candidates = ["tham-tu-lung-danh-conan", "doraemon", "bay-vien-ngoc-rong", "naruto", "thanh-guom-diet-quy", "than-dong-dat-viet", "vo-luyen-dien-phong"];
  let found = 0;

  for (const slug of candidates) {
    if (found >= 5) break;

    try {
      console.log(`Checking ${slug}...`);
      
      const searchRes = await fetchJson(`https://otruyenapi.com/v1/api/tim-kiem?keyword=${slug}`);
      if (searchRes.status !== 'success' || !searchRes.data.items || searchRes.data.items.length === 0) continue;
      
      const slugRes = await fetchJson(`https://otruyenapi.com/v1/api/truyen-tranh/${slug}`);
      if (slugRes.status !== 'success') continue;
      
      const item = slugRes.data.item;
      const categories = item.category.map(c => c.name);
      
      const hasBadGenre = categories.some(c => BAD_GENRES.some(bg => c.toLowerCase().includes(bg.toLowerCase())));
      if (hasBadGenre) {
        console.log(`Skipping ${slug} due to bad genres: ${categories.join(', ')}`);
        continue;
      }
      
      if (!item.chapters || item.chapters.length === 0 || !item.chapters[0].server_data || item.chapters[0].server_data.length === 0) {
        console.log(`Skipping ${slug} due to no chapters`);
        continue;
      }
      
      const chapterData = item.chapters[0].server_data[0];
      const chapterApiUrl = chapterData.chapter_api_data;
      
      const chapterRes = await fetchJson(chapterApiUrl);
      if (chapterRes.status !== 'success') continue;
      
      // Found one
      const folderName = slug;
      fs.mkdirSync(folderName, { recursive: true });
      fs.writeFileSync(path.join(folderName, 'responseBySearch.json'), JSON.stringify(searchRes, null, 2));
      fs.writeFileSync(path.join(folderName, 'responseBySlug.json'), JSON.stringify(slugRes, null, 2));
      fs.writeFileSync(path.join(folderName, 'responseByChapter.json'), JSON.stringify(chapterRes, null, 2));
      
      console.log(`Successfully verified and saved ${slug}`);
      found++;
      
      await delay(1000); // polite delay
    } catch (e) {
      console.error(`Error processing ${slug}:`, e.message);
    }
  }
  
  if (found < 5) {
    console.log(`Only found ${found} manga.`);
  } else {
    console.log("Successfully found 5 manga.");
  }
};

main();
