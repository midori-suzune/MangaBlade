# OTruyen Manga Research Results

## 1. Thám Tử Lừng Danh Conan

**1. Title and author**
- Title: Thám Tử Lừng Danh Conan (Thám Tử Lừng Danh Conan)
- Author: TruyenQQ

**2. Genres and content rating**
- Genres: Action
- Content Rating: Safe (No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=tham-tu-lung-danh-conan`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/tham-tu-lung-danh-conan`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/69ba380e7b89b5b2570e4082`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/tham-tu-lung-danh-conan`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/tham-tu-lung-danh-conan` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/69ba380e7b89b5b2570e4082` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/tham-tu-lung-danh-conan-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20260318/3cffe4367617f4b9635e8740a731041a/chapter_0/page_0.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `69afc1080a67720d2360b71b` |
| `name` | `name` | `Thám Tử Lừng Danh Conan` |
| `slug` | `slug` | `tham-tu-lung-danh-conan` |
| `description` | `content` | `Thám Tử Lừng Danh Conan - Thám Tử Lừng Danh Conan...` |
| `originNames` | `origin_name` | `["Thám Tử Lừng Danh Conan"]` |
| `status` | `status` | `coming_soon` |
| `thumbUrl` | `thumb_url` | `tham-tu-lung-danh-conan-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2026-04-12T08:03:45.895Z` |
| `authors` | `author` | `["TruyenQQ"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a491", "name": "Action", "slug": "action" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `0` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/69ba380e7b89b5b2570e4082` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_0.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20260318/3cffe4367617f4b9635e8740a731041a/chapter_0` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "69afc1080a67720d2360b71b",
  "name": "Thám Tử Lừng Danh Conan",
  "slug": "tham-tu-lung-danh-conan",
  "description": "Thám Tử Lừng Danh Conan - Thám Tử Lừng Danh Conan...",
  "originNames": ["Thám Tử Lừng Danh Conan"],
  "status": "coming_soon",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/tham-tu-lung-danh-conan-thumb.jpg",
  "updatedAt": "2026-04-12T08:03:45.895Z",
  "authors": ["TruyenQQ"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a491",
      "name": "Action",
      "slug": "action"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "0",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/69ba380e7b89b5b2570e4082",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20260318/3cffe4367617f4b9635e8740a731041a/chapter_0/page_0.jpg"
        }
      ]
    }
  ]
}
```

## 2. Doraemon

**1. Title and author**
- Title: Doraemon (Đôrêmon)
- Author: Fujiko F.Fujio

**2. Genres and content rating**
- Genres: Anime, Comedy, Fantasy, Historical, School Life, Shounen, Slice of Life, Supernatural, Thiếu Nhi
- Content Rating: Safe (No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=doraemon`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/doraemon`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/65901b5de120ddf2199227bc`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/doraemon`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/doraemon` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/65901b5de120ddf2199227bc` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/doraemon-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231230/7ec37ec828310e9a761643dbf3d2c642/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `658f7e2668e54cf5b50909b6` |
| `name` | `name` | `Doraemon` |
| `slug` | `slug` | `doraemon` |
| `description` | `content` | `<p>Đôrêmon là một chú mèo máy được Nôbita, cháu ba...` |
| `originNames` | `origin_name` | `["Đôrêmon"]` |
| `status` | `status` | `completed` |
| `thumbUrl` | `thumb_url` | `doraemon-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2023-12-30T17:06:13.528Z` |
| `authors` | `author` | `["Fujiko F.Fujio"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4a9", "name": "Anime", "slug": "anime" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `Tập 1   Doraemon đã đến với Nobita thế nào` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/65901b5de120ddf2199227bc` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231230/7ec37ec828310e9a761643dbf3d2c642/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "658f7e2668e54cf5b50909b6",
  "name": "Doraemon",
  "slug": "doraemon",
  "description": "<p>Đôrêmon là một chú mèo máy được Nôbita, cháu ba...",
  "originNames": ["Đôrêmon"],
  "status": "completed",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/doraemon-thumb.jpg",
  "updatedAt": "2023-12-30T17:06:13.528Z",
  "authors": ["Fujiko F.Fujio"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a4a9",
      "name": "Anime",
      "slug": "anime"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "Tập 1   Doraemon đã đến với Nobita thế nào",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/65901b5de120ddf2199227bc",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231230/7ec37ec828310e9a761643dbf3d2c642/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## 3. Thanh Gươm Diệt Quỷ

**1. Title and author**
- Title: Thanh Gươm Diệt Quỷ (Kimetsu no Yaiba)
- Author: Gotouge Koyoharu

**2. Genres and content rating**
- Genres: Drama, Fantasy, Historical, Manga, Shounen
- Content Rating: Safe (No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=thanh-guom-diet-quy`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/thanh-guom-diet-quy`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/65a7f7d2d9c91173cd7d2463`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/thanh-guom-diet-quy`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/thanh-guom-diet-quy` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/65a7f7d2d9c91173cd7d2463` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/thanh-guom-diet-quy-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20240117/da6a8aee12e4630a93426b6d75c2c5bd/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `6598989110dc9c0a7e2f48eb` |
| `name` | `name` | `Thanh Gươm Diệt Quỷ` |
| `slug` | `slug` | `thanh-guom-diet-quy` |
| `description` | `content` | `<p>Kimetsu no Yaiba – Tanjirou là con cả của gia đ...` |
| `originNames` | `origin_name` | `["Kimetsu no Yaiba", "Diệt Quỷ Cứu Nhân"]` |
| `status` | `status` | `completed` |
| `thumbUrl` | `thumb_url` | `thanh-guom-diet-quy-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2024-05-15T05:24:07.361Z` |
| `authors` | `author` | `["Gotouge Koyoharu"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4be", "name": "Drama", "slug": "drama" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/65a7f7d2d9c91173cd7d2463` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20240117/da6a8aee12e4630a93426b6d75c2c5bd/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "6598989110dc9c0a7e2f48eb",
  "name": "Thanh Gươm Diệt Quỷ",
  "slug": "thanh-guom-diet-quy",
  "description": "<p>Kimetsu no Yaiba – Tanjirou là con cả của gia đ...",
  "originNames": ["Kimetsu no Yaiba","Diệt Quỷ Cứu Nhân"],
  "status": "completed",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/thanh-guom-diet-quy-thumb.jpg",
  "updatedAt": "2024-05-15T05:24:07.361Z",
  "authors": ["Gotouge Koyoharu"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a4be",
      "name": "Drama",
      "slug": "drama"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/65a7f7d2d9c91173cd7d2463",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20240117/da6a8aee12e4630a93426b6d75c2c5bd/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## 4. One-Punch Man (Webcomic)

**1. Title and author**
- Title: One-Punch Man (Webcomic) (One)
- Author: TruyenQQ

**2. Genres and content rating**
- Genres: Action
- Content Rating: Safe (No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=one-punch-man-webcomic`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/one-punch-man-webcomic`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/69e901447b89b5b2570f7047`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/one-punch-man-webcomic`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/one-punch-man-webcomic` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/69e901447b89b5b2570f7047` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/one-punch-man-webcomic-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20260423/98dbf9d38033527c628f69559d1c0a6f/chapter_1/page_0.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `69e4a2da609fafd7f06cad4f` |
| `name` | `name` | `One-Punch Man (Webcomic)` |
| `slug` | `slug` | `one-punch-man-webcomic` |
| `description` | `content` | `One-Punch Man (Webcomic) - One - punch Man (webcom...` |
| `originNames` | `origin_name` | `["One", "punch Man (webcomic)"]` |
| `status` | `status` | `coming_soon` |
| `thumbUrl` | `thumb_url` | `one-punch-man-webcomic-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2026-04-23T09:56:52.902Z` |
| `authors` | `author` | `["TruyenQQ"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a491", "name": "Action", "slug": "action" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/69e901447b89b5b2570f7047` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_0.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20260423/98dbf9d38033527c628f69559d1c0a6f/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "69e4a2da609fafd7f06cad4f",
  "name": "One-Punch Man (Webcomic)",
  "slug": "one-punch-man-webcomic",
  "description": "One-Punch Man (Webcomic) - One - punch Man (webcom...",
  "originNames": ["One","punch Man (webcomic)"],
  "status": "coming_soon",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/one-punch-man-webcomic-thumb.jpg",
  "updatedAt": "2026-04-23T09:56:52.902Z",
  "authors": ["TruyenQQ"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a491",
      "name": "Action",
      "slug": "action"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/69e901447b89b5b2570f7047",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20260423/98dbf9d38033527c628f69559d1c0a6f/chapter_1/page_0.jpg"
        }
      ]
    }
  ]
}
```

## 5. Clover (Kuroobaa)

**1. Title and author**
- Title: Clover (Kuroobaa) (Kuroobaa)
- Author: Otsu Hiyori

**2. Genres and content rating**
- Genres: Comedy, Drama, School Life, Shoujo, Shoujo Ai, Slice of Life
- Content Rating: Safe (No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=clover-kuroobaa`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/clover-kuroobaa`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/65433ad219227e32c83aecf3`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/clover-kuroobaa`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/clover-kuroobaa` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/65433ad219227e32c83aecf3` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/clover-kuroobaa-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231102/44fe08fe62dc7e0ab3af896626fe4d83/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `65434010e29c23c6ae1b046e` |
| `name` | `name` | `Clover (Kuroobaa)` |
| `slug` | `slug` | `clover-kuroobaa` |
| `description` | `content` | `<p>Tuyển tập gồm những câu truyện ngắn xoay xung q...` |
| `originNames` | `origin_name` | `["Kuroobaa", "CLOVER (CHIYA TORIKO)"]` |
| `status` | `status` | `completed` |
| `thumbUrl` | `thumb_url` | `clover-kuroobaa-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2023-11-02T07:43:37.210Z` |
| `authors` | `author` | `["Otsu Hiyori"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4af", "name": "Comedy", "slug": "comedy" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/65433ad219227e32c83aecf3` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231102/44fe08fe62dc7e0ab3af896626fe4d83/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "65434010e29c23c6ae1b046e",
  "name": "Clover (Kuroobaa)",
  "slug": "clover-kuroobaa",
  "description": "<p>Tuyển tập gồm những câu truyện ngắn xoay xung q...",
  "originNames": ["Kuroobaa","CLOVER (CHIYA TORIKO)"],
  "status": "completed",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/clover-kuroobaa-thumb.jpg",
  "updatedAt": "2023-11-02T07:43:37.210Z",
  "authors": ["Otsu Hiyori"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a4af",
      "name": "Comedy",
      "slug": "comedy"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/65433ad219227e32c83aecf3",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231102/44fe08fe62dc7e0ab3af896626fe4d83/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## Validation Results

- **detective-conan**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **doraemon**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **demon-slayer**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **one-punch-man**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **black-clover**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

