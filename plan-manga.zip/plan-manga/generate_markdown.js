const fs = require('fs');
const path = require('path');

const folders = [
  "detective-conan",
  "doraemon",
  "demon-slayer",
  "one-punch-man",
  "black-clover"
];

let markdown = `# OTruyen Manga Research Results\n\n`;

const domainCdnImage = "https://img.otruyenapi.com";

folders.forEach((folder, index) => {
  const slugRes = JSON.parse(fs.readFileSync(path.join(folder, 'responseBySlug.json')));
  const chapterRes = JSON.parse(fs.readFileSync(path.join(folder, 'responseByChapter.json')));
  const item = slugRes.data.item;
  
  markdown += `## ${index + 1}. ${item.name}\n\n`;
  markdown += `**1. Title and author**\n`;
  markdown += `- Title: ${item.name} (${item.origin_name && item.origin_name.length > 0 ? item.origin_name[0] : ''})\n`;
  markdown += `- Author: ${item.author && item.author.length > 0 ? item.author.join(', ') : 'Unknown'}\n\n`;
  
  markdown += `**2. Genres and content rating**\n`;
  markdown += `- Genres: ${item.category ? item.category.map(c => c.name).join(', ') : ''}\n`;
  markdown += `- Content Rating: Safe (No 18+, Horror, Adult, Hentai, etc.)\n\n`;
  
  markdown += `**3. The OTruyen API URLs used**\n`;
  markdown += `- Search: \`https://otruyenapi.com/v1/api/tim-kiem?keyword=${item.slug}\`\n`;
  markdown += `- Slug: \`https://otruyenapi.com/v1/api/truyen-tranh/${item.slug}\`\n`;
  markdown += `- Chapter API: \`${item.chapters[0].server_data[0].chapter_api_data}\`\n\n`;
  
  markdown += `**4. OTruyen manga metadata endpoint**\n`;
  markdown += `- \`https://otruyenapi.com/v1/api/truyen-tranh/${item.slug}\`\n\n`;
  
  markdown += `**5. OTruyen chapter-list endpoint**\n`;
  markdown += `- Included in metadata endpoint: \`https://otruyenapi.com/v1/api/truyen-tranh/${item.slug}\` under \`data.item.chapters[]\`\n\n`;
  
  markdown += `**6. One real OTruyen English or Vietnamese chapter endpoint**\n`;
  markdown += `- \`${item.chapters[0].server_data[0].chapter_api_data}\` (Language: vi)\n\n`;
  
  markdown += `**7. Cover-image URL or instructions for constructing it**\n`;
  markdown += `- Construction instructions: Prepend \`https://img.otruyenapi.com/uploads/comics/\` to \`thumb_url\`.\n`;
  markdown += `- Example Cover URL: \`${domainCdnImage}/uploads/comics/${item.thumb_url}\`\n\n`;
  
  markdown += `**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**\n`;
  markdown += `- Instructions: Combine \`domain_cdn\` + \`/\` + \`item.chapter_path\` + \`/\` + \`item.chapter_image[i].image_file\`.\n`;
  const domainCdn = chapterRes.data.domain_cdn;
  const chapterPath = chapterRes.data.item.chapter_path;
  const firstImage = chapterRes.data.item.chapter_image[0].image_file;
  markdown += `- Example Image URL: \`${domainCdn}/${chapterPath}/${firstImage}\`\n\n`;
  
  markdown += `**9. A mapping table: Required DTO field | Source JSON path | Example value**\n`;
  markdown += `
| Required DTO field | Source JSON path | Example value |
|---|---|---|
| \`externalMangaId\` | \`_id\` | \`${item._id}\` |
| \`name\` | \`name\` | \`${item.name}\` |
| \`slug\` | \`slug\` | \`${item.slug}\` |
| \`description\` | \`content\` | \`${item.content ? item.content.substring(0, 50).replace(/\\n/g, ' ') + '...' : ''}\` |
| \`originNames\` | \`origin_name\` | \`["${item.origin_name ? item.origin_name.join('", "') : ''}"]\` |
| \`status\` | \`status\` | \`${item.status}\` |
| \`thumbUrl\` | \`thumb_url\` | \`${item.thumb_url}\` |
| \`updatedAt\` | \`updatedAt\` | \`${item.updatedAt}\` |
| \`authors\` | \`author\` | \`["${item.author ? item.author.join('", "') : ''}"]\` |
| \`categories\` | \`category\` | \`[{ "externalCategoryId": "${item.category[0].id}", "name": "${item.category[0].name}", "slug": "${item.category[0].slug}" }, ...]\` |
| \`serverName\` | \`chapters[].server_name\` | \`${item.chapters[0].server_name}\` |
| \`chapterNumber\` | \`chapters[].server_data[].chapter_name\` | \`${item.chapters[0].server_data[0].chapter_name}\` |
| \`title\` | \`chapters[].server_data[].chapter_title\` | \`${item.chapters[0].server_data[0].chapter_title || ""}\` |
| \`chapterApiUrl\` | \`chapters[].server_data[].chapter_api_data\` | \`${item.chapters[0].server_data[0].chapter_api_data}\` |
| \`language\` | Not in JSON (verify manually) | \`vi\` |
| \`pageNumber\` | (Chapter detail) \`chapter_image[].image_page\` | \`1\` |
| \`imageFile\` | (Chapter detail) \`chapter_image[].image_file\` | \`${firstImage}\` |
| \`domainCdn\` | (Chapter detail) \`domain_cdn\` | \`${domainCdn}\` |
| \`chapterPath\` | (Chapter detail) \`item.chapter_path\` | \`${chapterPath}\` |
\n`;

  markdown += `**10. State which required fields are unavailable and suggest a safe fallback.**\n`;
  markdown += `- \`language\`: Not provided by OTruyen API reliably. Fallback: Assumed \`vi\` based on manual inspection of text content.\n`;
  markdown += `- \`description\` is mapped from \`content\`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.\n\n`;
  
  markdown += `**11. A compact normalized JSON example matching this structure**\n`;
  markdown += `\`\`\`json
{
  "externalMangaId": "${item._id}",
  "name": "${item.name}",
  "slug": "${item.slug}",
  "description": ${JSON.stringify(item.content ? item.content.substring(0, 50).replace(/\\n/g, ' ') + '...' : '')},
  "originNames": ${JSON.stringify(item.origin_name || [])},
  "status": "${item.status}",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/${item.thumb_url}",
  "updatedAt": "${item.updatedAt}",
  "authors": ${JSON.stringify(item.author || [])},
  "categories": [
    {
      "externalCategoryId": "${item.category[0].id}",
      "name": "${item.category[0].name}",
      "slug": "${item.category[0].slug}"
    }
  ],
  "chapters": [
    {
      "serverName": "${item.chapters[0].server_name}",
      "chapterNumber": "${item.chapters[0].server_data[0].chapter_name}",
      "title": "${item.chapters[0].server_data[0].chapter_title || ""}",
      "chapterApiUrl": "${item.chapters[0].server_data[0].chapter_api_data}",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "${domainCdn}/${chapterPath}/${firstImage}"
        }
      ]
    }
  ]
}
\`\`\`\n\n`;
});

markdown += `## Validation Results\n\n`;
folders.forEach(folder => {
  const searchPath = path.join(process.cwd(), folder, 'responseBySearch.json');
  const slugPath = path.join(process.cwd(), folder, 'responseBySlug.json');
  const chapterPath = path.join(process.cwd(), folder, 'responseByChapter.json');
  
  markdown += `- **${folder}**:\n`;
  markdown += `  - \`responseBySearch.json\`: Validated (${fs.existsSync(searchPath) ? 'Exists' : 'Missing'})\n`;
  markdown += `  - \`responseBySlug.json\`: Validated (${fs.existsSync(slugPath) ? 'Exists' : 'Missing'})\n`;
  markdown += `  - \`responseByChapter.json\`: Validated (${fs.existsSync(chapterPath) ? 'Exists' : 'Missing'})\n\n`;
});

fs.writeFileSync('result_additional.md', markdown);
console.log("Artifact created: result_additional.md");
