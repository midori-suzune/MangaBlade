export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=H%C3%A0nh%20Tr%C3%ACnh%20Tu%20Ti%C3%AAn";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/bach-luyen-thanh-than";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/659121ecac52820f564b6af7";
