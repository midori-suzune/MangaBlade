export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=One%20Piece";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/dao-hai-tac";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/65901d64ac52820f564b373e";
