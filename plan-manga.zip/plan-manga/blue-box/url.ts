export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=Ao%20no%20Hako";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/blue-box";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/6591248fe120ddf2199253f6";
