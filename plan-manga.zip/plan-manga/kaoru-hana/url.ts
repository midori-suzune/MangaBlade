export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=Nh%E1%BB%AFng%20%C4%91%C3%B3a%20hoa%20th%C6%A1m%20n%E1%BB%9F%20di%E1%BB%85m%20ki%E1%BB%81u";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/the-fragrant-flower-blooms-with-dignity-kaoru-hana-wa-rin-to-saku";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/662c8b548d19104b9c75d2ef";
