# OTruyen Romance Manga Research Results

## 1. Horimiya

**1. Title and author**
- Title: Horimiya (Horimiya)
- Author: Hero, Hagiwara Daisuke

**2. Genres and content rating**
- Genres: Action
- Content Rating: Safe (Romance, School Life. No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=Horimiya`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/horimiya`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/6970592ce0d753f32e544047`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/horimiya`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/horimiya` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/6970592ce0d753f32e544047` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/horimiya-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20260121/23059641c2dae1565b0a3773475abf15/chapter_1/page_0.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `67762224a4a4a602fb7f7edd` |
| `name` | `name` | `Horimiya` |
| `slug` | `slug` | `horimiya` |
| `description` | `content` | `<p>Mỗi người đều có một mặt không muốn cho người k...` |
| `originNames` | `origin_name` | `["Horimiya"]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `horimiya-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2026-05-09T09:36:28.917Z` |
| `authors` | `author` | `["Hero", "Hagiwara Daisuke"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a491", "name": "Action", "slug": "action" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/6970592ce0d753f32e544047` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_0.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20260121/23059641c2dae1565b0a3773475abf15/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "67762224a4a4a602fb7f7edd",
  "name": "Horimiya",
  "slug": "horimiya",
  "description": "<p>Mỗi người đều có một mặt không muốn cho người k...",
  "originNames": ["Horimiya"],
  "status": "ongoing",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/horimiya-thumb.jpg",
  "updatedAt": "2026-05-09T09:36:28.917Z",
  "authors": ["Hero","Hagiwara Daisuke"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a491",
      "name": "Action",
      "slug": "action"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/6970592ce0d753f32e544047",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20260121/23059641c2dae1565b0a3773475abf15/chapter_1/page_0.jpg"
        }
      ]
    }
  ]
}
```

## 2. Toradora!

**1. Title and author**
- Title: Toradora! ()
- Author: Đang cập nhật

**2. Genres and content rating**
- Genres: Manga
- Content Rating: Safe (Romance, School Life. No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/toradora`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/6583ef12e120ddf2198de60b`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/toradora`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/toradora` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/6583ef12e120ddf2198de60b` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/toradora-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231221/99edac3f9fd9a0301e23ce62ceb8840e/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `6585001e68e54cf5b508c65e` |
| `name` | `name` | `Toradora!` |
| `slug` | `slug` | `toradora` |
| `description` | `content` | `<p>Toradora bắt đầu với nhân vật chính Ryuuji Taka...` |
| `originNames` | `origin_name` | `[""]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `toradora-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2023-12-22T03:25:06.406Z` |
| `authors` | `author` | `["Đang cập nhật"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4d6", "name": "Manga", "slug": "manga" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/6583ef12e120ddf2198de60b` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231221/99edac3f9fd9a0301e23ce62ceb8840e/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "6585001e68e54cf5b508c65e",
  "name": "Toradora!",
  "slug": "toradora",
  "description": "<p>Toradora bắt đầu với nhân vật chính Ryuuji Taka...",
  "originNames": [""],
  "status": "ongoing",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/toradora-thumb.jpg",
  "updatedAt": "2023-12-22T03:25:06.406Z",
  "authors": ["Đang cập nhật"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a4d6",
      "name": "Manga",
      "slug": "manga"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/6583ef12e120ddf2198de60b",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231221/99edac3f9fd9a0301e23ce62ceb8840e/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## 3. Khi sếp là hầu bàn

**1. Title and author**
- Title: Khi sếp là hầu bàn (Kaichou wa Maid)
- Author: Fujiwara Hiro

**2. Genres and content rating**
- Genres: Action, Comedy, Ngôn Tình, Romance, School Life, Shoujo, Slice of Life
- Content Rating: Safe (Romance, School Life. No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=Kaichou%20wa%20Maid`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/khi-sep-la-hau-ban`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/655b8c9fa7b870682dbf3d35`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/khi-sep-la-hau-ban`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/khi-sep-la-hau-ban` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/655b8c9fa7b870682dbf3d35` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/khi-sep-la-hau-ban-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231120/4ecab307d0ef53ac977bb87b482ddefe/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `655c132e10dc9c0a7e2d0894` |
| `name` | `name` | `Khi sếp là hầu bàn` |
| `slug` | `slug` | `khi-sep-la-hau-ban` |
| `description` | `content` | `<p>Misaki là hội trưởng hội học sinh của một ngôi ...` |
| `originNames` | `origin_name` | `["Kaichou wa Maid", "sama!"]` |
| `status` | `status` | `completed` |
| `thumbUrl` | `thumb_url` | `khi-sep-la-hau-ban-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2023-11-21T03:32:19.821Z` |
| `authors` | `author` | `["Fujiwara Hiro"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a491", "name": "Action", "slug": "action" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/655b8c9fa7b870682dbf3d35` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231120/4ecab307d0ef53ac977bb87b482ddefe/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "655c132e10dc9c0a7e2d0894",
  "name": "Khi sếp là hầu bàn",
  "slug": "khi-sep-la-hau-ban",
  "description": "<p>Misaki là hội trưởng hội học sinh của một ngôi ...",
  "originNames": ["Kaichou wa Maid","sama!"],
  "status": "completed",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/khi-sep-la-hau-ban-thumb.jpg",
  "updatedAt": "2023-11-21T03:32:19.821Z",
  "authors": ["Fujiwara Hiro"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a491",
      "name": "Action",
      "slug": "action"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/655b8c9fa7b870682dbf3d35",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231120/4ecab307d0ef53ac977bb87b482ddefe/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## 4. Relife

**1. Title and author**
- Title: Relife ()
- Author: Yayoi Sou

**2. Genres and content rating**
- Genres: Action
- Content Rating: Safe (Romance, School Life. No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/relife`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/692d1f017a48932b83d6c205`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/relife`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/relife` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/692d1f017a48932b83d6c205` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/relife-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20251201/37acc10a61f47e9dfa49ff98cfe2ac05/chapter_1/page_0.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `692bbd100a67720d230aeef4` |
| `name` | `name` | `Relife` |
| `slug` | `slug` | `relife` |
| `description` | `content` | `<p>Câu chuyện kể về Kaizaki Arata, 27 tuổi, FA, th...` |
| `originNames` | `origin_name` | `[""]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `relife-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2025-12-01T04:54:31.221Z` |
| `authors` | `author` | `["Yayoi Sou"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a491", "name": "Action", "slug": "action" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/692d1f017a48932b83d6c205` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_0.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20251201/37acc10a61f47e9dfa49ff98cfe2ac05/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "692bbd100a67720d230aeef4",
  "name": "Relife",
  "slug": "relife",
  "description": "<p>Câu chuyện kể về Kaizaki Arata, 27 tuổi, FA, th...",
  "originNames": [""],
  "status": "ongoing",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/relife-thumb.jpg",
  "updatedAt": "2025-12-01T04:54:31.221Z",
  "authors": ["Yayoi Sou"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a491",
      "name": "Action",
      "slug": "action"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/692d1f017a48932b83d6c205",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20251201/37acc10a61f47e9dfa49ff98cfe2ac05/chapter_1/page_0.jpg"
        }
      ]
    }
  ]
}
```

## 5. Tonari no Kaibutsu-kun

**1. Title and author**
- Title: Tonari no Kaibutsu-kun ()
- Author: Đang cập nhật

**2. Genres and content rating**
- Genres: Comedy, Romance, School Life, Shoujo
- Content Rating: Safe (Romance, School Life. No 18+, Horror, Adult, Hentai, etc.)

**3. The OTruyen API URLs used**
- Search: `https://otruyenapi.com/v1/api/tim-kiem?keyword=`
- Slug: `https://otruyenapi.com/v1/api/truyen-tranh/tonari-no-kaibutsu-kun`
- Chapter API: `https://sv1.otruyencdn.com/v1/api/chapter/65520e4b5f7c20cfed7b3d17`

**4. OTruyen manga metadata endpoint**
- `https://otruyenapi.com/v1/api/truyen-tranh/tonari-no-kaibutsu-kun`

**5. OTruyen chapter-list endpoint**
- Included in metadata endpoint: `https://otruyenapi.com/v1/api/truyen-tranh/tonari-no-kaibutsu-kun` under `data.item.chapters[]`

**6. One real OTruyen English or Vietnamese chapter endpoint**
- `https://sv1.otruyencdn.com/v1/api/chapter/65520e4b5f7c20cfed7b3d17` (Language: vi)

**7. Cover-image URL or instructions for constructing it**
- Construction instructions: Prepend `https://img.otruyenapi.com/uploads/comics/` to `thumb_url`.
- Example Cover URL: `https://img.otruyenapi.com/uploads/comics/tonari-no-kaibutsu-kun-thumb.jpg`

**8. Chapter-page/image endpoint or exact instructions for constructing image URLs**
- Instructions: Combine `domain_cdn` + `/` + `item.chapter_path` + `/` + `item.chapter_image[i].image_file`.
- Example Image URL: `https://sv1.otruyencdn.com/uploads/20231113/6718c633779f8e4890cd5e60a63fb803/chapter_1/page_1.jpg`

**9. A mapping table: Required DTO field | Source JSON path | Example value**

| Required DTO field | Source JSON path | Example value |
|---|---|---|
| `externalMangaId` | `_id` | `6552ae9f10dc9c0a7e2cca3e` |
| `name` | `name` | `Tonari no Kaibutsu-kun` |
| `slug` | `slug` | `tonari-no-kaibutsu-kun` |
| `description` | `content` | `<p>Yoshida Haru - Ngây thơ + điên khùng</p>...` |
| `originNames` | `origin_name` | `[""]` |
| `status` | `status` | `ongoing` |
| `thumbUrl` | `thumb_url` | `tonari-no-kaibutsu-kun-thumb.jpg` |
| `updatedAt` | `updatedAt` | `2023-11-14T10:29:28.741Z` |
| `authors` | `author` | `["Đang cập nhật"]` |
| `categories` | `category` | `[{ "externalCategoryId": "6508654905d5791ad671a4af", "name": "Comedy", "slug": "comedy" }, ...]` |
| `serverName` | `chapters[].server_name` | `Server #1` |
| `chapterNumber` | `chapters[].server_data[].chapter_name` | `1` |
| `title` | `chapters[].server_data[].chapter_title` | `Người ngồi cạnh t` |
| `chapterApiUrl` | `chapters[].server_data[].chapter_api_data` | `https://sv1.otruyencdn.com/v1/api/chapter/65520e4b5f7c20cfed7b3d17` |
| `language` | Not in JSON (verify manually) | `vi` |
| `pageNumber` | (Chapter detail) `chapter_image[].image_page` | `1` |
| `imageFile` | (Chapter detail) `chapter_image[].image_file` | `page_1.jpg` |
| `domainCdn` | (Chapter detail) `domain_cdn` | `https://sv1.otruyencdn.com` |
| `chapterPath` | (Chapter detail) `item.chapter_path` | `uploads/20231113/6718c633779f8e4890cd5e60a63fb803/chapter_1` |

**10. State which required fields are unavailable and suggest a safe fallback.**
- `language`: Not provided by OTruyen API reliably. Fallback: Assumed `vi` based on manual inspection of text content.
- `description` is mapped from `content`, which might contain HTML tags. Fallback: Parse or strip HTML tags before displaying.

**11. A compact normalized JSON example matching this structure**
```json
{
  "externalMangaId": "6552ae9f10dc9c0a7e2cca3e",
  "name": "Tonari no Kaibutsu-kun",
  "slug": "tonari-no-kaibutsu-kun",
  "description": "<p>Yoshida Haru - Ngây thơ + điên khùng</p>...",
  "originNames": [""],
  "status": "ongoing",
  "thumbUrl": "https://img.otruyenapi.com/uploads/comics/tonari-no-kaibutsu-kun-thumb.jpg",
  "updatedAt": "2023-11-14T10:29:28.741Z",
  "authors": ["Đang cập nhật"],
  "categories": [
    {
      "externalCategoryId": "6508654905d5791ad671a4af",
      "name": "Comedy",
      "slug": "comedy"
    }
  ],
  "chapters": [
    {
      "serverName": "Server #1",
      "chapterNumber": "1",
      "title": "Người ngồi cạnh t",
      "chapterApiUrl": "https://sv1.otruyencdn.com/v1/api/chapter/65520e4b5f7c20cfed7b3d17",
      "language": "vi",
      "images": [
        {
          "pageNumber": 1,
          "imageUrl": "https://sv1.otruyencdn.com/uploads/20231113/6718c633779f8e4890cd5e60a63fb803/chapter_1/page_1.jpg"
        }
      ]
    }
  ]
}
```

## Validation Results

- **horimiya**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **toradora**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **maid-sama**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **relife**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

- **my-little-monster**:
  - `responseBySearch.json`: Validated (Exists)
  - `responseBySlug.json`: Validated (Exists)
  - `responseByChapter.json`: Validated (Exists)

