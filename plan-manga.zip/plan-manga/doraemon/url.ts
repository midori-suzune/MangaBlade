export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=%C4%90%C3%B4r%C3%AAmon";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/doraemon";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/65901b5de120ddf2199227bc";
