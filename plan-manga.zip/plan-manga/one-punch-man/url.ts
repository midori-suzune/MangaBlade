export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=One";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/one-punch-man-webcomic";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/69e901447b89b5b2570f7047";
