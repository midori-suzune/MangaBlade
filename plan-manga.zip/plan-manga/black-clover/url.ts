export const queryByTitle =
  "https://otruyenapi.com/v1/api/tim-kiem?keyword=Kuroobaa";

export const queryBySlug =
  "https://otruyenapi.com/v1/api/truyen-tranh/clover-kuroobaa";

export const queryByChapter =
  "https://sv1.otruyencdn.com/v1/api/chapter/65433ad219227e32c83aecf3";
